"""Operational commands for `nyxgpt ops`: install, status, doctor, restart, logs, env-sync.

Wraps the native (Homebrew services + LaunchAgents) and Docker-managed
(Cassandra container, Docker Compose stack) pieces of a local nyxGPT
deployment behind a single CLI surface, so operators never need to run raw
`brew`/`docker`/`launchctl` commands themselves. Also cross-checks for a
Compose deployment running alongside the native one so `status`/`restart`
can warn about -- and refuse to create -- port collisions between the two.
"""

from __future__ import annotations

import base64
import contextlib
import getpass
import hashlib
import importlib.metadata
import importlib.resources
import ipaddress
import json
import logging
import os
import platform
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import tarfile
import threading
import time
import tomllib
from collections.abc import Callable, Container, Iterator
from configparser import ConfigParser
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from nacl import public as nacl_public

from nyxgpt import metrics as prom_metrics
from nyxgpt import release_tarball, self_heal, tracing
from nyxgpt import verify as verify_mod
from nyxgpt.config import (
    get_error_tracking_config,
    get_error_tracking_enabled,
    get_log_aggregation_enabled,
    get_monitoring_config,
    get_monitoring_slack_webhook_url,
    get_tracing_config,
    get_tracing_enabled,
    grafana_admin_password_path,
    read_grafana_admin_password,
    resolve_grafana_admin_password,
)
from nyxgpt.logging import get_correlation_id

# The vendored-source tarball builder lives in its own stdlib-only module
# (#3741) so release tooling -- `scripts/build_homebrew_artifacts.py`, run by
# CI jobs that only check the repo out -- can import it without dragging in
# this module's runtime dependencies (httpx, pynacl, the metrics/tracing
# stack). Re-exported here because the local file:// tap install path below
# has always called these by their `ops.` names.
from nyxgpt.release_tarball import (  # noqa: F401
    _WEB_VENDOR_EXCLUDES,
    _sha256_file,
    _vendor_tree,
    build_release_dist_tarball,
)

logger = logging.getLogger(__name__)

# Repo root: .../nyxGPT/src/nyxgpt/ops.py -> parents[2] is repo root.
#
# #3621 retired every REPO_ROOT-relative lookup the `nyxgpt ops
# install`/`up` local-stack reconciliation path depended on (Compose file,
# config/provisioning templates, launchd/systemd unit templates, helper
# scripts -- see `_sync_packaged_resources`) in favor of package data
# resolved via `importlib.resources`. REPO_ROOT itself stays, scoped to
# operations that are inherently repo-checkout-dependent regardless of
# Python packaging: building distributable artifacts FROM source (Homebrew
# tap tarball vendoring, the self-contained Linux venv build, Docker image
# builds for Terraform/Kubernetes local deploy), Terraform/Kubernetes local
# deploy itself (terraform/*.tf and k8s/*.yaml are files on disk, not
# importable package data), the `web/` npm project (its own build/packaging
# concern, not shipped as Python package data), and dev-checkout-only
# doctor/version diagnostics that no-op cleanly when REPO_ROOT doesn't
# exist. `tests/unit/test_repo_root_allowlist.py` guards this boundary: it
# fails if a new REPO_ROOT-relative lookup appears anywhere it isn't already
# on the allowlist.
REPO_ROOT = Path(__file__).resolve().parents[2]

# Maps a logical component to its Homebrew service name for native mode.
# Cassandra has no native brew service -- per product_management/PHASE_6_PLAN.md it stays the one
# ops-managed Docker container even under native-first, so it's tracked via
# `_docker_container_state` instead (see `detect_deployment_mode`).
NATIVE_BREW_SERVICES: dict[str, str] = {
    "api": "nyxgpt-api",
    "web": "nyxgpt-web",
    "ollama": "ollama",
}

# Linux twin of NATIVE_BREW_SERVICES: maps a logical component to its
# systemd --user unit name (see ops/systemd/*.service, #3508). "ollama" gets
# its own nyxgpt-ollama.service so it's managed the same operator-facing way
# as api/web -- including when a distro-installed system-wide `ollama.service`
# (e.g. from the official installer) already holds port 11434, which install
# stops and disables to take the port over (#3632; see
# `_system_ollama_service_conflicts`/`_takeover_system_ollama_service`).
NATIVE_SYSTEMD_SERVICES: dict[str, str] = {
    "api": "nyxgpt-api",
    "web": "nyxgpt-web",
    "ollama": "nyxgpt-ollama",
}


def _is_macos() -> bool:
    """True if running on macOS -- the Homebrew services + launchd native path."""
    return platform.system() == "Darwin"


def _is_linux() -> bool:
    """True if running on Linux -- the systemd --user native path (#3508)."""
    return platform.system() == "Linux"


def _unsupported_os_result(action: str) -> list[OpsResult]:
    """Standard failure for a native-mode step on an OS with no dispatch branch.

    Native install is supported on macOS (Homebrew/launchd) and Linux
    (systemd) only -- Compose/Terraform/Kubernetes deployment modes are
    unaffected since they never touch host service managers.
    """
    return [
        OpsResult(
            False,
            f"{action}: unsupported OS for native mode ({platform.system()})",
            "Native install (nyxgpt ops install, no --terraform/--kubernetes) supports "
            "macOS and Linux only. Use --terraform or --kubernetes on other platforms.",
        )
    ]


# Host port each component binds to under Docker Compose (see docker-compose.yml).
# Used only for collision messaging -- detection itself is state-based.
COMPOSE_COMPONENT_PORTS: dict[str, int] = {
    "api": 8000,
    "web": 3000,
    "ollama": 11434,
    "cassandra": 9042,
}

# Local web UI URL once the stack is up. Native and Compose/Terraform modes
# all bind `web` to the same host port (COMPOSE_COMPONENT_PORTS above,
# app.py's CORS allowlist) -- Kubernetes mode is the one exception, since its
# Services are ClusterIP-only and need a manual `kubectl port-forward` (see
# `up()`, docs/kubernetes.md#4-verify).
WEB_URL = "http://127.0.0.1:3000"

NATIVE_CONFIG_HINT = "~/.nyxGPT/config.ini"
COMPOSE_CONFIG_HINT = (
    "~/.nyxGPT/docker/config.docker.ini (mounted into the Compose 'api' container)"
)

# Runtime data the ops layer needs -- the Compose file, its config/provisioning
# templates, launchd/systemd unit templates, and a handful of helper scripts
# -- ships inside the installed package under `nyxgpt.resources` (see
# pyproject.toml's package-data and `src/nyxgpt/resources/`) instead of being
# resolved relative to REPO_ROOT: an installed, non-editable build has no
# repo checkout alongside it for REPO_ROOT-relative lookups to find (#3621).
# `_sync_packaged_resources` (called by `install()`) copies that packaged
# tree into this fixed, writable, ops-managed location once per install;
# every lookup below just reads from here afterwards, uniformly across a dev
# checkout and an installed package.
NYXGPT_HOME = Path.home() / ".nyxGPT"
OPS_COMPOSE_FILE = NYXGPT_HOME / "docker-compose.yml"
OPS_DOCKER_DIR = NYXGPT_HOME / "docker"
OPS_LAUNCHAGENTS_DIR = NYXGPT_HOME / "ops" / "launchagents"
OPS_SYSTEMD_TEMPLATES_DIR = NYXGPT_HOME / "ops" / "systemd"
OPS_SCRIPTS_SRC_DIR = NYXGPT_HOME / "scripts"

# Where nyxgpt drops CLI tools it installs on the operator's behalf when no
# package manager can supply them (currently `kind`/`kubectl` for
# `nyxgpt ops install --kubernetes --local` -- see `_ensure_cli_tool`, #3724).
# Kept inside the ops-managed home rather than a system location so no step
# ever needs sudo; `_ensure_nyxgpt_bin_on_path` puts it on PATH for the
# running process so the very same run can use what it just installed.
NYXGPT_BIN_DIR = NYXGPT_HOME / "bin"

# The container api-config is a derived, per-machine artifact (like .env):
# it's bind-mounted into the containerized api and gets its DSN filled in at
# runtime by `nyxgpt ops glitchtip-init`, so it isn't part of the packaged
# resources synced by `_sync_packaged_resources`. `nyxgpt ops
# install`/`env-sync` regenerates it from the native `~/.nyxGPT/config.ini`
# (the single source of truth) via `_generate_compose_config`.
COMPOSE_CONFIG_FILE = OPS_DOCKER_DIR / "config.docker.ini"

# Compose override that attaches the observability profiles to the
# terraform-managed network (`nyxgpt-terraform`) so they interoperate with the
# terraform-managed core containers -- used by `install --terraform --local`.
TERRAFORM_NET_OVERRIDE = OPS_DOCKER_DIR / "docker-compose.terraform-net.yml"

# Placeholder substituted with the installing user's home directory when a
# LaunchAgent plist template is copied into ~/Library/LaunchAgents -- the
# templates in ops/launchagents/ must never hard-code a real account's home
# directory (see #3276 acceptance failure: the merged plists hard-coded the
# original author's `/Users/darlabaker`, so the installed LaunchAgent pointed
# at a nonexistent script path for every other user).
LAUNCHAGENT_HOME_PLACEHOLDER = "__NYXGPT_HOME__"

# Container path promtail's docker-compose.yml service binds to native-mode
# host logs (~/.nyxGPT/logs). `_log_aggregation_wiring_issue` checks the
# running promtail container's actual mounts (via `docker inspect`) for this
# destination to catch a regression (see #3277, #3349) where that bind mount
# is dropped and native-mode logs silently stop reaching Loki.
PROMTAIL_NATIVE_LOG_MOUNT_MARKER = "/var/log/nyxgpt-native/logs"

# --- Container data layout (see docs/docker-compose.md#volumes, issue #3346) ---
#
# All container data lives in plain host bind mounts under ~/.nyxGPT/volumes/
# instead of opaque named Docker volumes -- visible/attributable on the host
# filesystem and, for the three "shared" directories below, reused as-is by
# every deployment mode that mounts them (rather than each mode keeping its
# own duplicate copy). `VOLUME_DIR_NAMES` maps a logical component name to
# its directory under ~/.nyxGPT/volumes/; `volume_dir()` resolves the full
# path. Kept in this module (rather than config.py) since it's purely a
# Docker/ops concern -- native processes' own state (~/.nyxGPT/config.ini,
# ~/.nyxGPT/logs, ...) is unrelated and untouched by any of this.
VOLUME_DIR_NAMES: dict[str, str] = {
    # Shared across every mode that mounts them: the native `nyxgpt-cassandra`
    # container (`_ensure_cassandra_container` below), docker-compose.yml, and
    # terraform/main.tf all bind to the *same* ~/.nyxGPT/volumes/cassandra and
    # ~/.nyxGPT/volumes/nyxgpt-data directories -- ollama is now shared by
    # native mode too (see #3431): native Ollama isn't containerized, but
    # `_ensure_ollama_service` points its `OLLAMA_MODELS` env var at
    # ~/.nyxGPT/volumes/ollama/models, the same directory Compose/Terraform's
    # `ollama` container bind-mounts (as /root/.ollama), instead of native
    # Ollama's own default ~/.ollama/models store.
    "cassandra": "cassandra",
    "ollama": "ollama",
    "nyxgpt-data": "nyxgpt-data",
    # Compose-only today (no native/Terraform equivalent), so no per-mode
    # duplication to worry about -- see OBSERVABILITY_PROFILES.
    "prometheus": "prometheus",
    "grafana": "grafana",
    "loki": "loki",
    "glitchtip-postgres": "glitchtip-postgres",
    "glitchtip-uploads": "glitchtip-uploads",
}


def volume_dir(component: str) -> Path:
    """Return `~/.nyxGPT/volumes/<component>`'s host bind-mount path, creating it if needed."""
    p = Path.home() / ".nyxGPT" / "volumes" / VOLUME_DIR_NAMES[component]
    _ensure_dir(p)
    return p


@dataclass(frozen=True)
class DeploymentMode:
    """Snapshot of what's actually running, native vs. Docker Compose vs. Terraform.

    `native`/`compose`/`terraform` map component name -> a state string
    ("started"/"running"/"none"/"absent"/...); `conflicts` lists components
    reported live in both native and Compose (a same-port phantom-backend
    conflict). `terraform_conflicts` lists components reported live under
    Terraform *and* under native or Compose at once -- a whole second core
    stack left running after an incomplete mode switch (#3565: `nyxgpt ops
    down` without `--terraform` followed by `nyxgpt ops install` left both
    the native and Terraform stacks up, each answering on its own network,
    while this dataclass's pre-fix `conflicts` field -- native-vs-Compose
    only -- had no way to represent it and logged `conflicts=[]`). `terraform`
    defaults to `{}` and `terraform_conflicts` to `[]` so every existing
    positional/keyword construction (tests included) stays valid without
    populating them.
    """

    native: dict[str, str]
    compose: dict[str, str]
    conflicts: list[str]
    terraform: dict[str, str] = field(default_factory=dict)
    terraform_conflicts: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class OpsResult:
    """Outcome of a single ops step: whether it succeeded, plus human-readable detail."""

    ok: bool
    message: str
    details: str = ""


# Prefix a step uses to mark an attempt that failed but that a later fallback
# in the *same* step already made moot -- see `_superseded_attempts`.
_SUPERSEDED_PREFIX = "Superseded"


def _result_status_label(r: OpsResult) -> str:
    """Return the stdout status label for `r`: "OK", "FAIL", "SKIP" or "NOTE".

    A skip is still `ok=True` (accounting/exit-code logic is unaffected) but
    reads misleadingly as a plain "OK" -- results whose message starts with
    "Skipped" (the existing convention for a deliberate no-op, e.g. "no
    docker found") print as SKIP instead (#3558).

    "NOTE" is the same idea for the other direction: an attempt that *failed*
    but that the step then recovered from is not a success and not a failure,
    and printing it as either misreports the step (#3762).
    """
    if not r.ok:
        return "FAIL"
    if r.message.strip().lower().startswith("skip"):
        return "SKIP"
    if r.message.strip().startswith(_SUPERSEDED_PREFIX):
        return "NOTE"
    return "OK"


def _superseded_attempts(results: list[OpsResult]) -> list[OpsResult]:
    """Rewrite failed attempts in `results` that a later fallback already made moot.

    A step that tries one route, fails, and then succeeds by another route
    used to print `[FAIL] <first route>` followed by `[OK] <second route>`,
    which reads as a step contradicting itself -- the owner's 2026-08-14
    cloud acceptance run saw exactly that under `[4/23] docker engine`
    (#3762). The attempt genuinely failed, so it is not relabelled "OK";
    it becomes a `[NOTE]` whose details keep the original diagnostic, and
    the step's verdict is left to the result that actually settled it.

    Successful results pass through untouched, so callers can hand a whole
    sub-step's output here without filtering first.
    """
    settled: list[OpsResult] = []
    for r in results:
        if r.ok:
            settled.append(r)
            continue
        settled.append(
            OpsResult(
                True,
                f"{_SUPERSEDED_PREFIX}: {r.message} (recovered below -- not a failure of this step)",
                r.details,
            )
        )
    return settled


def _emit_results(action: str, results: list[OpsResult]) -> bool:
    """Print and structured-log each OpsResult from an ops step, returning overall success.

    Preserves the `[OK]`/`[FAIL]`/`[SKIP]` stdout lines every CLI entrypoint
    already printed, and additionally logs one INFO/WARNING record per
    result (service/action/result plus any subprocess failure detail in
    `details`) so `nyxgpt ops` activity lands in the log files instead of
    only stdout.

    A *failing* result's details are inlined into the WARNING message itself,
    bounded by `_bounded_output` (#3783). They were previously carried only in
    the structured `extra`, so the step-failure line an operator actually reads
    ("ops: install failed: Failed to pip install nyxgpt-api") named the step
    and dropped the reason.
    """
    ok = True
    for r in results:
        print(f"[{_result_status_label(r)}] {r.message}")
        if r.details:
            print(f"  {r.details}")
        log = logger.info if r.ok else logger.warning
        detail_excerpt = "" if r.ok else _bounded_output(r.details)
        log(
            "ops: %s %s: %s",
            action,
            "ok" if r.ok else "failed",
            f"{r.message}\n{detail_excerpt}" if detail_excerpt else r.message,
            extra={
                "component": "ops",
                "action": action,
                "ok": r.ok,
                "result_message": r.message,
                "details": r.details,
            },
        )
        ok = ok and r.ok
    return ok


# --- Live step progress (#3558) ---
#
# `install()`/`down()`/`restart()`/`stop()`/`observability()`/`env_sync()`/
# `glitchtip_init()` used to build up a `results` list across every step and
# print it all at once via a single `_emit_results()` call at the end --
# meaning a ~52-step `nyxgpt ops install` run stayed completely silent until
# the very last step finished, with no way to tell a slow step from a hung
# one. `_run_steps()` below is the shared replacement: it announces each
# step before running it, prints that step's own outcome immediately after
# (so output streams live), and runs a background heartbeat while a step is
# still in flight. `--quiet` (per CLI entrypoint) suppresses the
# announcements/heartbeat/summary and falls back to the old terse
# OK/FAIL-only-per-result output, for scripting.

# Seconds between "still running" heartbeat lines for an in-flight step.
_STEP_HEARTBEAT_INTERVAL_S = 5.0

# Elapsed seconds at/over which a step is called out in the final "slow
# steps" summary.
_SLOW_STEP_THRESHOLD_S = 3.0

_STEP_FAILURE_HINT = (
    "Run `nyxgpt ops doctor` for diagnostics or `nyxgpt ops logs <service>` to inspect "
    "recent logs, then retry."
)


class _StepHeartbeat:
    """Background thread printing periodic elapsed-time lines for an in-flight step.

    Started right before a step's function runs and stopped right after, so
    an operator watching a long silent step (brew install, image pull,
    Cassandra readiness wait) can tell "still working" from "hung" (#3558).
    """

    def __init__(self, step_name: str) -> None:
        """Prepare (but don't yet start) a heartbeat for the step named `step_name`."""
        self._step_name = step_name
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        """Start the background heartbeat thread."""
        self._thread.start()

    def _run(self) -> None:
        """Print a "still running" line every `_STEP_HEARTBEAT_INTERVAL_S` until stopped."""
        elapsed = 0.0
        while not self._stop_event.wait(_STEP_HEARTBEAT_INTERVAL_S):
            elapsed += _STEP_HEARTBEAT_INTERVAL_S
            print(f"    ... still running ({elapsed:.0f}s): {self._step_name}")

    def stop(self) -> None:
        """Signal the heartbeat thread to stop and wait for it to exit."""
        self._stop_event.set()
        self._thread.join(timeout=_STEP_HEARTBEAT_INTERVAL_S)


def _run_steps(
    action: str,
    steps: list[tuple[str, Callable[[], list[OpsResult]]]],
    *,
    quiet: bool = False,
) -> tuple[list[OpsResult], list[tuple[str, float]]]:
    """Run `steps` in order, streaming live progress instead of buffering to the end (#3558).

    Before each step (unless `quiet`): prints "[n/m] step_name..." and
    starts a background heartbeat (`_StepHeartbeat`). After each step: prints
    its OK/FAIL/SKIP outcome via `_emit_results` right away, so a long
    `nyxgpt ops install` run shows progress as it happens. A step whose
    function raises is turned into a single FAIL result naming the step, the
    error, and a remediation hint -- exactly like a returned failure -- so
    one bad step doesn't abort the rest (matches the pre-existing
    best-effort contract of these step loops).

    Returns the combined results plus `(step_name, elapsed_seconds)` for
    every step at/over `_SLOW_STEP_THRESHOLD_S`, for the caller's final
    slow-step summary.
    """
    results: list[OpsResult] = []
    slow_steps: list[tuple[str, float]] = []
    total = len(steps)
    for i, (step_name, fn) in enumerate(steps, start=1):
        if not quiet:
            print(f"[{i}/{total}] {step_name}...")
        heartbeat = None if quiet else _StepHeartbeat(step_name)
        start_time = time.monotonic()
        if heartbeat is not None:
            heartbeat.start()
        try:
            step_results = fn()
        except Exception as e:
            logger.error(
                "ops: %s step %s raised %s: %s",
                action,
                step_name,
                type(e).__name__,
                e,
                extra={"component": "ops", "action": action, "step": step_name},
                exc_info=True,
            )
            # `str(CalledProcessError)` is only "Command '...' returned
            # non-zero exit status 1." -- the output that says *why* is on the
            # exception, so put it in the step's own failure detail rather
            # than making the reader go find the preceding `_run` warning
            # (#3783).
            cause = f"{type(e).__name__}: {e}"
            if isinstance(e, subprocess.CalledProcessError):
                excerpt = _combined_output_excerpt(e.stdout, e.stderr)
                if excerpt:
                    cause = f"{cause}\n{excerpt}"
            step_results = [
                OpsResult(
                    False,
                    f"ops {action} failed: {step_name}",
                    f"{cause}. {_STEP_FAILURE_HINT}",
                )
            ]
        finally:
            if heartbeat is not None:
                heartbeat.stop()
        elapsed = time.monotonic() - start_time
        if elapsed >= _SLOW_STEP_THRESHOLD_S:
            slow_steps.append((step_name, elapsed))
        _emit_results(action, step_results)
        _emit_step_verdict(action, step_name, i, total, step_results)
        results.extend(step_results)
    return results, slow_steps


def _emit_step_verdict(
    action: str,
    step_name: str,
    index: int,
    total: int,
    results: list[OpsResult],
) -> None:
    """Print one closing verdict for a step whose results were mixed (#3762).

    Each `OpsResult` is true on its own, but a step that emits a `[FAIL]`
    and then `[OK]` lines for its other checks has no single answer to "did
    step 4 pass?" -- the owner's 2026-08-14 cloud acceptance run read that
    output as self-contradictory. The step's last word is added here so the
    answer is always the last line about it.

    Only mixed steps get a verdict: an all-OK or all-FAIL step already reads
    coherently, and a failure the step recovered from is a `[NOTE]`
    (`_superseded_attempts`), not a failure, so it doesn't trigger one either.
    """
    failures = [r for r in results if not r.ok]
    if not failures or len(failures) == len(results):
        return
    summary = "; ".join(r.message for r in failures)
    print(
        f"[FAIL] step {index}/{total} {step_name!r} did not fully succeed: "
        f"{len(failures)} of {len(results)} checks failed ({summary})"
    )
    logger.warning(
        "ops: %s step %s did not fully succeed: %s",
        action,
        step_name,
        summary,
        extra={
            "component": "ops",
            "action": action,
            "step": step_name,
            "ok": False,
            "failed_checks": len(failures),
            "total_checks": len(results),
        },
    )


def _print_slow_steps_summary(slow_steps: list[tuple[str, float]]) -> None:
    """Print the final "slow steps" summary for a live-progress step run (#3558)."""
    if not slow_steps:
        return
    print(f"\nSlow steps (over {_SLOW_STEP_THRESHOLD_S:.0f}s):")
    for step_name, elapsed in slow_steps:
        print(f"  {step_name}: {elapsed:.1f}s")


def _ops_action_outcome(results: list[OpsResult]) -> tuple[str, str]:
    """Reduce a block of `OpsResult`s to a single (result, message) pair.

    `result` is "success" if every result ok'd, "refused" if any failing
    result's message starts with "Refusing" (the existing convention used by
    `_compose_conflict_result`/`_ensure_cassandra_container`'s port-collision
    refusals), else "failure".
    """
    if not results:
        return "success", ""
    failed = [r for r in results if not r.ok]
    if not failed:
        return "success", "; ".join(r.message for r in results)
    if any(r.message.startswith("Refusing") for r in failed):
        return "refused", "; ".join(r.message for r in failed)
    return "failure", "; ".join(r.message for r in failed)


def _record_ops_action(command: str, service: str, result: str, message: str = "") -> None:
    """Record one operator-initiated lifecycle action: a `nyxgpt_ops_actions_total`
    increment plus a structured log event.

    Kept entirely separate from self-heal's own `nyxgpt_selfheal_restarts_total`
    counter and heal-event log (see #3390 -- the self-heal counter answers "how
    often did the system recover itself"; folding operator-driven `nyxgpt ops`
    actions into it would make autonomous heals indistinguishable from manual
    restarts). This is the one place both CLI (`nyxgpt ops ...`) and the
    SRE/admin dashboard's equivalent API calls funnel through, so a metrics gap
    can be attributed to a deliberate `ops down` rather than reading as an
    unexplained outage.

    `correlation_id` (#3430) is `get_correlation_id()`'s resolution: the
    active HTTP request's `request_id` for dashboard-triggered actions, or
    `NYXGPT_CORRELATION_ID` from the environment for CLI-triggered ones (see
    `mint_correlation_id`) -- lets an operator join this event to the
    subprocess it drove, or the request that triggered it.
    """
    correlation_id = get_correlation_id()
    prom_metrics.OPS_ACTIONS_TOTAL.labels(command=command, service=service, result=result).inc()
    log = logger.info if result == "success" else logger.warning
    log(
        "ops: lifecycle action command=%s service=%s result=%s correlation_id=%s%s",
        command,
        service,
        result,
        correlation_id,
        f": {message}" if message else "",
        extra={
            "component": "ops",
            "event": "ops_lifecycle_action",
            "command": command,
            "service": service,
            "result": result,
            "result_message": message,
            "correlation_id": correlation_id,
        },
    )


def record_manual_restart(service: str, ok: bool, message: str = "") -> None:
    """Record a dashboard-triggered "Heal Now" restart as an ops lifecycle action.

    Called by the `/api/v1/self-heal/heal` endpoint for each component it
    restarts -- a manual heal-now click is an operator-initiated restart just
    like `nyxgpt ops restart <service>`, so it's recorded the same way (see
    #3390). This does not touch `nyxgpt_selfheal_restarts_total`, which
    self_heal.heal_now() already increments for this same restart -- that
    counter's accounting of "this component was restarted" is unaffected;
    this only adds the separate operator-action signal.
    """
    _record_ops_action("restart", service, "success" if ok else "failure", message)


def record_canary_action(
    action: str, result: str, message: str = "", *, component: str = "api"
) -> None:
    """Record a canary lifecycle action (deploy/start/promote/rollback) per #3390.

    `canary.py` funnels every rollout action through here rather than calling
    `_record_ops_action` directly, keeping the "canary-<action>" command
    naming convention (mirroring "install"/"restart"/"down") in one place.
    `service` is `component` -- "api" by default (unchanged from before
    #3419), or "web" for the web canary pair (see canary.py's `COMPONENTS`).
    """
    _record_ops_action(f"canary-{action}", component, result, message)


# Set by `_enable_docker_socket_hop` (see its docstring) when this process
# cannot reach the Docker socket directly -- the invoking session predates its
# `docker` group membership. Either "sg" (re-run the command under the docker
# group) or "sudo" (passwordless sudo), whichever is available *and* proven to
# carry this process's environment through unchanged. It is applied centrally
# in `_run` rather than at the ~40 `["docker", ...]` call sites in this module,
# so no Docker call path can forget it and re-introduce #3760's mid-deploy
# "permission denied ... /var/run/docker.sock".
_DOCKER_SOCKET_HOP: str | None = None

# How each hop is spelled, and how it reads in an OpsResult.
_DOCKER_SOCKET_HOP_LABELS = {"sg": "`sg docker`", "sudo": "`sudo -n docker`"}


def _docker_socket_hop() -> str | None:
    """The hop ops is currently routing its Docker calls through, if any."""
    return _DOCKER_SOCKET_HOP


def _docker_socket_hop_active() -> bool:
    """True while ops is reaching the Docker socket through a hop."""
    return _DOCKER_SOCKET_HOP is not None


def _wrap_docker_hop(cmd: list[str], hop: str | None) -> list[str]:
    """Rewrite `cmd` to run through `hop`, preserving the environment it sees.

    Both forms are environment-preserving *by construction*, which is the
    whole point (#3760 review): `docker-compose.yml` interpolates `${HOME}`
    for every bind mount, and `docker compose exec -e VAR` (bare, no `=value`)
    forwards secrets out of this process's environment without ever putting
    them on argv (CodeQL #105/#106). A hop that resets the environment would
    silently relocate every volume under `/root` and drop those secrets.

    - `sg docker -c ...` re-runs the command with the `docker` group added to
      the credentials, leaving the environment entirely alone. It takes a
      command *string*, so argv is shell-quoted with `shlex.join`.
    - `sudo -n --preserve-env ...` opts out of sudo's default `env_reset`
      (and, on Amazon Linux/RHEL, its `always_set_home`). `--preserve-env`
      needs the sudoers SETENV tag, which `NOPASSWD: ALL` implies -- and
      `_docker_hop_preserves_env` verifies it rather than assuming it.
    """
    if hop == "sg":
        return ["sg", "docker", "-c", shlex.join(cmd)]
    if hop == "sudo":
        return ["sudo", "-n", "--preserve-env", *cmd]
    return cmd


def _apply_docker_socket_hop(cmd: list[str]) -> list[str]:
    """Route a bare `docker ...` argv through the active hop.

    Only rewrites argv whose *first* element is `docker`, so an argv that is
    already privileged (`_privileged_run` puts `sudo` in front) is never
    double-wrapped, and no non-Docker command is touched.
    """
    if _DOCKER_SOCKET_HOP is not None and cmd and cmd[0] == "docker":
        return _wrap_docker_hop(cmd, _DOCKER_SOCKET_HOP)
    return cmd


def _run(
    cmd: list[str],
    *,
    check: bool = True,
    expected: bool = False,
    expected_returncodes: Container[int] | None = None,
    expected_message: str | None = None,
    input: str | None = None,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run `cmd`, capturing stdout/stderr as text.

    Raises `subprocess.CalledProcessError` on non-zero exit unless `check=False`.
    Non-zero exits are always logged with the command and a stderr tail first,
    so the evidence reaches Loki even when a caller catches the exception (or
    passes `check=False`) without logging it itself (#3415 gap 5).
    Pass `expected=True` for read-only probes where any non-zero exit is a
    normal outcome (e.g. "not found"/"not running") to log at DEBUG instead
    of WARNING.
    Pass `expected_returncodes={1, ...}` when only specific non-zero exit
    codes are a known success/no-op path (e.g. `createsuperuser --noinput`
    exiting 1 because the account already exists) -- a matching exit logs at
    INFO with `expected_message` (or a generic "expected exit" message)
    instead of WARNING, while any other non-zero exit still logs at WARNING
    exactly as today (#3574).
    A bare `docker ...` argv is routed through the active Docker socket hop
    (`_apply_docker_socket_hop`, see `_enable_docker_socket_hop`). Logging
    keeps the *unwrapped* argv: `_redact_cmd` masks secrets element by
    element, and `sg -c` collapses argv into one shell string it could not
    then see into.
    Pass `input` to feed the subprocess's stdin (e.g. a secret a caller
    doesn't want to put on `cmd`'s argv at all -- argv is visible to `ps`,
    shell history, and this function's own non-zero-exit logging, while
    stdin is not (#3644, CodeQL py/clear-text-logging-sensitive-data)).
    Pass `env` to run with a modified environment -- the other secret-safe
    channel: `docker compose exec -e VAR` (bare, no `=value`) forwards VAR
    from this process's environment into the container without the value
    ever appearing on argv (CodeQL #105/#106).
    """
    try:
        result = subprocess.run(
            _apply_docker_socket_hop(cmd),
            check=check,
            text=True,
            capture_output=True,
            input=input,
            env=env,
        )
    except subprocess.CalledProcessError as e:
        _log_nonzero_exit(
            cmd, e.returncode, e.stdout, e.stderr, expected, expected_returncodes, expected_message
        )
        raise
    if result.returncode != 0:
        _log_nonzero_exit(
            cmd,
            result.returncode,
            result.stdout,
            result.stderr,
            expected,
            expected_returncodes,
            expected_message,
        )
    return result


# --- Bounded subprocess output excerpts (#3783) ---
#
# A failed subprocess's *own* output is almost always the whole diagnosis --
# `pip`'s "requires a different Python: 3.9.x not in '>=3.11'" refusal during
# the rc9 cloud round said exactly what was wrong, and was thrown away because
# ops logged only the exit code and the argv. The owner had to SSH to the
# instance and re-run the command by hand to read it. So every failure path
# below carries the output with it -- but bounded, because an `npm ci` or a
# resolver backtrack can emit thousands of lines and unbounded log spam is its
# own failure of reporting. Head plus tail with an elision marker keeps both
# ends that matter: what the command was starting to do, and how it died.
_OUTPUT_EXCERPT_HEAD_LINES = 5
_OUTPUT_EXCERPT_TAIL_LINES = 20
_OUTPUT_EXCERPT_MAX_LINE_CHARS = 500


def _bounded_output(text: str | None) -> str:
    """Return `text` reduced to a bounded head+tail excerpt.

    Empty/None input yields `""`. Short output is returned verbatim (stripped),
    so the common case reads exactly as it did before this bounding existed.
    Longer output keeps the first `_OUTPUT_EXCERPT_HEAD_LINES` and the last
    `_OUTPUT_EXCERPT_TAIL_LINES` lines with an explicit `... [N lines omitted]
    ...` marker between them -- never silently truncated, and never zero. Any
    single line over `_OUTPUT_EXCERPT_MAX_LINE_CHARS` is clipped too, so one
    pathological line (a minified stack trace, a base64 blob) can't blow the
    bound on its own.
    """
    if not text or not text.strip():
        return ""
    lines = [
        (
            line
            if len(line) <= _OUTPUT_EXCERPT_MAX_LINE_CHARS
            else line[:_OUTPUT_EXCERPT_MAX_LINE_CHARS] + " ... [line truncated]"
        )
        for line in text.strip().splitlines()
    ]
    keep = _OUTPUT_EXCERPT_HEAD_LINES + _OUTPUT_EXCERPT_TAIL_LINES
    if len(lines) <= keep:
        return "\n".join(lines)
    omitted = len(lines) - keep
    return "\n".join(
        [
            *lines[:_OUTPUT_EXCERPT_HEAD_LINES],
            f"... [{omitted} lines omitted] ...",
            *lines[-_OUTPUT_EXCERPT_TAIL_LINES:],
        ]
    )


def _combined_output_excerpt(stdout: str | None, stderr: str | None) -> str:
    """Bounded stdout+stderr of a finished subprocess, in that order.

    Each stream is bounded *separately* rather than concatenated first: `pip`
    and `npm` write volumes of progress to stdout and the one-line reason for
    the failure to stderr, so a tail taken over the concatenation could drop
    the only line worth reading.
    """
    parts = [_bounded_output(stdout), _bounded_output(stderr)]
    return "\n".join(p for p in parts if p)


def _output_excerpt(cp: subprocess.CompletedProcess[str]) -> str:
    """Bounded combined output of `cp`, for an `OpsResult`'s failure details."""
    return _combined_output_excerpt(cp.stdout, cp.stderr)


# Argument names (and inline `--flag=value` forms) whose *value* may carry a
# secret. When we log a failed command we mask those values so an API key,
# password, or DSN can never reach Loki in clear text (CodeQL
# py/clear-text-logging-sensitive-data). Matching is case-insensitive and
# substring-based so `--api-key`, `--admin-password`, and `--glitchtip-dsn`
# are all covered.
_SECRET_ARG_HINTS = ("key", "token", "secret", "password", "passwd", "dsn", "credential")


def _redact_cmd(cmd: list[str]) -> list[str]:
    """Return a copy of `cmd` with any secret-bearing argument value masked.

    Two shapes are redacted: a value in the position *after* a secret-named
    flag (`--api-key VALUE` -> `--api-key ***`), and an inline `NAME=value`
    where the name looks sensitive -- with or without a leading dash, so
    both `--dsn=...` and an env-style `DJANGO_SUPERUSER_PASSWORD=...`
    (docker `-e NAME=value` forwarding) are masked. The returned list is
    freshly built so the sensitive value never flows on to the logging sink.
    """
    redacted: list[str] = []
    mask_next = False
    for arg in cmd:
        if mask_next:
            redacted.append("***")
            mask_next = False
            continue
        low = arg.lower()
        if "=" in arg:
            name, _, _value = arg.partition("=")
            if any(h in name.lower() for h in _SECRET_ARG_HINTS):
                redacted.append(f"{name}=***")
                continue
        if arg.startswith("-") and any(h in low for h in _SECRET_ARG_HINTS):
            redacted.append(arg)
            mask_next = True
            continue
        redacted.append(arg)
    return redacted


def _log_nonzero_exit(
    cmd: list[str],
    returncode: int,
    stdout: str | None,
    stderr: str | None,
    expected: bool,
    expected_returncodes: Container[int] | None,
    expected_message: str | None,
) -> None:
    """Log a subprocess non-zero exit at the appropriate level (helper for `_run`).

    A returncode declared via `expected_returncodes` logs at INFO -- it is
    useful information, not a warning sign -- with wording that explicitly
    says the exit was expected, so it never reads as scary to the user
    (#3574). Everything else keeps the pre-existing WARNING/DEBUG split.

    An unexpected exit carries a bounded excerpt of the subprocess's own
    combined output *in the log message*, not only in the structured `extra`
    (#3783): the message is what reaches a terminal, a `journalctl` tail and
    `nyxgpt ops logs`, and it was the only thing the owner could see when an
    rc9 install died on a `pip` refusal whose text ops had thrown away.
    """
    safe_cmd = _redact_cmd(cmd)
    safe_cmd_str = " ".join(safe_cmd)
    output = _combined_output_excerpt(stdout, stderr)
    if expected_returncodes is not None and returncode in expected_returncodes:
        level = logging.INFO
        message = expected_message or (
            f"Subprocess exited with expected rc={returncode}, treated as "
            f"success: {safe_cmd_str}"
        )
    else:
        level = logging.DEBUG if expected else logging.WARNING
        message = f"Subprocess exited non-zero (rc={returncode}): {safe_cmd_str}"
        if output:
            message += f"\n--- subprocess output ---\n{output}\n--- end subprocess output ---"
    # CodeQL alerts #105/#106 (py/clear-text-logging-sensitive-data) flagged
    # `message`/`extra` below, and were REAL twice over: a bare positional
    # secret (`_reset_grafana_admin_password`, fixed in #3644 by piping it
    # over stdin), and an env-style `-e DJANGO_SUPERUSER_PASSWORD=value`
    # argv element (`_glitchtip_ensure_superuser`) that slipped past
    # `_redact_cmd`'s dash-prefixed flag masking and reached this log's
    # `extra` at INFO on every idempotent glitchtip-init re-run. That call
    # site now forwards the secret via the process environment (bare `-e
    # VAR` + `_run(env=...)`) so it never appears on argv, and `_redact_cmd`
    # also masks dash-less `NAME=value` elements as defense-in-depth.
    # Keep secrets off argv entirely (stdin or env) at any new call site --
    # that kills the flow at the source instead of trying to convince
    # CodeQL's taint tracker that `_redact_cmd` is a sanitizer. Inline
    # suppression comments (`codeql[...]`, then `lgtm[...]`) were tried in
    # earlier rounds and neither took effect against this repo's CodeQL
    # default-setup configuration -- don't reintroduce them.
    # `test_run_redacts_secret_cmd_values_on_nonzero_exit` in
    # `tests/unit/test_ops.py` covers the masking that remains as
    # defense-in-depth for any other secret-bearing flag.
    logger.log(
        level,
        message,
        extra={
            "component": "ops",
            "cmd": safe_cmd,
            "returncode": returncode,
            "stderr_tail": stderr[-2000:] if stderr else "",
            "output_excerpt": output,
        },
    )


def _which(prog: str) -> str | None:
    """Return the absolute path to `prog` on PATH, or None if it isn't found."""
    return shutil.which(prog)


def _running_as_root() -> bool:
    """True if this process already has root privileges (no sudo needed)."""
    geteuid = getattr(os, "geteuid", None)
    return geteuid is not None and geteuid() == 0


def _privileged_run(
    cmd: list[str], *, expected: bool = False
) -> subprocess.CompletedProcess[str] | None:
    """Run `cmd` with root privileges, never prompting for a password.

    A handful of install steps genuinely need root on Linux and cannot be
    expressed any other way: stopping/disabling the *system-scope*
    `ollama.service` the official Ollama installer enables so nyxGPT's own
    `nyxgpt-ollama.service` can hold port 11434 (#3632), installing the
    Docker engine/Compose plugin from the distro's package manager, and
    chowning a Docker-created root-owned bind-mount directory to the uid its
    container runs as. All of them are reconciliation `nyxgpt ops install`
    is expected to perform on its own -- an operator who has to hand-run
    three `sudo` commands before `install` can finish is exactly the
    friction #3632 was filed about.

    `sudo -n` is the safety property that makes this acceptable: it *never*
    prompts. On a host with passwordless sudo (the default on Ubuntu cloud
    images and GitHub Actions runners) the command runs; anywhere else it
    fails instantly and the caller reports the exact command for the
    operator to run themselves, rather than hanging on a TTY prompt inside a
    non-interactive install. Returns None when root is unreachable at all
    (no `sudo` on PATH and not already root) so callers can distinguish
    "couldn't even try" from "tried and was refused".
    """
    if _running_as_root():
        return _run(cmd, check=False, expected=expected)
    if _which("sudo") is None:
        return None
    return _run(["sudo", "-n", *cmd], check=False, expected=expected)


def _read_project_version() -> str:
    """Return the project version from pyproject.toml, or "0.0.0" if unreadable.

    The "0.0.0" fallback is deliberately implausible: a brew formula stamped
    with it signals "version could not be determined" instead of silently
    masquerading as a real release.
    """
    pyproject = REPO_ROOT / "pyproject.toml"
    if not pyproject.exists():
        return "0.0.0"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    return str(data.get("project", {}).get("version", "0.0.0"))


def project_version() -> str:
    """Public wrapper around `_read_project_version()`, for cross-module version stamping.

    Used by `canary.py` to stamp the versioned image tag `nyxgpt ops deploy
    --kubernetes` builds (see #3409) -- `_read_project_version` stays private
    since every other caller is internal to this module.
    """
    return _read_project_version()


def _ensure_dir(p: Path) -> None:
    """Create directory `p` (and any missing parents) if it doesn't already exist."""
    p.mkdir(parents=True, exist_ok=True)


def _copy_file(src: Path, dst: Path, *, mode: int | None = None) -> None:
    """Copy `src` to `dst`, creating `dst`'s parent directory and optionally chmod'ing it.

    Args:
        src: Source file path.
        dst: Destination file path.
        mode: If given, permission bits applied to `dst` after copying (e.g. 0o755).
    """
    _ensure_dir(dst.parent)
    shutil.copy2(src, dst)
    if mode is not None:
        os.chmod(dst, mode)


def _packaged_resources_root() -> Path:
    """Return the filesystem path backing the `nyxgpt.resources` package data.

    Resolves via `importlib.resources`, so this works identically whether
    nyxGPT is running from an editable dev checkout (`src/nyxgpt/resources/`
    holds symlinks back to the canonical `docker/`, `docker-compose.yml`,
    `ops/`, `.env.example`, `scripts/*.sh`) or an installed, non-editable
    wheel (real copies of the same files, bundled at build time -- see
    pyproject.toml's `[tool.setuptools.package-data]`).
    """
    return Path(str(importlib.resources.files("nyxgpt.resources")))


def _sync_packaged_resources() -> list[OpsResult]:
    """Copy the packaged Compose/config/provisioning/unit-template/script
    tree into `NYXGPT_HOME` so every other ops step reads from one fixed,
    writable location regardless of whether nyxGPT is running from a source
    checkout or an installed package (#3621) -- see `_packaged_resources_root`.

    Idempotent and safe to re-run: overwrites the synced copies (so a
    `nyxgpt ops install` after an upgrade always ships the current
    templates) without touching anything else already under `NYXGPT_HOME`,
    notably `docker/config.docker.ini` (a separately generated, git-ignored
    artifact -- see `_generate_compose_config` -- never part of the packaged
    resources) and `config.ini`.
    """
    src_root = _packaged_resources_root()
    try:
        _copy_file(src_root / "docker-compose.yml", OPS_COMPOSE_FILE)
        _copy_file(src_root / ".env.example", NYXGPT_HOME / ".env.example")
        for subdir in ("docker", "ops", "scripts"):
            shutil.copytree(src_root / subdir, NYXGPT_HOME / subdir, dirs_exist_ok=True)
        for script in OPS_SCRIPTS_SRC_DIR.glob("*.sh"):
            os.chmod(script, 0o755)
    except OSError as e:
        return [
            OpsResult(
                False,
                "Failed to sync packaged ops resources",
                f"{type(e).__name__}: {e}",
            )
        ]
    return [OpsResult(True, f"Synced packaged ops resources to {NYXGPT_HOME}")]


def _tap_repo(tap: str) -> Path:
    """Return the local checkout path of Homebrew tap `tap` (`brew --repo <tap>`)."""
    cp = _run(["brew", "--repo", tap])
    return Path((cp.stdout or "").strip())


# --- Deployment mode detection ---


def _brew_services_snapshot() -> dict[str, str]:
    """Return {brew_service_name: state} parsed from `brew services list`."""
    if _which("brew") is None:
        return {}
    cp = _run(["brew", "services", "list"], check=False, expected=True)
    snapshot: dict[str, str] = {}
    for line in (cp.stdout or "").splitlines():
        parts = line.split()
        if len(parts) >= 2:
            snapshot[parts[0]] = parts[1]
    return snapshot


def _docker_container_state(name: str) -> str:
    """Return the docker state ('running', 'exited', ...) for a container, or 'absent'."""
    if _which("docker") is None:
        return "absent"
    cp = _run(
        ["docker", "ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.State}}"],
        check=False,
        expected=True,
    )
    out = (cp.stdout or "").strip()
    return out.splitlines()[0].strip() if out else "absent"


def _compose_stack_snapshot() -> dict[str, str]:
    """Return {service: state} for the docker-compose.yml stack, if any is running.

    Reuses self_heal.list_component_status(), which already knows how to resolve
    and query the project's docker-compose.yml via `docker compose ps -a`. That
    call returns a combined view -- Compose services plus native components plus
    absent-desired entries -- so this filters to `source == "compose"` only;
    otherwise a native component (e.g. the native `nyxgpt-cassandra` container)
    would fold into this "compose" snapshot and collide with the native reading
    of the very same container in `detect_deployment_mode()`, producing a false
    phantom-backend conflict.
    """
    try:
        statuses = self_heal.list_component_status()
    except Exception as e:
        logger.warning(
            "list_component_status() failed, treating compose stack as empty: %s",
            e,
            extra={"component": "ops"},
        )
        return {}
    return {s.service: s.state for s in statuses if s.source == "compose"}


def _terraform_or_kubernetes_managed_components() -> set[str]:
    """Service names `list_component_status()` currently reports as Terraform/Kubernetes-managed.

    `ops down`/`stop` (no `--terraform`/`--kubernetes` flag) mark api/web/
    ollama/cassandra intentionally stopped by service name, but only ever
    stop the native/Compose form of those services. If a Terraform/
    Kubernetes deployment is what's actually running, marking would flag it
    `desired=False` in `list_component_status()` even though neither this
    call nor its `_stop_*` helpers touched it -- silently blinding self-heal
    to a component that never went down. Returns an empty set (never
    raises) if the status lookup fails, so a lookup error never blocks the
    marking it would otherwise guard.
    """
    try:
        statuses = self_heal.list_component_status()
    except Exception as e:
        logger.warning(
            "list_component_status() failed, treating no components as "
            "Terraform/Kubernetes-managed: %s",
            e,
            extra={"component": "ops"},
        )
        return set()
    return {s.service for s in statuses if s.source in ("terraform", "kubernetes")}


def detect_deployment_mode() -> DeploymentMode:
    """Detect which deployment(s) are actually running: native vs. Docker Compose.

    `ops.py` otherwise assumes native-only (Homebrew services + one ops-managed
    Cassandra container). This cross-checks the Compose stack so `status`/`restart`
    can see -- and avoid colliding with -- a Compose deployment left running.
    """
    native = _native_services_snapshot()
    native["cassandra"] = _docker_container_state("nyxgpt-cassandra")

    compose = _compose_stack_snapshot()
    terraform = terraform_stack_state()

    conflicts = [
        component
        for component in COMPOSE_COMPONENT_PORTS
        if native.get(component) in ("started", "running") and compose.get(component) == "running"
    ]

    terraform_conflicts = [
        component
        for component in TERRAFORM_CONTAINERS
        if terraform.get(component) == "running"
        and (native.get(component) in ("started", "running") or compose.get(component) == "running")
    ]

    logger.debug(
        "ops: detected deployment mode (native=%s, compose=%s, terraform=%s, conflicts=%s, "
        "terraform_conflicts=%s)",
        native,
        compose,
        terraform,
        conflicts,
        terraform_conflicts,
        extra={
            "component": "ops",
            "action": "detect_deployment_mode",
            "native": native,
            "compose": compose,
            "terraform": terraform,
            "conflicts": conflicts,
            "terraform_conflicts": terraform_conflicts,
        },
    )
    if conflicts:
        logger.warning(
            "ops: native/Compose deployment conflict on %s -- both report running on the "
            "shared port",
            ", ".join(sorted(conflicts)),
            extra={"component": "ops", "action": "detect_deployment_mode", "conflicts": conflicts},
        )
    if terraform_conflicts:
        logger.warning(
            "ops: native/Compose and Terraform deployment stacks both running on %s -- an "
            "incomplete mode switch left two core stacks up",
            ", ".join(sorted(terraform_conflicts)),
            extra={
                "component": "ops",
                "action": "detect_deployment_mode",
                "terraform_conflicts": terraform_conflicts,
            },
        )

    return DeploymentMode(
        native=native,
        compose=compose,
        conflicts=conflicts,
        terraform=terraform,
        terraform_conflicts=terraform_conflicts,
    )


# --- Restart helpers ---


def _restart_brew_service(name: str) -> list[OpsResult]:
    """Restart Homebrew service `name` via `brew services restart`.

    Returns a single-element list: an OpsResult reporting brew missing, the
    restart command's success, or its failure with captured stdout/stderr.
    """
    if _which("brew") is None:
        return [OpsResult(False, f"brew not found; cannot restart {name}")]
    try:
        cp = _run(["brew", "services", "restart", name], check=False)
        if cp.returncode == 0:
            return [OpsResult(True, f"Restarted brew service: {name}")]
        details = _output_excerpt(cp)
        return [OpsResult(False, f"Failed to restart brew service: {name}", details.strip())]
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to restart brew service: {name}",
                f"{type(e).__name__}: {e}",
            )
        ]


def _restart_docker_container(name: str) -> list[OpsResult]:
    """Restart Docker container `name` via `docker restart`, with a start-back-up recovery attempt.

    If the container was running before the restart and `docker restart`
    leaves it stopped (e.g. a port collision on the start half), this makes
    one `docker start` attempt to bring it back up rather than silently
    leaving a previously healthy container down.

    Returns a single-element list of OpsResult describing success, a
    recovered restart failure, or an unrecovered "DOWN" failure.
    """
    if _which("docker") is None:
        return [OpsResult(False, f"docker not found; cannot restart {name}")]

    was_running = _docker_container_state(name) == "running"

    try:
        cp = _run(["docker", "restart", name], check=False)
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to restart docker container: {name}",
                f"{type(e).__name__}: {e}",
            )
        ]

    if cp.returncode == 0:
        return [OpsResult(True, f"Restarted docker container: {name}")]

    details = _output_excerpt(cp)

    if was_running and _docker_container_state(name) != "running":
        # `docker restart` stops then starts the container -- if the start half fails
        # (e.g. a port collision) the container is left stopped even though it was
        # healthy before. Try once to bring it back up rather than silently leaving a
        # previously-running container down with only a generic failure message.
        recovery = _run(["docker", "start", name], check=False)
        if recovery.returncode == 0 and _docker_container_state(name) == "running":
            return [
                OpsResult(
                    False,
                    f"Restart of {name} failed but the previously running container was recovered",
                    details.strip(),
                )
            ]
        return [
            OpsResult(
                False,
                f"DOWN: {name} failed to restart and is now STOPPED (recovery attempt also failed)",
                details.strip(),
            )
        ]

    return [OpsResult(False, f"Failed to restart docker container: {name}", details.strip())]


def _restart_launchagent(label: str) -> list[OpsResult]:
    """Restart the LaunchAgent `label` via `launchctl kickstart -k` in the current GUI domain.

    Returns a single-element list of OpsResult reporting success or failure
    (including any exception raised while invoking launchctl).
    """
    # Prefer a kickstart (restart) in the current GUI domain.
    domain = f"gui/{os.getuid()}/{label}"
    try:
        cp = _run(["launchctl", "kickstart", "-k", domain], check=False)
        if cp.returncode == 0:
            return [OpsResult(True, f"Restarted LaunchAgent: {label}")]
        details = _output_excerpt(cp)
        return [OpsResult(False, f"Failed to restart LaunchAgent: {label}", details.strip())]
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to restart LaunchAgent: {label}",
                f"{type(e).__name__}: {e}",
            )
        ]


def _find_launchagent_template(
    name: str = "com.nyxgpt.cassandra-logs.plist",
) -> tuple[Path | None, list[Path]]:
    """
    Locate a log-follower LaunchAgent template (by plist filename) among the
    packaged resources `_sync_packaged_resources` synced to
    `OPS_LAUNCHAGENTS_DIR`. Returns (path_or_none, candidates_checked).
    """
    candidates = [OPS_LAUNCHAGENTS_DIR / name]
    for p in candidates:
        try:
            if p.exists():
                return p, candidates
        except Exception as e:
            # If something odd happens (permissions, broken symlink), keep searching.
            logger.warning(
                "Could not check candidate path %s, skipping: %s",
                p,
                e,
                extra={"component": "ops"},
            )
            continue
    return None, candidates


def _install_launchagent_from_template(tpl: Path, dst: Path) -> None:
    """Render a LaunchAgent plist template to `dst`, substituting
    `LAUNCHAGENT_HOME_PLACEHOLDER` with the installing user's actual home
    directory so the installed plist works for whichever account runs
    `nyxgpt ops install`, not just the template's original author.
    """
    _ensure_dir(dst.parent)
    text = tpl.read_text(encoding="utf-8")
    text = text.replace(LAUNCHAGENT_HOME_PLACEHOLDER, str(Path.home()))
    dst.write_text(text, encoding="utf-8")


def _install_cassandra_launchagent() -> list[OpsResult]:
    """Install and (re)load the Cassandra log-follower LaunchAgent.

    Locates the synced plist template (see `_find_launchagent_template`), copies it into
    ~/Library/LaunchAgents, then boots it out and back in via `launchctl
    bootout`/`bootstrap`/`kickstart` so a stale prior load doesn't linger.
    Returns a single-element list of OpsResult; fails if the template can't
    be found among the candidate paths.
    """
    results: list[OpsResult] = []
    tpl, checked = _find_launchagent_template()
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing Cassandra logs LaunchAgent template", details))
        return results
    la_dir = Path.home() / "Library" / "LaunchAgents"
    _ensure_dir(la_dir)
    dst = la_dir / tpl.name
    _install_launchagent_from_template(tpl, dst)

    label = "com.nyxgpt.cassandra-logs"
    domain = f"gui/{os.getuid()}"

    _run(["launchctl", "bootout", domain, str(dst)], check=False, expected=True)
    _run(["launchctl", "bootstrap", domain, str(dst)], check=False)
    _run(["launchctl", "kickstart", "-k", f"{domain}/{label}"], check=False)

    results.append(OpsResult(True, "Installed Cassandra logs LaunchAgent", str(dst)))
    return results


def _install_ollama_launchagent() -> list[OpsResult]:
    """Install and (re)load the Ollama container-logs LaunchAgent (Compose mode).

    Mirrors `_install_cassandra_launchagent`: locates the plist template,
    copies it into ~/Library/LaunchAgents, then boots it out and back in via
    `launchctl bootout`/`bootstrap`/`kickstart`. Installed unconditionally by
    `nyxgpt ops install` regardless of deployment mode, same as the Cassandra
    LaunchAgent -- `follow-ollama-logs.sh` (which this LaunchAgent runs)
    handles both Compose mode (follows the `nyxgpt-ollama` container's
    `docker logs`) and native mode (tails Homebrew's own ollama.log
    directly), switching between them on its own (see #3441). Returns a
    single-element list of OpsResult; fails if the template can't be found
    among the candidate paths.
    """
    results: list[OpsResult] = []
    tpl, checked = _find_launchagent_template("com.nyxgpt.ollama-logs.plist")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing Ollama logs LaunchAgent template", details))
        return results
    la_dir = Path.home() / "Library" / "LaunchAgents"
    _ensure_dir(la_dir)
    dst = la_dir / tpl.name
    _install_launchagent_from_template(tpl, dst)

    label = "com.nyxgpt.ollama-logs"
    domain = f"gui/{os.getuid()}"

    _run(["launchctl", "bootout", domain, str(dst)], check=False, expected=True)
    _run(["launchctl", "bootstrap", domain, str(dst)], check=False)
    _run(["launchctl", "kickstart", "-k", f"{domain}/{label}"], check=False)

    results.append(OpsResult(True, "Installed Ollama logs LaunchAgent", str(dst)))
    return results


def _install_ollama_env_launchagent() -> list[OpsResult]:
    """Install and (re)load the Ollama shared-model-store env LaunchAgent (#3431).

    Mirrors `_install_ollama_launchagent`/`_install_cassandra_launchagent`:
    locates the `com.nyxgpt.ollama-env.plist` template, copies it into
    ~/Library/LaunchAgents, then boots it out and back in. That LaunchAgent
    runs `scripts/set-ollama-models-env.sh` (`launchctl setenv OLLAMA_MODELS
    ...`) at every login, since a bare `launchctl setenv` call (as done
    immediately by `_ensure_ollama_service`) only applies to the current
    session and would otherwise be lost on reboot. Returns a single-element
    list of OpsResult; fails if the template can't be found among the
    candidate paths.
    """
    results: list[OpsResult] = []
    tpl, checked = _find_launchagent_template("com.nyxgpt.ollama-env.plist")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing Ollama env LaunchAgent template", details))
        return results
    la_dir = Path.home() / "Library" / "LaunchAgents"
    _ensure_dir(la_dir)
    dst = la_dir / tpl.name
    _install_launchagent_from_template(tpl, dst)

    label = "com.nyxgpt.ollama-env"
    domain = f"gui/{os.getuid()}"

    _run(["launchctl", "bootout", domain, str(dst)], check=False, expected=True)
    _run(["launchctl", "bootstrap", domain, str(dst)], check=False)
    _run(["launchctl", "kickstart", "-k", f"{domain}/{label}"], check=False)

    results.append(OpsResult(True, "Installed Ollama env LaunchAgent", str(dst)))
    return results


_STALE_LOG_SYMLINK_NAMES: tuple[str, ...] = (
    "nyxgpt-api.log",
    "nyxgpt-api.err.log",
    "nyxgpt-web.log",
    "nyxgpt-web.err.log",
)


def _cleanup_stale_log_symlinks() -> list[OpsResult]:
    """Remove leftover ~/.nyxGPT/logs symlinks from the pre-#3441 symlink mechanism.

    A prior nyxgpt version's `_ensure_log_symlinks` pointed these names at
    Homebrew's var/log dir. That target lives outside ~/.nyxGPT/logs, which
    is all promtail's container actually bind-mounts, so those symlinks were
    never reachable from inside it and never shipped a single line to Loki
    (#3441) -- nyxgpt-api/nyxgpt-web's own structured logs already land
    directly in ~/.nyxGPT/logs as real files (`api.log`, see
    `nyxgpt.logging.configure_logging`), and Ollama's log now reaches
    ~/.nyxGPT/logs/ollama.log as a real file too, written by
    `follow-ollama-logs.sh` itself. Reconciles on every `nyxgpt ops install`
    so a leftover symlink from before this fix doesn't linger.

    Returns one OpsResult per name considered.
    """
    results: list[OpsResult] = []
    home_logs = Path.home() / ".nyxGPT" / "logs"
    for name in _STALE_LOG_SYMLINK_NAMES:
        dst = home_logs / name
        try:
            if dst.is_symlink():
                dst.unlink()
                results.append(OpsResult(True, f"Removed stale log symlink {name}", str(dst)))
            else:
                results.append(OpsResult(True, f"No stale log symlink for {name}"))
        except Exception as e:
            results.append(OpsResult(False, f"Failed to remove stale log symlink {name}", str(e)))
    return results


def _create_dist_tarball(
    tap_dir: Path, name: str, version: str, source_root: Path | None = None
) -> Path:
    """`nyxgpt.release_tarball._create_dist_tarball`, defaulted to *this* module's REPO_ROOT.

    The builder itself moved to the stdlib-only `nyxgpt.release_tarball`
    module (#3741) so release tooling can import it without this module's
    third-party dependencies. Every local install path here still calls it
    by its `ops.` name and expects "vendor from the checkout `ops.REPO_ROOT`
    points at", so the default is resolved here rather than there.
    """
    return release_tarball._create_dist_tarball(
        tap_dir, name, version, REPO_ROOT if source_root is None else source_root
    )


# --- Artifact install: the same service tarballs, published (#3759) -----
#
# The native installers below build each service from a
# `<name>-<version>.tar.gz` that `_create_dist_tarball` vendors out of the
# checkout. An artifact install (`pip install nyxgpt`, the repo-less
# portability requirement -- CLAUDE.md 2026-08-01) has no checkout to vendor
# from: `REPO_ROOT` resolves *inside* the installed venv
# (.../venv/lib/python3.11), where `src/nyxgpt`, `web/` and `pyproject.toml`
# do not exist. That is what broke `nyxgpt cloud deploy` on EC2 (#3759): the
# api install step died on `FileNotFoundError: .../lib/python3.11/src/nyxgpt`.
#
# The fix is not a second install recipe -- it is a second *source* for the
# very same tarball. Every release and release candidate attaches
# `nyxgpt-api-<version>.tar.gz` and `nyxgpt-web-<version>.tar.gz` to its
# GitHub Release (release-artifacts.yml's homebrew-tap job for a release,
# release-publish-pypi.yml's rc job for a candidate) -- byte-for-byte what
# `_create_dist_tarball` produces locally, and exactly what the published
# Homebrew formulas install from. So `_service_source_tarball` vendors from
# the checkout when there is one and downloads the published asset when
# there isn't; everything downstream (venv, pip install, npm build, wrapper,
# unit) is unchanged and shared by both paths.
#
# `{tag}` is the release the assets are *published on*, which is not always
# the release named by the version (#3763): a candidate carries its own
# tarballs, but a stable release is published before they are built and can
# never gain an asset afterwards, so its tarballs are served from the
# `<version>-homebrew` sidecar release. `_release_asset_urls` tries both, in
# that order, from `release_tarball.homebrew_asset_release_tag` -- the same
# definition `scripts/build_homebrew_artifacts.py` stamps the Homebrew
# formulas' `url` with.
RELEASE_ASSET_URL = (
    "https://github.com/dkblinux98/nyxGPT/releases/download/{tag}/{name}-{version}.tar.gz"
)


def _release_asset_urls(name: str, version: str) -> list[str]:
    """Every URL `<name>-<version>.tar.gz` may be published at, best first.

    The version's own release first -- where a release candidate's tarballs
    are, and where releases published before #3763 carry theirs -- then the
    `<version>-homebrew` sidecar the stable tarballs are published on now.
    """
    tags = [version, release_tarball.homebrew_asset_release_tag(version)]
    return [RELEASE_ASSET_URL.format(tag=tag, name=name, version=version) for tag in tags]


# The published Homebrew tap, macOS's artifact channel (docs/homebrew.md).
# Used when `nyxgpt ops install` runs on macOS from an artifact install: the
# local `file://` tap is built from a checkout, the remote one isn't.
REMOTE_TAP = "dkblinux98/nyxgpt"


def _has_vendorable_source(name: str) -> bool:
    """True when `REPO_ROOT` holds the source `_create_dist_tarball` vendors for `name`.

    Per service rather than one repo-wide "is this a checkout" flag,
    because that is exactly the granularity of the failure: the api tarball
    needs `pyproject.toml` + `src/nyxgpt/` + `example.config.ini`, the web
    tarball needs `web/`, and each installer only cares about its own.
    False means "artifact install" for that service -- see
    `_service_source_tarball`.
    """
    if name == "nyxgpt-web":
        return (REPO_ROOT / "web" / "package.json").is_file()
    return (REPO_ROOT / "src" / "nyxgpt").is_dir() and (REPO_ROOT / "pyproject.toml").is_file()


def _installed_distribution_version() -> str | None:
    """Version of the installed `nyxgpt` distribution, or None if it isn't installed."""
    try:
        return importlib.metadata.version("nyxgpt")
    except importlib.metadata.PackageNotFoundError:  # pragma: no cover - source tree only
        return None


def _native_service_version() -> str:
    """The version the native `api`/`web` services are installed at.

    A dev checkout answers with the checkout's declared `pyproject.toml`
    version, so a version bump is picked up with no reinstall (the reason
    `_read_project_version` reads the file rather than package metadata).
    An artifact install has no `pyproject.toml` above the package -- where
    `_read_project_version` would answer its deliberately implausible
    "0.0.0" -- so the installed distribution's metadata version answers
    instead. That is the release whose published tarballs
    `_download_release_tarball` fetches, which keeps the services on the
    same release as the `nyxgpt` that installed them.
    """
    if (REPO_ROOT / "pyproject.toml").is_file():
        return _read_project_version()
    return _installed_distribution_version() or _read_project_version()


def _download_release_tarball(dest_dir: Path, name: str, version: str) -> Path:
    """Download the published `<name>-<version>.tar.gz` release asset into `dest_dir/dist`.

    Mirrors `_create_dist_tarball`'s contract -- same filename, same
    `dist/` location, same returned path -- so the callers can't tell which
    source produced the tarball. Downloads to a temp path and `replace()`s
    it into position, so an interrupted download can never leave a
    truncated archive behind for the next run to install from (the same
    reason `_download_tool_binary` does it).

    Tries every release the asset may be published on (`_release_asset_urls`
    -- the version's own release, then its `<version>-homebrew` sidecar), so
    a stable version whose release could not take the assets still installs.

    Raises RuntimeError with the URLs tried and the last underlying error
    when the asset can't be fetched anywhere -- the caller turns that into an
    OpsResult rather than letting a traceback stand in for a diagnosis.
    """
    dist_dir = dest_dir / "dist"
    _ensure_dir(dist_dir)
    tar_path = dist_dir / f"{name}-{version}.tar.gz"
    tmp = dist_dir / f".{name}-{version}.download"
    urls = _release_asset_urls(name, version)
    last_error: Exception | None = None
    for url in urls:
        try:
            with httpx.stream("GET", url, follow_redirects=True, timeout=300.0) as resp:
                resp.raise_for_status()
                with tmp.open("wb") as fh:
                    for chunk in resp.iter_bytes():
                        fh.write(chunk)
            tmp.replace(tar_path)
        except (httpx.HTTPError, OSError) as e:
            # Never leave a truncated archive behind for the next candidate
            # URL -- or the next run -- to install from.
            with contextlib.suppress(OSError):
                tmp.unlink(missing_ok=True)
            last_error = e
            continue
        return tar_path
    raise RuntimeError(
        f"Could not download the published {name} {version} artifact from "
        f"{' or '.join(urls)} ({type(last_error).__name__}: {last_error}). Check network "
        f"access to github.com, and that {version} is a published release or release "
        "candidate."
    ) from last_error


def _service_source_tarball(dest_dir: Path, name: str, version: str) -> Path:
    """Return the `<name>-<version>.tar.gz` a native installer builds `name` from.

    Vendored from the checkout when one is present (the dev path, byte-for-
    byte as before), downloaded from the published GitHub Release asset when
    it isn't (the artifact path, #3759). Raises RuntimeError if the artifact
    can't be obtained.
    """
    if _has_vendorable_source(name):
        return _create_dist_tarball(dest_dir, name, version)
    return _download_release_tarball(dest_dir, name, version)


def _remote_tap_formula(name: str, version: str) -> str:
    """The published tap's formula name for `name` at `version`.

    Stable releases keep the plain name (`nyxgpt-api`); a release candidate
    is published as its release line's candidate formula
    (`3.0.0rc5` -> `nyxgpt-api@3.0.0rc`), so the two channels can coexist in
    one tap without `brew install nyxgpt-api` ever resolving to a candidate
    -- see docs/homebrew.md#candidate-channel and
    `scripts/build_homebrew_artifacts.py`'s `formula_name`.
    """
    line, marker, _candidate = version.partition("rc")
    return f"{name}@{line}rc" if marker else name


def _install_from_remote_tap(name: str) -> list[OpsResult]:
    """Install `name` from the published Homebrew tap and (re)start its service.

    macOS's artifact-install path (#3759): `_install_homebrew_api`/`_web`
    build a local `file://` tap out of the checkout, which an artifact
    install doesn't have. The remote tap carries the same formulas built
    from the same tarballs, so this is the identical install recipe with a
    published source -- the documented macOS install
    (docs/homebrew.md#install), run for the operator instead of handed to
    them.
    """
    if _which("brew") is None:
        return [OpsResult(False, "Homebrew not found", "")]

    version = _native_service_version()
    formula = _remote_tap_formula(name, version)
    spec = f"{REMOTE_TAP}/{formula}"

    cp = _run(["brew", "tap", REMOTE_TAP], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, f"Failed to tap {REMOTE_TAP}", _cp_details(cp))]
    # Homebrew gates formulas from third-party taps: without trust, `brew
    # install` stops instead of installing (#3752). Trust the tap, never one
    # formula -- installing a candidate resolves its `conflicts_with` against
    # the stable formula, which brew then has to load too, and a per-formula
    # grant does not cover it (#3770). The subcommand is spelled `tap-trust`
    # on some Homebrews and `trust` on others, so try both. Tolerated on
    # failure -- Homebrew builds predating the trust gate have nothing to
    # trust.
    if _run(["brew", "tap-trust", REMOTE_TAP], check=False, expected=True).returncode != 0:
        _run(["brew", "trust", REMOTE_TAP], check=False, expected=True)

    cp = _run(["brew", "install", spec], check=False)
    if cp.returncode != 0:
        # An already-installed formula that the tap has since moved on from
        # is an upgrade, not an install, and brew says so rather than doing
        # it -- so try that before reporting a failure.
        cp_upgrade = _run(["brew", "upgrade", spec], check=False)
        if cp_upgrade.returncode != 0:
            return [
                OpsResult(
                    False,
                    f"Failed to install {spec} from the published tap",
                    f"{_cp_details(cp)}\n{_cp_details(cp_upgrade)}",
                )
            ]

    detail = f"version {version}"
    if formula != name:
        # brew names a service after its formula, so a candidate keg's
        # service is `nyxgpt-api@3.0.0rc`, not `nyxgpt-api` -- which is what
        # `nyxgpt ops status` and the self-heal watchdog look for.
        detail += (
            f"\nCandidate channel: the service is named {formula} after its formula, "
            "so `nyxgpt ops status` (which tracks the stable service names) reports "
            "this component as not running. See docs/homebrew.md#candidate-channel."
        )
    results = [OpsResult(True, f"Installed {formula} from {REMOTE_TAP}", detail)]
    results.extend(_restart_brew_service(formula))
    return results


def _brew_install_or_reinstall(spec: str, name: str, *, sha256: str, marker_dir: Path) -> str:
    """`brew install`/`reinstall` formula `name`, skipping the work when unchanged.

    Compares the just-built tarball's `sha256` against the one recorded the
    last time this formula was actually installed (`marker_dir/.<name>.sha256`).
    If the formula is already installed and the checksum matches, the source
    hasn't changed since the last install: skip the `brew fetch`/`install`
    round-trip entirely. Otherwise (not installed yet, or the checksum
    changed -- a new/edited source tree), fetch and install/reinstall, then
    record the new checksum. The `fetch --force` refreshes brew's download
    cache first: the tarball URL and version are constant across runs, so
    without it brew would reinstall from a stale cached tarball and fail the
    formula's sha256 check.

    Returns a short human-readable string describing which of the three
    decisions was made ("installed" / "reinstalled (source changed)" /
    "already up to date (skipped)"), for the caller to report.
    """
    installed = (
        _run(["brew", "list", "--versions", name], check=False, expected=True).returncode == 0
    )
    marker = marker_dir / f".{name}.sha256"
    previous_sha256 = marker.read_text(encoding="utf-8").strip() if marker.exists() else None

    if installed and previous_sha256 == sha256:
        return "already up to date (skipped reinstall)"

    _run(["brew", "fetch", "--force", spec], check=False)
    if installed:
        cp = _run(["brew", "reinstall", spec], check=False)
        action, decision = "reinstall", "reinstalled (source changed since last install)"
    else:
        cp = _run(["brew", "install", "--overwrite", spec], check=False)
        action, decision = "install", "installed"

    if cp.returncode != 0:
        # Surface the failure instead of reporting a false success, and do NOT
        # record the checksum: writing the marker on a failed build would make
        # the next run see a matching checksum and skip, so the broken install
        # would never be retried (the bug that let a failed api keg rebuild
        # report "reinstalled" and then stick as a stale wrapper).
        detail = _output_excerpt(cp)
        raise RuntimeError(f"brew {action} {name} failed: {detail}")

    _ensure_dir(marker_dir)
    marker.write_text(sha256, encoding="utf-8")
    return decision


# Where `_docker_build_if_needed` records the sha256 fingerprint of the source
# an image was last built from (`.<image>.sha256`, image name/tag sanitized) --
# the Docker-image analogue of `_tap_repo(tap) / "dist"` for the Homebrew
# markers `_brew_install_or_reinstall` reads/writes.
DOCKER_IMAGE_MARKER_DIR = Path.home() / ".nyxGPT" / "docker-images"


def _hash_paths(paths: list[Path], *, excludes: frozenset[str] = frozenset()) -> str:
    """sha256 fingerprint over the file contents under `paths` (files or directories).

    Walks each directory deterministically (sorted, skipping any dir named in
    `excludes` -- e.g. `_WEB_VENDOR_EXCLUDES`), hashing every file's path
    relative to its base plus its bytes, so the digest changes iff the
    content or layout under `paths` actually changed. Used by
    `_docker_build_if_needed` to detect source changes for the app the
    image is built from -- the Docker-image equivalent of `_sha256_file`
    over `_create_dist_tarball`'s vendored tarball.
    """
    digest = hashlib.sha256()
    for base in sorted(paths, key=str):
        if base.is_file():
            digest.update(f"{base.name}\0".encode())
            digest.update(base.read_bytes())
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(n for n in dirnames if n not in excludes)
            for fname in sorted(filenames):
                fpath = Path(dirpath) / fname
                rel = fpath.relative_to(base)
                digest.update(f"{base.name}/{rel}\0".encode())
                digest.update(fpath.read_bytes())
    return digest.hexdigest()


def _docker_build_if_needed(
    image: str,
    context: Path,
    *,
    fingerprint_paths: list[Path],
    excludes: frozenset[str] = frozenset(),
    build_args: dict[str, str] | None = None,
    marker_dir: Path,
) -> str:
    """`docker build -t image context`, skipping the work when the source hasn't changed.

    Mirrors `_brew_install_or_reinstall` (#3406) for the Docker/terraform
    image build sites (#3414). Compares a sha256 fingerprint of
    `fingerprint_paths` -- the actual app source the image is built from
    (e.g. `src/nyxgpt/` + `pyproject.toml` for `nyxgpt-api`, `web/` for
    `nyxgpt-web`), not the whole build context -- against the one recorded
    the last time `image` was actually built (`marker_dir/.<image>.sha256`,
    name/tag sanitized). If `image` already exists locally and the
    fingerprint matches, the source hasn't changed since the last build:
    skip `docker build` entirely. Otherwise (image missing, or the
    fingerprint changed -- a new/edited source tree), run the build and
    record the new fingerprint.

    Returns a short human-readable string describing which of the three
    decisions was made ("built" / "rebuilt (source changed since last
    build)" / "already up to date (skipped rebuild)"), for the caller to
    report.
    """
    marker_name = re.sub(r"[^A-Za-z0-9_.-]", "_", image)
    marker = marker_dir / f".{marker_name}.sha256"
    previous_fingerprint = marker.read_text(encoding="utf-8").strip() if marker.exists() else None
    fingerprint = _hash_paths(fingerprint_paths, excludes=excludes)

    image_exists = (
        _run(["docker", "image", "inspect", image], check=False, expected=True).returncode == 0
    )
    if image_exists and previous_fingerprint == fingerprint:
        return "already up to date (skipped rebuild)"

    cmd = ["docker", "build", "-t", image]
    for arg_name, arg_value in (build_args or {}).items():
        cmd += ["--build-arg", f"{arg_name}={arg_value}"]
    cmd.append(str(context))
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        # As with `_brew_install_or_reinstall`: surface the failure and do NOT
        # record the fingerprint, so a broken build doesn't get skipped (and
        # so stick as a stale image) on the next run.
        detail = _output_excerpt(cp)
        raise RuntimeError(f"docker build {image} failed: {detail}")

    _ensure_dir(marker_dir)
    marker.write_text(fingerprint, encoding="utf-8")
    return "built" if previous_fingerprint is None else "rebuilt (source changed since last build)"


# The app source `nyxgpt-api`'s image is built from -- COPY'd into the
# Dockerfile (pyproject.toml, src/nyxgpt/, example.config.ini) plus the
# entrypoint script it also COPYs -- not the whole build context, so an
# unrelated repo-root change (docs, terraform/, etc.) doesn't force a rebuild.
_API_IMAGE_FINGERPRINT_PATHS = [
    REPO_ROOT / "src" / "nyxgpt",
    REPO_ROOT / "pyproject.toml",
    REPO_ROOT / "example.config.ini",
    REPO_ROOT / "docker" / "entrypoint.sh",
]


def _install_homebrew_api(tap: str = "dkblinux98/nyxgpt-local") -> list[OpsResult]:
    """Build and install the `nyxgpt-api` Homebrew formula into `tap`, then (re)start the service.

    Generates a dist tarball vendoring `pyproject.toml` + `src/nyxgpt/`,
    patches the formula template's `sha256` to match it, writes the formula
    into the tap's Formula/ dir, and installs/reinstalls it only if the
    vendored source actually changed since the last install (see
    `_brew_install_or_reinstall`). The formula itself builds a self-contained
    venv inside the Cellar keg from that vendored source -- the installed app
    never depends on the repo checkout or an editable `.venv` (#3406).

    When a rebuild actually happened (`decision` is "installed" or
    "reinstalled ..."), this restarts the service (`brew services restart`)
    instead of just starting it: `brew services start` on an already-running
    service is a no-op, so a code fix landing while the API is still running
    would otherwise leave the *old* in-memory process serving requests
    against the new keg's on-disk source forever -- silently undoing the fix
    (#3472, mirrors the `nyxgpt-web` fix in #3445). When nothing changed, a
    plain `start` is used so an already-up-to-date install doesn't bounce a
    healthy running service. Returns a list of OpsResult; fails early if brew
    isn't installed or the formula template is missing.
    """
    results: list[OpsResult] = []
    if _which("brew") is None:
        return [OpsResult(False, "Homebrew not found", "")]

    template = REPO_ROOT / "homebrew" / "nyxgpt-api.rb"
    if not template.exists():
        # No checkout to build a local tap from -- an artifact install
        # (`pip install nyxgpt`) installs the published formula instead of
        # failing on a missing template (#3759).
        return _install_from_remote_tap("nyxgpt-api")

    tap_dir = _tap_repo(tap)
    version = _read_project_version()

    tar = _create_dist_tarball(tap_dir, "nyxgpt-api", version)
    sha = _sha256_file(tar)

    content = template.read_text(encoding="utf-8")
    # Stamp the template's __VERSION__/__SHA256__ placeholders with the real
    # values for the tarball just generated. The regex substitutions remain as
    # a safety net for any formula copy that still carries concrete (stale)
    # values instead of placeholders.
    content = content.replace("__VERSION__", version)
    content = content.replace("__SHA256__", sha)
    content = re.sub(r'sha256 "[a-f0-9]+"', f'sha256 "{sha}"', content)
    content = re.sub(r'version "[^"]+"', f'version "{version}"', content)
    content = re.sub(r"nyxgpt-api-[^\"/]+\.tar\.gz", f"nyxgpt-api-{version}.tar.gz", content)

    formula_dir = tap_dir / "Formula"
    _ensure_dir(formula_dir)
    dst = formula_dir / "nyxgpt-api.rb"
    dst.write_text(content, encoding="utf-8")
    results.append(OpsResult(True, "Installed nyxgpt-api formula", str(dst)))

    decision = _brew_install_or_reinstall(
        f"{tap}/nyxgpt-api", "nyxgpt-api", sha256=sha, marker_dir=tap_dir / "dist"
    )
    if decision == "already up to date (skipped reinstall)":
        _run(["brew", "services", "start", "nyxgpt-api"], check=False)
        results.append(OpsResult(True, f"nyxgpt-api: {decision}; requested service start", ""))
    else:
        # A new keg was just installed -- restart, not start, so the running
        # process actually picks it up instead of continuing to serve the
        # old build's code (#3472).
        results.append(OpsResult(True, f"nyxgpt-api: {decision}", ""))
        results.extend(_restart_brew_service("nyxgpt-api"))

    return results


def _install_homebrew_web(tap: str = "dkblinux98/nyxgpt-local") -> list[OpsResult]:
    """Build and install the `nyxgpt-web` Homebrew formula into `tap`, then (re)start the service.

    Generates a dist tarball vendoring the `web/` source tree (minus
    gitignored build artifacts -- see `_WEB_VENDOR_EXCLUDES`), substitutes
    its `file://` URL and sha256 into the formula template, writes the
    formula into the tap's Formula/ dir, and installs/reinstalls it only if
    the vendored source actually changed since the last install (see
    `_brew_install_or_reinstall`). The formula itself runs `npm ci`/`npm run
    build` inside the Cellar keg from that vendored source -- the installed
    app never depends on the repo checkout (#3406).

    When a rebuild actually happened (`decision` is "installed" or
    "reinstalled ..."), this restarts the service (`brew services restart`)
    instead of just starting it: `brew services start` on an already-running
    service is a no-op, so a rebuild-while-serving would otherwise leave the
    old `next start` process running against the *old* in-memory build
    manifest while the on-disk `.next` chunks are already the new build's --
    every served page then references chunk hashes that no longer exist,
    404ing (#3445). When nothing changed, a plain `start` is used so an
    already-up-to-date install doesn't bounce a healthy running service.

    Returns a list of OpsResult; fails early if brew isn't installed or the
    formula template is missing.
    """
    results: list[OpsResult] = []
    if _which("brew") is None:
        return [OpsResult(False, "Homebrew not found", "")]

    template = REPO_ROOT / "homebrew" / "nyxgpt-web.rb"
    if not template.exists():
        # Artifact install -- see `_install_homebrew_api` above (#3759).
        return _install_from_remote_tap("nyxgpt-web")

    tap_dir = _tap_repo(tap)
    version = _read_project_version()

    tar = _create_dist_tarball(tap_dir, "nyxgpt-web", version)
    sha = _sha256_file(tar)
    url = f"file://{tar}"

    content = template.read_text(encoding="utf-8")
    content = content.replace("__NYXGPT_WEB_URL__", url)
    content = content.replace("__NYXGPT_WEB_SHA256__", sha)
    content = content.replace("__VERSION__", version)
    content = re.sub(r'version "[^"]+"', f'version "{version}"', content)

    formula_dir = tap_dir / "Formula"
    _ensure_dir(formula_dir)
    dst = formula_dir / "nyxgpt-web.rb"
    dst.write_text(content, encoding="utf-8")
    results.append(OpsResult(True, "Installed nyxgpt-web formula", str(dst)))

    decision = _brew_install_or_reinstall(
        f"{tap}/nyxgpt-web", "nyxgpt-web", sha256=sha, marker_dir=tap_dir / "dist"
    )
    if decision == "already up to date (skipped reinstall)":
        _run(["brew", "services", "start", "nyxgpt-web"], check=False)
        results.append(OpsResult(True, f"nyxgpt-web: {decision}; requested service start", ""))
    else:
        # A new keg (and new `.next` build output) was just installed --
        # restart, not start, so the running process actually picks it up
        # instead of continuing to serve the old build's chunk manifest.
        results.append(OpsResult(True, f"nyxgpt-web: {decision}", ""))
        results.extend(_restart_brew_service("nyxgpt-web"))

    return results


# Keys in the derived container api-config that must be rewritten from their
# native (localhost) values to container-network values. Everything else --
# models, RAG tuning, secrets, and the browser-facing *_ui_url values -- is
# copied verbatim from ~/.nyxGPT/config.ini (the single source of truth); only
# service-to-service endpoints change inside the container network. Terraform
# gives its containers matching network aliases (cassandra/ollama/...) so these
# same hostnames resolve under `nyxgpt ops install --terraform --local`.
_COMPOSE_CONFIG_OVERRIDES: tuple[tuple[str, str, str], ...] = (
    ("nyxgpt", "sessions_dir", "/root/.nyxGPT/sessions"),
    ("nyxgpt", "vectorstore_dir", "/root/.nyxGPT/vectorstore"),
    ("logging", "dir", "/root/.nyxGPT/logs"),
    ("ollama", "base_url", "http://ollama:11434"),
    ("rag", "cassandra_hosts", "cassandra"),
    ("tracing", "otlp_endpoint", "http://otel-collector:4318/v1/traces"),
    ("api", "host", "0.0.0.0"),
    # NOTE: auth is intentionally NOT overridden. The `--local` deploy is
    # loopback-only (NYXGPT_BIND_ADDR defaults to 127.0.0.1) and container
    # traffic stays on the private docker network, so it mirrors the native
    # local-first setup -- auth follows the real config. If the user has
    # `[auth] enabled = true` + an api_key natively, that carries over; if it's
    # disabled (the local default), forcing it on would just reject the web's
    # own requests (it has no matching key), which is the 401/500 we hit.
)


def _generate_compose_config() -> list[OpsResult]:
    """Generate the git-ignored `docker/config.docker.ini` from the native
    `~/.nyxGPT/config.ini` (the single source of truth).

    The containerized deploys -- the observability Compose profiles and the
    terraform/kubernetes `--local` core stack -- bind-mount this file as the
    api container's `config.ini`. Rather than maintain a separate hand-edited
    file, derive it from the real local config so the container runs the
    user's actual settings, rewriting only the service-network endpoints that
    must differ inside the container network (`_COMPOSE_CONFIG_OVERRIDES`). The
    browser-facing `*_ui_url` values stay `localhost` -- they're opened from
    the host, not container-internal.

    Regenerated on every `nyxgpt ops install`/`env-sync` so native edits
    propagate. Comments and unlisted keys survive verbatim (the rewrite is
    line-based via `_patch_ini_value`). The DSN `nyxgpt ops glitchtip-init`
    writes into the native config also carries over, but -- unlike every
    other unlisted key -- it isn't copied verbatim: its host:port is rewritten
    for the container network the same way `_COMPOSE_CONFIG_OVERRIDES` rewrites
    `ollama`/`cassandra` (see `_containerized_error_tracking_dsn`), because a
    containerized api using the native, browser-facing `localhost` DSN
    silently drops every event (#3565). It can't be a static entry in
    `_COMPOSE_CONFIG_OVERRIDES` because the value carries a per-install secret
    key, not a fixed constant.

    No-ops (successfully) before `nyxgpt wizard` has created the native config.
    """
    native = Path.home() / ".nyxGPT" / "config.ini"
    if not native.exists():
        return [
            OpsResult(
                True,
                f"Skipped compose config (no {native})",
                "Run `nyxgpt wizard` to create config.ini, then re-run `nyxgpt ops install`.",
            )
        ]
    try:
        text = native.read_text(encoding="utf-8")
        for section, key, value in _COMPOSE_CONFIG_OVERRIDES:
            text = _patch_ini_value(text, section, key, value)
        try:
            dsn_parser = ConfigParser()
            dsn_parser.optionxform = str  # type: ignore[assignment]
            dsn_parser.read_string(text)
            native_dsn = dsn_parser.get("error_tracking", "dsn", fallback="").strip()
        except Exception as e:
            logger.warning(
                "Failed to parse %s while rewriting the error-tracking DSN for "
                "the container network, leaving it unrewritten: %s",
                native,
                e,
                extra={"component": "ops"},
            )
            native_dsn = ""
        if native_dsn:
            text = _patch_ini_value(
                text, "error_tracking", "dsn", _containerized_error_tracking_dsn(native_dsn)
            )
        COMPOSE_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        COMPOSE_CONFIG_FILE.write_text(text, encoding="utf-8")
        # Copied verbatim from native config.ini above (see docstring): carries
        # [auth] api_key / [monitoring] grafana_admin_password when set, same
        # secret-bearing content as the native file, so it gets the same 0600.
        os.chmod(COMPOSE_CONFIG_FILE, 0o600)
    except OSError as e:
        return [
            OpsResult(
                False,
                f"Failed to generate {COMPOSE_CONFIG_FILE}",
                f"{type(e).__name__}: {e}",
            )
        ]
    return [OpsResult(True, f"Generated {COMPOSE_CONFIG_FILE} from {native}")]


def _shared_ollama_models_dir() -> Path:
    """Path native Ollama's `OLLAMA_MODELS` must point at to read the same
    models as Compose/Terraform (#3431).

    Ollama's `OLLAMA_MODELS` env var names a directory holding `blobs/` and
    `manifests/` directly (its default is `~/.ollama/models`, which has that
    layout). The shared `~/.nyxGPT/volumes/ollama` dir is bind-mounted to
    `/root/.ollama` in the Compose/Terraform `ollama` containers, which -- not
    having `OLLAMA_MODELS` overridden themselves -- store models at the
    container-default `/root/.ollama/models`, i.e. host
    `~/.nyxGPT/volumes/ollama/models`. Pointing native `OLLAMA_MODELS` at that
    same subdirectory (rather than its `~/.nyxGPT/volumes/ollama` parent)
    is what actually unifies the two stores.
    """
    d = volume_dir("ollama") / "models"
    _ensure_dir(d)
    return d


def _ollama_migration_state_path(name: str) -> Path:
    """Path to a `~/.nyxGPT/.migration-state/` marker for a one-time Ollama
    unification step (#3431) -- mirrors `_migration_marker_path`'s pattern so
    later `nyxgpt ops install` runs skip work already done rather than
    re-touching it (merged models, an already-applied env restart, ...).
    """
    state_dir = Path.home() / ".nyxGPT" / ".migration-state"
    _ensure_dir(state_dir)
    return state_dir / name


def _migrate_native_ollama_models(dest_models_dir: Path) -> list[OpsResult]:
    """One-time merge of native Ollama's own store (`~/.ollama/models`) into
    the shared `dest_models_dir`, so pointing native Ollama at the shared
    store doesn't silently orphan models already pulled natively before this
    unification (#3431).

    Additive merge, not overwrite: blobs are content-addressed by sha256
    digest (so an existing blob at the destination is always identical to
    the source one) and manifests take the destination's copy as
    authoritative on conflict -- the shared store is what Compose/Terraform
    already use, so it wins. Idempotent via a marker file, mirroring
    `migrate_legacy_volumes`. Merges via hardlink (falling back to a real
    copy if source and dest are on different filesystems), since blobs can
    be multi-GB and both paths are normally under the same `$HOME`.
    """
    marker = _ollama_migration_state_path("ollama-native-models.migrated")
    if marker.exists():
        return [OpsResult(True, "Native Ollama models: already reconciled (nothing to migrate)")]

    src_dir = Path.home() / ".ollama" / "models"
    if not src_dir.exists():
        marker.touch()
        return [OpsResult(True, "No native Ollama model store found (nothing to migrate)")]

    copied = 0
    for src_file in src_dir.rglob("*"):
        if not src_file.is_file():
            continue
        dst_file = dest_models_dir / src_file.relative_to(src_dir)
        if dst_file.exists():
            continue
        _ensure_dir(dst_file.parent)
        try:
            # Source and dest are normally both under $HOME on the same
            # filesystem, so a hardlink is instant and uses no extra disk
            # for what can be multi-GB blobs -- falls back to a real copy
            # for the (e.g. custom OLLAMA volume elsewhere) cross-device case.
            os.link(src_file, dst_file)
        except OSError:
            _copy_file(src_file, dst_file)
        copied += 1

    marker.touch()
    if copied:
        return [
            OpsResult(
                True,
                f"Merged {copied} native Ollama model file(s) into the shared store",
                f"Source: {src_dir}\nDest: {dest_models_dir}\n"
                f"The old {src_dir} files were left in place -- safe to remove by hand "
                "once you've confirmed the shared store has everything you need.",
            )
        ]
    return [OpsResult(True, "Native Ollama model store already matched the shared store")]


def _set_native_ollama_models_env(models_dir: Path) -> OpsResult:
    """Point native Ollama at `models_dir` via `launchctl setenv OLLAMA_MODELS`
    -- never a symlink (owner constraint, #3431) -- so `brew services
    start`/`restart ollama` picks it up in the user's launchd GUI session.

    `launchctl setenv` only applies to the current login session, which is
    why `nyxgpt ops install` also installs a RunAtLoad LaunchAgent
    (`_install_ollama_env_launchagent`) that reapplies it at every login.
    """
    cp = _run(["launchctl", "setenv", "OLLAMA_MODELS", str(models_dir)], check=False)
    if cp.returncode == 0:
        return OpsResult(True, f"Set OLLAMA_MODELS={models_dir} for native Ollama")
    details = _output_excerpt(cp)
    return OpsResult(False, "Failed to set OLLAMA_MODELS via launchctl setenv", details.strip())


def _ensure_ollama_service() -> list[OpsResult]:
    """Ensure the native Ollama Homebrew service is installed, running, and
    pointed at the shared model store.

    Reconciles to the intended state like `_ensure_cassandra_container`:
    already started (and already pointed at the shared store) -> no-op;
    installed but stopped -> `brew services start`; formula absent -> `brew
    install ollama` first, then start. Without this step, `ops install` only
    set up the Ollama *logs* LaunchAgent and never started Ollama itself, so
    chat/embeddings stayed down after an `ops down` until a manual `ops
    restart ollama`.

    Also unifies the native model store with Compose/Terraform's shared one
    (#3431): merges any models already pulled natively into
    `~/.nyxGPT/volumes/ollama/models`, then points native Ollama at it via
    `launchctl setenv OLLAMA_MODELS` (see `_set_native_ollama_models_env`).
    An already-running service doesn't pick up a `launchctl setenv` change on
    its own, so the first time this runs against a live service it issues a
    one-time `brew services restart` -- gated by a marker so later runs stay
    a no-op, same as every other reconciler here.
    """
    if _which("brew") is None:
        return [OpsResult(False, "Homebrew not found; cannot ensure ollama service", "")]

    results: list[OpsResult] = []
    models_dir = _shared_ollama_models_dir()
    results.extend(_migrate_native_ollama_models(models_dir))

    env_marker = _ollama_migration_state_path("ollama-native-env.configured")
    env_already_applied = env_marker.exists()
    env_result = _set_native_ollama_models_env(models_dir)
    results.append(env_result)
    if env_result.ok:
        env_marker.touch()

    state = _brew_services_snapshot().get("ollama")

    if state == "started":
        if env_already_applied:
            results.append(OpsResult(True, "Ollama brew service already running"))
            return results
        cp = _run(["brew", "services", "restart", "ollama"], check=False)
        if cp.returncode == 0:
            results.append(
                OpsResult(True, "Restarted brew service: ollama (to pick up shared OLLAMA_MODELS)")
            )
        else:
            details = _output_excerpt(cp)
            results.append(
                OpsResult(False, "Failed to restart brew service: ollama", details.strip())
            )
        return results

    if state is None:
        cp = _run(["brew", "install", "ollama"], check=False)
        if cp.returncode != 0:
            details = _output_excerpt(cp)
            results.append(OpsResult(False, "Failed to brew install ollama", details.strip()))
            return results
        results.append(OpsResult(True, "Installed ollama formula"))

    cp = _run(["brew", "services", "start", "ollama"], check=False)
    if cp.returncode == 0:
        results.append(OpsResult(True, "Started brew service: ollama"))
    else:
        details = _output_excerpt(cp)
        results.append(OpsResult(False, "Failed to start brew service: ollama", details.strip()))
    return results


# --- Linux native (systemd) install (#3508) ---
#
# Linux twin of the Homebrew-services + launchd section above. There's no
# Homebrew Cellar to build inside, so `_install_native_api_systemd`/
# `_install_native_web_systemd` create their own self-contained install roots
# under ~/.nyxGPT/opt/<component> (a plain venv for the api, a built `web/`
# tree for the web UI) instead -- reusing `_create_dist_tarball` (already
# OS-agnostic: it just vendors source into a tarball) rather than duplicating
# it. `ollama` is managed as its own systemd --user unit (`nyxgpt-ollama.service`)
# so every native component is reachable through the same `systemctl --user`
# surface -- including on a host where the distro's system-wide
# `ollama.service` holds port 11434, which install disables to free it (#3632).


def _systemd_user_dir() -> Path:
    """Return `~/.config/systemd/user`, the systemd --user unit search path."""
    return Path.home() / ".config" / "systemd" / "user"


def _find_systemd_unit_template(name: str) -> tuple[Path | None, list[Path]]:
    """Locate a systemd unit template (by filename) among the packaged
    resources `_sync_packaged_resources` synced to `OPS_SYSTEMD_TEMPLATES_DIR`.

    Mirrors `_find_launchagent_template`'s search strategy. Returns
    (path_or_none, candidates_checked).
    """
    candidates = [OPS_SYSTEMD_TEMPLATES_DIR / name]
    for p in candidates:
        try:
            if p.exists():
                return p, candidates
        except Exception as e:
            logger.warning(
                "Could not check candidate path %s, skipping: %s",
                p,
                e,
                extra={"component": "ops"},
            )
            continue
    return None, candidates


def _install_systemd_unit_from_template(
    tpl: Path, dst: Path, *, substitutions: dict[str, str] | None = None
) -> None:
    """Render a systemd unit template to `dst`.

    Substitutes `LAUNCHAGENT_HOME_PLACEHOLDER` (the same `__NYXGPT_HOME__`
    placeholder the launchd plist templates use) with the installing user's
    actual home directory, plus any unit-specific `substitutions` (e.g. the
    resolved `ollama` binary path for nyxgpt-ollama.service).
    """
    _ensure_dir(dst.parent)
    text = tpl.read_text(encoding="utf-8")
    text = text.replace(LAUNCHAGENT_HOME_PLACEHOLDER, str(Path.home()))
    for placeholder, value in (substitutions or {}).items():
        text = text.replace(placeholder, value)
    dst.write_text(text, encoding="utf-8")


def _reload_and_activate_systemd_unit(unit: str) -> list[OpsResult]:
    """`daemon-reload`, enable, then restart (or start) a systemd --user unit.

    Mirrors the launchd installers' bootout+bootstrap+kickstart pattern: a
    changed unit file must be reloaded before systemd picks it up, `enable`
    makes it start at every login (the launchd RunAtLoad equivalent), and
    `restart` (rather than `start`) ensures a just-rebuilt venv/web bundle is
    actually picked up instead of leaving an already-running process serving
    stale code -- `systemctl restart` on a unit that isn't running yet is
    equivalent to `start` (mirrors the brew-service restart-vs-start fix from
    #3472/#3445).
    """
    results: list[OpsResult] = []
    cp = _run(["systemctl", "--user", "daemon-reload"], check=False)
    if cp.returncode != 0:
        details = _output_excerpt(cp)
        results.append(OpsResult(False, "systemctl --user daemon-reload failed", details.strip()))
        return results

    _run(["systemctl", "--user", "enable", unit], check=False, expected=True)

    cp = _run(["systemctl", "--user", "restart", unit], check=False)
    if cp.returncode == 0:
        results.append(OpsResult(True, f"Started/restarted systemd unit: {unit}"))
    else:
        details = _output_excerpt(cp)
        results.append(OpsResult(False, f"Failed to start systemd unit: {unit}", details.strip()))
    return results


def _install_cassandra_logs_systemd_unit() -> list[OpsResult]:
    """Install and (re)start the Cassandra log-follower systemd --user unit.

    Linux twin of `_install_cassandra_launchagent`: locates the unit template
    in the repo, copies it into ~/.config/systemd/user/, then reloads and
    (re)starts it. Returns a single-element list of OpsResult (plus the
    reload/activate results); fails if the template can't be found.
    """
    results: list[OpsResult] = []
    tpl, checked = _find_systemd_unit_template("nyxgpt-cassandra-logs.service")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing Cassandra logs systemd unit template", details))
        return results
    dst = _systemd_user_dir() / tpl.name
    _install_systemd_unit_from_template(tpl, dst)
    results.append(OpsResult(True, "Installed Cassandra logs systemd unit", str(dst)))
    results.extend(_reload_and_activate_systemd_unit("nyxgpt-cassandra-logs.service"))
    return results


def _install_ollama_logs_systemd_unit() -> list[OpsResult]:
    """Install and (re)start the Ollama log-follower systemd --user unit.

    Linux twin of `_install_ollama_launchagent`. Installed unconditionally by
    `nyxgpt ops install` regardless of deployment mode, same as the Cassandra
    unit -- `follow-ollama-logs.sh` (which this unit runs) handles both
    Compose mode (follows the `nyxgpt-ollama` container) and native mode
    (tails ~/.nyxGPT/logs/ollama-native.log, nyxgpt-ollama.service's own
    stdout) on its own (see #3441).
    """
    results: list[OpsResult] = []
    tpl, checked = _find_systemd_unit_template("nyxgpt-ollama-logs.service")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing Ollama logs systemd unit template", details))
        return results
    dst = _systemd_user_dir() / tpl.name
    _install_systemd_unit_from_template(tpl, dst)
    results.append(OpsResult(True, "Installed Ollama logs systemd unit", str(dst)))
    results.extend(_reload_and_activate_systemd_unit("nyxgpt-ollama-logs.service"))
    return results


def _linux_native_root(component: str) -> Path:
    """Return `~/.nyxGPT/opt/<component>`, creating it if needed.

    The self-contained install root Linux native mode uses in place of a
    Homebrew Cellar keg -- holds the component's venv/build plus the wrapper
    script its systemd unit execs.
    """
    p = Path.home() / ".nyxGPT" / "opt" / component
    _ensure_dir(p)
    return p


def _venv_site_packages(venv_dir: Path) -> Path | None:
    """Return a venv's `site-packages` directory, or None if the venv wasn't created."""
    matches = sorted((venv_dir / "lib").glob("python3.*/site-packages"))
    return matches[0] if matches else None


# nyxGPT's `requires-python` floor, as a literal: a service venv has to be
# built *before* anything is installed into it, so ops cannot read the
# metadata of the package it is about to install.
# `tests/unit/test_ops_service_python.py` asserts this stays in step with
# pyproject.toml's `requires-python`.
_MIN_SERVICE_PYTHON = (3, 11)

# Explicitly-versioned interpreter names to look for on PATH, newest first,
# when the interpreter ops itself runs under is below the floor. Bare
# `python3` is tried last and only if it satisfies the floor: on Amazon Linux
# 2023 it is 3.9, which is exactly how #3782 shipped a service venv that pip
# then refused ("requires a different Python: 3.9.16 not in '>=3.11'").
_SERVICE_PYTHON_NAMES = ("python3.13", "python3.12", "python3.11", "python3")


def _interpreter_version(exe: str) -> tuple[int, int] | None:
    """Return `exe`'s `(major, minor)`, or None if it cannot be run.

    Asks the interpreter itself rather than parsing its filename: a
    `python3.11` on PATH may be a wrapper, a symlink to something else, or
    not executable at all.
    """
    cp = _run(
        [exe, "-c", "import sys; print('%d.%d' % sys.version_info[:2])"],
        check=False,
        expected=True,
    )
    if cp.returncode != 0:
        return None
    parts = (cp.stdout or "").strip().split(".")
    if len(parts) != 2:
        return None
    try:
        return (int(parts[0]), int(parts[1]))
    except ValueError:
        return None


def _running_interpreter() -> tuple[str, tuple[int, int]]:
    """Return the interpreter ops itself runs under, and its `(major, minor)`.

    Read from `sys` rather than by running a subprocess -- and factored out
    so a smoke/test can stand in a different interpreter for it.
    """
    return (sys.executable, (sys.version_info[0], sys.version_info[1]))


def _service_python_candidates() -> list[tuple[str, tuple[int, int]]]:
    """Return the interpreters that could build a service venv, best first.

    Order:

    1. `sys.executable` -- the interpreter ops itself runs under. It is
       already known to satisfy `requires-python` (it is running nyxGPT), and
       on a cloud instance it is the one provisioning installed for exactly
       that reason. Its version is read from `sys.version_info` rather than a
       subprocess, so selection costs nothing in the common case.
    2. `python3.13`/`python3.12`/`python3.11` from PATH, newest first.
    3. Bare `python3`, last -- it is the distro's choice, not nyxGPT's.

    Every entry carries the version actually reported by that interpreter;
    entries below the floor are kept (the caller names them in its failure
    message) and duplicates of the same real path are dropped.
    """
    candidates: list[tuple[str, tuple[int, int]]] = []
    seen: set[str] = set()

    def _add(exe: str | None, version: tuple[int, int] | None) -> None:
        if not exe:
            return
        try:
            key = os.path.realpath(exe)
        except OSError:  # pragma: no cover - realpath on a live path
            key = exe
        if key in seen:
            return
        seen.add(key)
        if version is None:
            version = _interpreter_version(exe)
        if version is None:
            return
        candidates.append((exe, version))

    _add(*_running_interpreter())
    for name in _SERVICE_PYTHON_NAMES:
        _add(_which(name), None)
    return candidates


def _format_python_version(version: tuple[int, int]) -> str:
    return f"{version[0]}.{version[1]}"


def _no_service_python_details(candidates: list[tuple[str, tuple[int, int]]]) -> str:
    """Explain a failed interpreter search, naming found and required versions."""
    floor = _format_python_version(_MIN_SERVICE_PYTHON)
    if candidates:
        found = "\n".join(f"  {exe} (Python {_format_python_version(v)})" for exe, v in candidates)
    else:
        found = "  (no working Python interpreter found on PATH)"
    return (
        f"nyxGPT requires Python >= {floor}; none of the interpreters on this machine qualify.\n"
        f"Found:\n{found}\n"
        f"Install a Python >= {floor} and re-run `nyxgpt ops install`:\n"
        "  Amazon Linux / Fedora / RHEL: sudo dnf install -y python3.11 python3.11-pip\n"
        "  Debian / Ubuntu:              sudo apt-get install -y python3.11 python3.11-venv"
    )


def _create_service_venv(venv_dir: Path, service: str) -> OpsResult:
    """Create `venv_dir` with an interpreter that satisfies `requires-python`.

    Bare `python3` is never assumed sufficient (#3782): Amazon Linux 2023's
    is 3.9, so `python3 -m venv` there produced a venv pip then refused to
    install nyxGPT into -- a failure that surfaced as an opaque `pip install
    ... (rc=1)` at the end of a cloud deploy.

    Candidates are tried in `_service_python_candidates` order and the first
    one that both satisfies the floor *and* successfully creates the venv
    wins -- so a `python3.11` that is present but has no working `venv`/
    `ensurepip` (Debian's split `python3.11-venv` package) falls through to
    the next candidate instead of failing the install.
    """
    candidates = _service_python_candidates()
    usable = [(exe, v) for exe, v in candidates if v >= _MIN_SERVICE_PYTHON]
    if not usable:
        return OpsResult(
            False,
            f"No Python >= {_format_python_version(_MIN_SERVICE_PYTHON)} "
            f"available to create the {service} venv",
            _no_service_python_details(candidates),
        )

    failures: list[str] = []
    for exe, version in usable:
        cp = _run([exe, "-m", "venv", str(venv_dir)], check=False)
        if cp.returncode == 0:
            return OpsResult(
                True,
                f"Created {service} venv with Python {_format_python_version(version)}",
                f"{exe} -> {venv_dir}",
            )
        failures.append(
            f"{exe} (Python {_format_python_version(version)}):\n{_output_excerpt(cp).strip()}"
        )

    return OpsResult(False, f"Failed to create {service} venv", "\n".join(failures))


def _write_executable(path: Path, content: str) -> None:
    """Write `content` to `path` and mark it executable (0o755)."""
    _ensure_dir(path.parent)
    path.write_text(content, encoding="utf-8")
    os.chmod(path, 0o755)


# Wrapper script templates for the Linux native services -- plain-string
# (not f-string) templates so the embedded Python heredocs' own `{...}`
# formatting doesn't need brace-escaping; `__NYXGPT_API_VENV__`/
# `__NYXGPT_WEB_ROOT__` are substituted via `str.replace` at install time.
# Mirror homebrew/nyxgpt-api.rb's and nyxgpt-web.rb's `bin/nyxgpt-*` wrapper
# scripts: read host/port (and, for web, the api_base_url override) from
# ~/.nyxGPT/config.ini, then exec the real process.
_NATIVE_API_WRAPPER_TEMPLATE = """#!/bin/bash
set -euo pipefail

CONFIG_FILE="$HOME/.nyxGPT/config.ini"
SYS_PY="$(command -v python3 || echo /usr/bin/python3)"

HOST="127.0.0.1"
PORT="8000"

if [ -f "$CONFIG_FILE" ]; then
  IFS=$'\\t' read -r HOST PORT < <("$SYS_PY" - <<'PY'
import configparser
import os

cfg = configparser.ConfigParser()
cfg.read(os.path.expanduser('~/.nyxGPT/config.ini'), encoding='utf-8')

host = cfg.get('api', 'host', fallback='127.0.0.1')
try:
    port = str(cfg.getint('api', 'port', fallback=8000))
except Exception:
    port = '8000'

print(f"{host}\\t{port}")
PY
)
fi

echo "nyxgpt-api starting (self-contained venv)" >&2
echo "  host: $HOST" >&2
echo "  port: $PORT" >&2

exec "__NYXGPT_API_VENV__/bin/python3" -m uvicorn nyxgpt.app:app --host "$HOST" --port "$PORT"
"""

_NATIVE_WEB_WRAPPER_TEMPLATE = """#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="$HOME/.nyxGPT/config.ini"
SYS_PY="$(command -v python3 || echo /usr/bin/python3)"

HOST="127.0.0.1"
PORT="3000"
API_BASE=""
AUTH_KEY=""

if [ -f "$CONFIG_FILE" ]; then
  IFS=$'\\t' read -r HOST PORT API_BASE AUTH_KEY < <("$SYS_PY" - <<'PY'
import configparser
import os

cfg = configparser.ConfigParser()
cfg.read(os.path.expanduser('~/.nyxGPT/config.ini'), encoding='utf-8')

host = cfg.get('web', 'host', fallback='127.0.0.1')
try:
    port = str(cfg.getint('web', 'port', fallback=3000))
except Exception:
    port = '3000'
api_base = cfg.get('web', 'api_base_url', fallback='')
# The proxy in web/src/lib/apiProxy.ts attaches X-API-Key from
# NYXGPT_AUTH_API_KEY; without it every proxied call 401s the moment
# [auth] enabled is turned on (#3632).
try:
    auth_on = cfg.getboolean('auth', 'enabled', fallback=False)
except Exception:
    auth_on = False
api_key = cfg.get('auth', 'api_key', fallback='').strip() if auth_on else ''

print(f"{host}\\t{port}\\t{api_base}\\t{api_key}")
PY
)
fi

export HOST="$HOST"
export PORT="$PORT"
if [ -n "$API_BASE" ]; then
  export NEXT_PUBLIC_API_BASE="$API_BASE"
fi
if [ -n "$AUTH_KEY" ]; then
  export NYXGPT_AUTH_API_KEY="$AUTH_KEY"
fi

echo "nyxgpt-web starting (self-contained build)" >&2
echo "  host: $HOST" >&2
echo "  port: $PORT" >&2

cd "__NYXGPT_WEB_ROOT__"
exec npm run start
"""


def _install_native_api_systemd() -> list[OpsResult]:
    """Build and install a self-contained venv for `nyxgpt-api` on Linux, then
    (re)start its systemd --user unit.

    Linux twin of `_install_homebrew_api`: takes the `nyxgpt-api` source
    tarball (`pyproject.toml` + `src/nyxgpt/` + `example.config.ini`) into
    `~/.nyxGPT/opt/nyxgpt-api`, creates a venv there with an interpreter that
    satisfies nyxGPT's `requires-python` (`_create_service_venv`, #3782 --
    the distro's bare `python3` is 3.9 on Amazon Linux 2023 and pip refuses
    the artifact in a venv built from it), `pip install`s
    that tarball into it, copies `example.config.ini` next to the installed
    package (`config_wizard`'s schema-source resolution finds it there with
    no repo root above the venv, mirroring the brew formula's own fix,
    #3406 -- an artifact install carries it as package data instead, so
    there is nothing to copy), writes the wrapper script the systemd unit
    execs, then installs/reloads the unit.

    The tarball is vendored from the checkout on a dev machine and
    downloaded from the published release asset on an artifact install
    (`_service_source_tarball`, #3759) -- the install recipe below is the
    same either way.

    Unlike `_install_homebrew_api`'s sha256-gated skip-if-unchanged
    (`_brew_install_or_reinstall`), this always rebuilds -- a slower but
    simpler first Linux implementation; `nyxgpt ops install` is not a hot
    path. Returns a list of OpsResult.
    """
    results: list[OpsResult] = []
    root = _linux_native_root("nyxgpt-api")
    version = _native_service_version()
    try:
        tar = _service_source_tarball(root, "nyxgpt-api", version)
    except RuntimeError as e:
        return [OpsResult(False, "Could not obtain the nyxgpt-api artifact", str(e))]
    venv_dir = root / "venv"

    venv_result = _create_service_venv(venv_dir, "nyxgpt-api")
    results.append(venv_result)
    if not venv_result.ok:
        return results

    pip = str(venv_dir / "bin" / "pip")
    _run([pip, "install", "--upgrade", "pip"], check=False)
    cp = _run([pip, "install", str(tar)], check=False)
    if cp.returncode != 0:
        details = _output_excerpt(cp)
        results.append(OpsResult(False, "Failed to pip install nyxgpt-api", details.strip()))
        return results
    results.append(
        OpsResult(True, "Installed nyxgpt-api into a self-contained venv", str(venv_dir))
    )

    site_packages = _venv_site_packages(venv_dir)
    example_config = REPO_ROOT / "example.config.ini"
    if site_packages is not None and example_config.exists():
        nyxgpt_pkg_dir = site_packages / "nyxgpt"
        if nyxgpt_pkg_dir.exists():
            _copy_file(example_config, nyxgpt_pkg_dir / "example.config.ini")

    wrapper = root / "bin" / "nyxgpt-api"
    _write_executable(
        wrapper, _NATIVE_API_WRAPPER_TEMPLATE.replace("__NYXGPT_API_VENV__", str(venv_dir))
    )
    results.append(OpsResult(True, "Installed nyxgpt-api wrapper script", str(wrapper)))

    tpl, checked = _find_systemd_unit_template("nyxgpt-api.service")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing nyxgpt-api systemd unit template", details))
        return results
    dst = _systemd_user_dir() / tpl.name
    _ensure_dir(Path.home() / ".nyxGPT" / "logs")
    _install_systemd_unit_from_template(tpl, dst)
    results.append(OpsResult(True, "Installed nyxgpt-api systemd unit", str(dst)))
    results.extend(_reload_and_activate_systemd_unit("nyxgpt-api.service"))
    return results


def _install_native_web_systemd() -> list[OpsResult]:
    """Build and install a self-contained web build for `nyxgpt-web` on Linux,
    then (re)start its systemd --user unit.

    Linux twin of `_install_homebrew_web`: takes the `nyxgpt-web` source
    tarball (the `web/` tree minus its gitignored build artifacts, see
    `_WEB_VENDOR_EXCLUDES`) -- vendored from the checkout on a dev machine,
    downloaded from the published release asset on an artifact install
    (`_service_source_tarball`, #3759) -- extracts it into a staging
    directory, runs `npm ci`/`npm run build` inside it, then -- only once that build has
    succeeded -- swaps it into `~/.nyxGPT/opt/nyxgpt-web/build` in place of
    the previous one, writes the wrapper script the systemd unit execs, and
    installs/reloads the unit. Always rebuilds -- see
    `_install_native_api_systemd`'s docstring for why this doesn't do
    `_install_homebrew_web`'s sha256-gated skip.

    The build/swap is staged rather than done in place so a failed `npm ci`/
    `npm run build` (transient registry issue, disk pressure, OOM, ...)
    leaves the previous, still-running build untouched -- the live
    `nyxgpt-web.service` wrapper keeps `cd`ing into a build that still
    exists instead of a path a failed rebuild rmtree'd out from under it (a
    real outage-on-restart bug found in review, #3508).

    Returns a list of OpsResult; fails early if `npm` isn't on PATH.
    """
    if _which("npm") is None:
        return [OpsResult(False, "npm not found; cannot install nyxgpt-web", "")]

    results: list[OpsResult] = []
    root = _linux_native_root("nyxgpt-web")
    version = _native_service_version()
    try:
        tar = _service_source_tarball(root, "nyxgpt-web", version)
    except RuntimeError as e:
        return [OpsResult(False, "Could not obtain the nyxgpt-web artifact", str(e))]

    build_dir = root / "build"
    staging_dir = root / "build.staging"
    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    _ensure_dir(staging_dir)
    with tarfile.open(tar) as tf:
        # Trusted input: `tar` was just built by `_create_dist_tarball` above
        # from this repo's own `web/` tree, not from an external/user source.
        tf.extractall(staging_dir, filter="data")
    staged_extracted = staging_dir / f"nyxgpt-web-{version}"

    npm = _which("npm") or "npm"
    for step_name, npm_args in (("npm ci", ["ci"]), ("npm run build", ["run", "build"])):
        try:
            cp = subprocess.run(
                [npm, *npm_args],
                cwd=str(staged_extracted),
                text=True,
                capture_output=True,
                check=False,
            )
        except Exception as e:
            shutil.rmtree(staging_dir, ignore_errors=True)
            results.append(
                OpsResult(
                    False, f"Failed to run {step_name} for nyxgpt-web", f"{type(e).__name__}: {e}"
                )
            )
            return results
        if cp.returncode != 0:
            shutil.rmtree(staging_dir, ignore_errors=True)
            results.append(
                OpsResult(
                    False,
                    f"{step_name} failed for nyxgpt-web",
                    _output_excerpt(cp),
                )
            )
            return results

    # The new build is known-good -- swap it into place. Two renames (both
    # fast, same-filesystem) instead of an rmtree-then-build so the previous
    # build is never gone from `build_dir` for longer than the swap itself.
    old_dir = root / "build.old"
    if old_dir.exists():
        shutil.rmtree(old_dir)
    if build_dir.exists():
        build_dir.rename(old_dir)
    staging_dir.rename(build_dir)
    if old_dir.exists():
        shutil.rmtree(old_dir, ignore_errors=True)
    extracted = build_dir / f"nyxgpt-web-{version}"
    results.append(OpsResult(True, "Built nyxgpt-web production bundle", str(extracted)))

    wrapper = root / "bin" / "nyxgpt-web"
    _write_executable(
        wrapper, _NATIVE_WEB_WRAPPER_TEMPLATE.replace("__NYXGPT_WEB_ROOT__", str(extracted))
    )
    results.append(OpsResult(True, "Installed nyxgpt-web wrapper script", str(wrapper)))

    tpl, checked = _find_systemd_unit_template("nyxgpt-web.service")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing nyxgpt-web systemd unit template", details))
        return results
    dst = _systemd_user_dir() / tpl.name
    _ensure_dir(Path.home() / ".nyxGPT" / "logs")
    _install_systemd_unit_from_template(tpl, dst)
    results.append(OpsResult(True, "Installed nyxgpt-web systemd unit", str(dst)))
    results.extend(_reload_and_activate_systemd_unit("nyxgpt-web.service"))
    return results


def _system_ollama_service_active() -> bool:
    """True if a distro-managed system-wide `ollama.service` is currently active.

    The official Ollama Linux installer (`curl -fsSL https://ollama.com/install.sh
    | sh`) auto-enables and starts this unit, bound to 127.0.0.1:11434 -- the
    same port `nyxgpt-ollama.service` (nyxGPT's own systemd --user unit)
    needs, so the two can never both hold the port at once (#3632: observed
    in CI as `nyxgpt-ollama.service` crash-looping, "ollama serve" exiting
    immediately with the port already taken). Checked with plain `systemctl
    is-active` (system scope, no `--user`), since the installer's unit runs
    system-wide, not per-user. False (never raises) if systemctl is missing
    or the query fails -- an unknown/absent system unit is not a conflict.
    """
    if _which("systemctl") is None:
        return False
    cp = _run(["systemctl", "is-active", "ollama.service"], check=False, expected=True)
    return (cp.stdout or "").strip() == "active"


def _system_ollama_service_enabled() -> bool:
    """True if the system-wide `ollama.service` is enabled to start at boot.

    Checked alongside `_system_ollama_service_active()` because a merely
    *enabled* (currently stopped) system unit is just as much of a conflict:
    it would grab port 11434 back from `nyxgpt-ollama.service` at the next
    boot. `is-enabled` also reports "enabled" for a unit that is masked-free
    but stopped, which is precisely the state we still want to disable.

    "static" is deliberately *not* treated as a conflict: a static unit has no
    `[Install]` section, so `systemctl disable` on it is a no-op -- reporting
    it would leave `ops doctor` flagging a conflict nothing can ever clear.
    A static unit is also not started at boot on its own, so it only matters
    while it is running, which `_system_ollama_service_active()` already
    covers.
    """
    if _which("systemctl") is None:
        return False
    cp = _run(["systemctl", "is-enabled", "ollama.service"], check=False, expected=True)
    return (cp.stdout or "").strip() in {"enabled", "enabled-runtime"}


def _system_ollama_service_conflicts() -> bool:
    """True if a distro-managed system-wide `ollama.service` would contend for port 11434."""
    return _system_ollama_service_active() or _system_ollama_service_enabled()


def _takeover_system_ollama_service() -> tuple[bool, list[OpsResult]]:
    """Stop and disable a pre-existing system-wide `ollama.service` so
    `nyxgpt-ollama.service` can own port 11434.

    Chosen reconciliation for #3632 (documented in docs/systemd.md): nyxGPT
    manages Ollama itself, the same operator-facing way it manages api/web,
    rather than deferring to whatever the official Ollama installer
    (`curl -fsSL https://ollama.com/install.sh | sh`) left enabled. An
    earlier round of this fix *adopted* the system unit instead; that was
    rejected in acceptance testing because it leaves the machine in a split
    arrangement nyxgpt neither owns nor can restart, and leaves
    `OLLAMA_MODELS` pointed at Ollama's own store rather than the shared
    `~/.nyxGPT/volumes/ollama/models` one every other mode bind-mounts.

    Stopping a *system*-scope unit needs root, which is done via
    `_privileged_run`'s never-prompting `sudo -n` (see its docstring).
    Returns `(port_free, results)`: `port_free` is False when the system
    unit is still holding the port -- the caller must then NOT install or
    start `nyxgpt-ollama.service`, since it could only crash-loop, which is
    the exact failure this issue was filed for.
    """
    results: list[OpsResult] = []
    cp = _privileged_run(["systemctl", "disable", "--now", "ollama.service"])
    if cp is None or cp.returncode != 0:
        details = ""
        if cp is not None:
            details = _output_excerpt(cp)
        return False, [
            OpsResult(
                False,
                "System-wide ollama.service holds port 11434 and could not be disabled",
                "nyxgpt manages Ollama itself via nyxgpt-ollama.service, which cannot "
                "start while the distro's system unit owns the port. Root was not "
                "available without a password prompt, so free the port by hand and "
                "re-run install:\n"
                "  sudo systemctl disable --now ollama.service && nyxgpt ops install"
                + (f"\n{details}" if details else ""),
            )
        ]
    results.append(
        OpsResult(
            True,
            "Stopped and disabled system-wide ollama.service",
            "Freed 127.0.0.1:11434 for nyxgpt-ollama.service, which nyxgpt manages "
            "itself (pointed at the shared ~/.nyxGPT/volumes/ollama/models store). "
            "See docs/systemd.md#ollama.",
        )
    )
    # `disable --now` returns as soon as systemd accepts the job; the socket
    # can still be held for a moment while `ollama serve` shuts down, and
    # nyxgpt-ollama.service would lose the race and crash-loop exactly as
    # before. Wait for the port to actually come free.
    ollama_port = COMPOSE_COMPONENT_PORTS["ollama"]
    if not _wait_for_port_free("127.0.0.1", ollama_port):
        return False, [
            *results,
            OpsResult(
                False,
                f"Port {ollama_port} is still in use after disabling system ollama.service",
                "Something else is serving on it (another Ollama process, a container). "
                "Free it, then re-run `nyxgpt ops install`.",
            ),
        ]
    return True, results


def _wait_for_port_free(host: str, port: int, timeout: float = 15.0) -> bool:
    """Poll until nothing accepts TCP connections on `host:port`, or `timeout` elapses."""
    deadline = time.monotonic() + timeout
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1.0)
            if sock.connect_ex((host, port)) != 0:
                return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.5)


def _install_native_ollama_systemd() -> list[OpsResult]:
    """Ensure native Ollama is installed as the `nyxgpt-ollama.service` systemd
    --user unit, pointed at the shared model store.

    Linux twin of `_ensure_ollama_service`. Requires the `ollama` binary to
    already be on PATH -- unlike api/web, nyxgpt doesn't install Ollama
    itself on Linux (see the Linux install section in the docs for the
    official installer). Migrates any models already pulled into Ollama's
    own default store into the shared one (`_migrate_native_ollama_models`,
    OS-agnostic, #3431), then installs/reloads a unit whose `Environment=`
    already bakes in `OLLAMA_MODELS` -- no separate env-refresh unit is
    needed the way launchd needs a RunAtLoad LaunchAgent (`Environment=`
    applies on every unit start, unlike `launchctl setenv`'s per-session
    scope; see ops/systemd/nyxgpt-ollama.service).

    If a system-wide `ollama.service` already holds port 11434, it is stopped
    and disabled first so this unit can take the port over (#3632; see
    `_takeover_system_ollama_service`). When that takeover can't be
    completed, the nyxgpt unit is deliberately NOT installed or started --
    it could only crash-loop against the port -- and the failure is reported
    with the command that frees it.
    """
    results: list[OpsResult] = []
    if _system_ollama_service_conflicts():
        port_free, takeover_results = _takeover_system_ollama_service()
        results.extend(takeover_results)
        if not port_free:
            return results

    ollama_bin = _which("ollama")
    if ollama_bin is None:
        return [
            *results,
            OpsResult(
                False,
                "ollama not found on PATH",
                "Install it first: curl -fsSL https://ollama.com/install.sh | sh "
                "(see the Linux install section in the docs)",
            ),
        ]

    models_dir = _shared_ollama_models_dir()
    results.extend(_migrate_native_ollama_models(models_dir))

    tpl, checked = _find_systemd_unit_template("nyxgpt-ollama.service")
    if tpl is None:
        details = (
            "Tried:\n"
            + "\n".join(str(p) for p in checked)
            + "\nRun `nyxgpt ops install` first to sync packaged templates into "
            f"{NYXGPT_HOME}."
        )
        results.append(OpsResult(False, "Missing nyxgpt-ollama systemd unit template", details))
        return results
    dst = _systemd_user_dir() / tpl.name
    _ensure_dir(Path.home() / ".nyxGPT" / "logs")
    _install_systemd_unit_from_template(
        tpl, dst, substitutions={"__NYXGPT_OLLAMA_BIN__": ollama_bin}
    )
    results.append(OpsResult(True, "Installed nyxgpt-ollama systemd unit", str(dst)))
    results.extend(_reload_and_activate_systemd_unit("nyxgpt-ollama.service"))
    return results


def _systemd_services_snapshot() -> dict[str, str]:
    """Return {unit_name: state} for nyxGPT-managed systemd --user units.

    Mirrors `_brew_services_snapshot()`'s vocabulary ("started" for a live
    unit) *and* its "not in this dict" == "not installed" contract: a unit
    is only included if its file actually exists in
    `~/.config/systemd/user/` -- `systemctl --user is-active` on a
    never-installed unit name reports "inactive"/"unknown" the same way it
    would for an installed-but-stopped one, so checking activity alone would
    misreport a fresh machine that's never run `nyxgpt ops install` as
    having every native component "down" instead of simply absent. Empty on
    any failure (systemctl not on PATH, no session bus reachable).
    """
    if _which("systemctl") is None:
        return {}
    unit_dir = _systemd_user_dir()
    snapshot: dict[str, str] = {}
    for unit in NATIVE_SYSTEMD_SERVICES.values():
        if not (unit_dir / f"{unit}.service").exists():
            continue
        cp = _run(
            ["systemctl", "--user", "is-active", f"{unit}.service"], check=False, expected=True
        )
        state = (cp.stdout or "").strip()
        snapshot[unit] = "started" if state == "active" else "none"
    return snapshot


def _native_services_snapshot() -> dict[str, str]:
    """{component: state} for the OS-appropriate native service manager.

    Used by `detect_deployment_mode()` in place of a direct
    `_brew_services_snapshot()` call so it reflects whichever native path
    (Homebrew/launchd or systemd) actually applies on this host.
    """
    if _is_macos():
        brew_snapshot = _brew_services_snapshot()
        return {
            component: brew_snapshot.get(brew_name, "none")
            for component, brew_name in NATIVE_BREW_SERVICES.items()
        }
    if _is_linux():
        systemd_snapshot = _systemd_services_snapshot()
        return {
            component: systemd_snapshot.get(unit, "none")
            for component, unit in NATIVE_SYSTEMD_SERVICES.items()
        }
    return dict.fromkeys(NATIVE_BREW_SERVICES, "none")


def _restart_systemd_service(unit: str) -> list[OpsResult]:
    """Restart systemd --user unit `unit` via `systemctl --user restart`.

    Returns a single-element list: an OpsResult reporting systemctl missing,
    the restart command's success, or its failure with captured stdout/stderr.
    """
    if _which("systemctl") is None:
        return [OpsResult(False, f"systemctl not found; cannot restart {unit}")]
    try:
        cp = _run(["systemctl", "--user", "restart", f"{unit}.service"], check=False)
        if cp.returncode == 0:
            return [OpsResult(True, f"Restarted systemd unit: {unit}")]
        details = _output_excerpt(cp)
        return [OpsResult(False, f"Failed to restart systemd unit: {unit}", details.strip())]
    except Exception as e:
        return [
            OpsResult(False, f"Failed to restart systemd unit: {unit}", f"{type(e).__name__}: {e}")
        ]


def _stop_systemd_service(unit: str) -> list[OpsResult]:
    """Stop systemd --user unit `unit` via `systemctl --user stop`.

    Returns a single-element list: an OpsResult reporting systemctl missing,
    the stop command's success, or its failure with captured stdout/stderr.
    """
    if _which("systemctl") is None:
        return [OpsResult(False, f"systemctl not found; cannot stop {unit}")]
    try:
        cp = _run(["systemctl", "--user", "stop", f"{unit}.service"], check=False)
        if cp.returncode == 0:
            return [OpsResult(True, f"Stopped systemd unit: {unit}")]
        details = _output_excerpt(cp)
        return [OpsResult(False, f"Failed to stop systemd unit: {unit}", details.strip())]
    except Exception as e:
        return [
            OpsResult(False, f"Failed to stop systemd unit: {unit}", f"{type(e).__name__}: {e}")
        ]


def _install_native_api() -> list[OpsResult]:
    """Install/update the native `api` service via the OS-appropriate mechanism."""
    if _is_macos():
        return _install_homebrew_api()
    if _is_linux():
        return _install_native_api_systemd()
    return _unsupported_os_result("native api install")


def _install_native_web() -> list[OpsResult]:
    """Install/update the native `web` service via the OS-appropriate mechanism."""
    if _is_macos():
        return _install_homebrew_web()
    if _is_linux():
        return _install_native_web_systemd()
    return _unsupported_os_result("native web install")


def _ensure_native_ollama_service() -> list[OpsResult]:
    """Ensure the native `ollama` service is installed/running via the OS-appropriate mechanism."""
    if _is_macos():
        return _ensure_ollama_service()
    if _is_linux():
        return _install_native_ollama_systemd()
    return _unsupported_os_result("native ollama service")


def _install_cassandra_log_follower_service() -> list[OpsResult]:
    """Install the Cassandra log-follower agent via the OS-appropriate mechanism."""
    if _is_macos():
        return _install_cassandra_launchagent()
    if _is_linux():
        return _install_cassandra_logs_systemd_unit()
    return _unsupported_os_result("cassandra log follower")


def _install_ollama_log_follower_service() -> list[OpsResult]:
    """Install the Ollama log-follower agent via the OS-appropriate mechanism."""
    if _is_macos():
        return _install_ollama_launchagent()
    if _is_linux():
        return _install_ollama_logs_systemd_unit()
    return _unsupported_os_result("ollama log follower")


def _install_ollama_env_agent() -> list[OpsResult]:
    """Install the Ollama shared-model-store env agent, on the OS that still needs one.

    macOS needs a RunAtLoad LaunchAgent that reapplies `launchctl setenv
    OLLAMA_MODELS` every login (#3431); Linux's `nyxgpt-ollama.service`
    already bakes `Environment=OLLAMA_MODELS=...` into the unit file, which
    applies on every unit start with no companion agent needed.
    """
    if _is_macos():
        return _install_ollama_env_launchagent()
    if _is_linux():
        return [
            OpsResult(
                True,
                "Ollama env agent: not needed on Linux",
                "nyxgpt-ollama.service's Environment= directive sets OLLAMA_MODELS "
                "directly -- unlike launchctl setenv, it doesn't need a RunAtLoad "
                "companion to survive a reboot.",
            )
        ]
    return _unsupported_os_result("ollama env agent")


def _restart_native_service(component: str) -> list[OpsResult]:
    """Restart the OS-appropriate native service for `component` ("api"/"web"/"ollama")."""
    if _is_macos():
        return _restart_brew_service(NATIVE_BREW_SERVICES[component])
    if _is_linux():
        return _restart_systemd_service(NATIVE_SYSTEMD_SERVICES[component])
    return _unsupported_os_result(f"restart {component}")


def _stop_native_service(component: str) -> list[OpsResult]:
    """Stop the OS-appropriate native service for `component` ("api"/"web"/"ollama")."""
    if _is_macos():
        return _stop_brew_service(NATIVE_BREW_SERVICES[component])
    if _is_linux():
        return _stop_systemd_service(NATIVE_SYSTEMD_SERVICES[component])
    return _unsupported_os_result(f"stop {component}")


# Log-follower agent identifiers ("cassandra-logs"/"ollama-logs", matching
# `nyxgpt ops restart`/`stop`'s `cassandra-logs` target) mapped to each OS's
# native name for that agent.
_NATIVE_LOG_FOLLOWER_LAUNCHD_LABELS: dict[str, str] = {
    "cassandra-logs": "com.nyxgpt.cassandra-logs",
    "ollama-logs": "com.nyxgpt.ollama-logs",
}
_NATIVE_LOG_FOLLOWER_SYSTEMD_UNITS: dict[str, str] = {
    "cassandra-logs": "nyxgpt-cassandra-logs",
    "ollama-logs": "nyxgpt-ollama-logs",
}


def _restart_native_log_follower(name: str) -> list[OpsResult]:
    """Restart the OS-appropriate log-follower agent ("cassandra-logs"/"ollama-logs")."""
    if _is_macos():
        return _restart_launchagent(_NATIVE_LOG_FOLLOWER_LAUNCHD_LABELS[name])
    if _is_linux():
        return _restart_systemd_service(_NATIVE_LOG_FOLLOWER_SYSTEMD_UNITS[name])
    return _unsupported_os_result(f"restart {name}")


def _stop_native_log_follower(name: str) -> list[OpsResult]:
    """Stop the OS-appropriate log-follower agent ("cassandra-logs"/"ollama-logs")."""
    if _is_macos():
        return _stop_launchagent(_NATIVE_LOG_FOLLOWER_LAUNCHD_LABELS[name])
    if _is_linux():
        return _stop_systemd_service(_NATIVE_LOG_FOLLOWER_SYSTEMD_UNITS[name])
    return _unsupported_os_result(f"stop {name}")


def _ensure_web_deps() -> list[OpsResult]:
    """Ensure web/node_modules is present by running npm ci/install in ./web.

    This is intentionally part of ops install so users don't have to run `npm install` manually.
    """
    results: list[OpsResult] = []
    web_dir = REPO_ROOT / "web"
    if not web_dir.exists():
        # Artifact install: there is no checkout, so there is no `web/` npm
        # project to prime -- and reporting the path REPO_ROOT resolved to
        # inside the installed venv only reads as a bug (#3759). The
        # nyxgpt-web service installs its own dependencies from the
        # published web artifact (`_install_native_web`).
        return [
            OpsResult(
                True,
                "Web deps: not applicable to an artifact install (no repo checkout)",
                "The nyxgpt-web service installs its own dependencies from the published "
                "web artifact; web/node_modules is a dev-checkout concern.",
            )
        ]

    if _which("node") is None:
        return [
            OpsResult(
                False,
                "node not found; cannot install web deps",
                "Install Node.js and ensure `node` is on PATH",
            )
        ]
    if _which("npm") is None:
        return [
            OpsResult(
                False,
                "npm not found; cannot install web deps",
                "Install Node.js/npm and ensure `npm` is on PATH",
            )
        ]

    node_modules = web_dir / "node_modules"
    lockfile = web_dir / "package-lock.json"

    def _can_resolve(pkg: str) -> bool:
        try:
            cp = subprocess.run(
                ["node", "-p", f"require.resolve('{pkg}')"],
                cwd=str(web_dir),
                text=True,
                capture_output=True,
            )
            return cp.returncode == 0
        except Exception as e:
            logger.warning(
                "Failed to resolve node package %r, assuming missing: %s",
                pkg,
                e,
                extra={"component": "ops"},
            )
            return False

    # Check if node_modules exists and undici can be resolved
    if node_modules.exists() and _can_resolve("undici"):
        results.append(OpsResult(True, "Web deps already installed (undici OK)", str(node_modules)))
        return results

    def _run_npm(cmd: list[str]) -> subprocess.CompletedProcess[str]:
        return subprocess.run(cmd, cwd=str(web_dir), text=True, capture_output=True)

    # Prefer npm ci when a lockfile exists, but if the lockfile is out of sync
    # (common after editing package.json), fall back to npm install so the lock
    # is updated and dependencies actually get installed.
    try:
        if lockfile.exists():
            cp = _run_npm(["npm", "ci"])
            if cp.returncode != 0:
                stderr = cp.stderr or ""
                # npm uses EUSAGE + a specific message when package-lock is out of sync
                if (
                    "can only install packages when your package.json and package-lock.json"
                    in stderr
                ):
                    cp2 = _run_npm(["npm", "install"])
                    if cp2.returncode != 0:
                        details = _output_excerpt(cp2)
                        results.append(
                            OpsResult(
                                False,
                                "Failed to install web deps via npm install (after npm ci mismatch)",
                                details.strip(),
                            )
                        )
                        return results
                    # npm install succeeded (and likely updated package-lock.json)
                    if not _can_resolve("undici"):
                        details = _output_excerpt(cp2)
                        results.append(
                            OpsResult(
                                False,
                                "Web deps installed but undici still missing",
                                details.strip(),
                            )
                        )
                        return results
                    results.append(
                        OpsResult(
                            True,
                            "Installed web deps via npm install (lockfile was out of sync; package-lock.json updated)",
                            str(node_modules),
                        )
                    )
                    return results

                # Other npm ci failure
                details = _output_excerpt(cp)
                results.append(
                    OpsResult(False, "Failed to install web deps via npm ci", details.strip())
                )
                return results

            # npm ci succeeded
            if not _can_resolve("undici"):
                details = _output_excerpt(cp)
                results.append(
                    OpsResult(
                        False,
                        "Web deps installed but undici still missing",
                        details.strip(),
                    )
                )
                return results
            results.append(OpsResult(True, "Installed web deps via npm ci", str(node_modules)))
            return results

        # No lockfile: use npm install
        cp = _run_npm(["npm", "install"])
        if cp.returncode == 0:
            if not _can_resolve("undici"):
                details = _output_excerpt(cp)
                results.append(
                    OpsResult(
                        False,
                        "Web deps installed but undici still missing",
                        details.strip(),
                    )
                )
                return results
            results.append(OpsResult(True, "Installed web deps via npm install", str(node_modules)))
            return results

        details = _output_excerpt(cp)
        results.append(
            OpsResult(False, "Failed to install web deps via npm install", details.strip())
        )
        return results

    except Exception as e:
        results.append(OpsResult(False, "Failed to install web deps", f"{type(e).__name__}: {e}"))
        return results


def _ensure_mcp_deps() -> list[OpsResult]:
    """Ensure root node_modules are present for Claude Code MCP servers."""
    results: list[OpsResult] = []
    root_dir = REPO_ROOT
    pkg_json = root_dir / "package.json"

    if not pkg_json.exists():
        # Artifact install -- same reasoning as `_ensure_web_deps` (#3759).
        # The MCP servers are repo-local dev tooling, never part of an
        # installed deployment.
        return [
            OpsResult(
                True,
                "MCP deps: not applicable to an artifact install (no repo checkout)",
                "The Claude Code MCP servers are repo-local dev tooling, not a runtime "
                "dependency of an installed nyxGPT.",
            )
        ]

    if _which("npm") is None:
        return [
            OpsResult(
                False,
                "npm not found; cannot install MCP deps",
                "Install Node.js/npm and ensure `npm` is on PATH",
            )
        ]

    sentinel = root_dir / "node_modules" / "@modelcontextprotocol" / "server-github"
    if sentinel.exists():
        results.append(
            OpsResult(True, "MCP deps already installed", str(root_dir / "node_modules"))
        )
        return results

    lockfile = root_dir / "package-lock.json"
    use_ci = lockfile.exists()
    npm_cmd = ["npm", "ci"] if use_ci else ["npm", "install"]

    try:
        cp = subprocess.run(npm_cmd, cwd=str(root_dir), text=True, capture_output=True)
        if cp.returncode == 0:
            results.append(
                OpsResult(
                    True,
                    f"Installed MCP deps via {' '.join(npm_cmd)}",
                    str(root_dir / "node_modules"),
                )
            )
        else:
            details = _output_excerpt(cp)
            results.append(OpsResult(False, "Failed to install MCP deps", details.strip()))
    except Exception as e:
        results.append(OpsResult(False, "Failed to install MCP deps", f"{type(e).__name__}: {e}"))

    return results


# --- Docker engine bootstrap (Linux) ---

# Distro package sets that provide the Docker *engine*, tried in order. Each
# entry is (package-manager argv prefix, packages).
#
# Engine and Compose plugin are installed as two separate transactions
# (`_LINUX_COMPOSE_PACKAGE_SETS` below) because the two are not packaged
# together everywhere. Amazon Linux 2023 carries `docker` but ships no compose
# package in its repos at all, so the combined `dnf install -y docker
# docker-compose-plugin` this used to run failed as a unit -- taking the engine
# down with the plugin and reporting "Could not install Docker automatically"
# on a host where the engine alone would have installed fine (#3760).
_LINUX_DOCKER_ENGINE_PACKAGE_SETS: tuple[tuple[str, list[str], list[str]], ...] = (
    ("apt-get", ["apt-get", "install", "-y"], ["docker.io"]),
    ("dnf", ["dnf", "install", "-y"], ["docker"]),
    ("yum", ["yum", "install", "-y"], ["docker"]),
)

# Distro package sets that provide the Compose v2 CLI plugin. The Debian/Ubuntu
# plugin has been packaged under two names across releases
# (`docker-compose-v2` on recent Ubuntu, `docker-compose-plugin` where Docker's
# own repo is configured), so both are attempted before giving up. Distros that
# package nothing at all (Amazon Linux 2023) fall through to
# `_install_compose_plugin_binary`.
_LINUX_COMPOSE_PACKAGE_SETS: tuple[tuple[str, list[str], list[str]], ...] = (
    ("apt-get", ["apt-get", "install", "-y"], ["docker-compose-v2"]),
    ("apt-get", ["apt-get", "install", "-y"], ["docker-compose-plugin"]),
    ("dnf", ["dnf", "install", "-y"], ["docker-compose-plugin"]),
    ("yum", ["yum", "install", "-y"], ["docker-compose-plugin"]),
)

# Where a manually fetched Compose v2 plugin goes. The Docker CLI scans this
# directory for `docker-<subcommand>` plugins for *every* user on the host,
# which is what a per-user `~/.docker/cli-plugins` install would not do -- and
# ops may end up invoking Docker as root (`_enable_docker_socket_hop`).
COMPOSE_PLUGIN_DIR = Path("/usr/local/lib/docker/cli-plugins")

# Docker publishes one static plugin binary per platform with every Compose
# release. `releases/latest/download/...` is GitHub's own redirect to the
# newest release's asset, so this URL keeps resolving without a version bump
# here -- and the fetch is verified by actually running `docker compose
# version` afterwards rather than trusted blind.
_COMPOSE_PLUGIN_URL = (
    "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-{arch}"
)

# `platform.machine()` -> the architecture suffix in Compose's release assets.
_COMPOSE_PLUGIN_ARCHES: dict[str, str] = {
    "x86_64": "x86_64",
    "amd64": "x86_64",
    "aarch64": "aarch64",
    "arm64": "aarch64",
    "armv6l": "armv6",
    "armv7l": "armv7",
    "ppc64le": "ppc64le",
    "riscv64": "riscv64",
    "s390x": "s390x",
}

_DOCKER_MANUAL_INSTALL_HINT = (
    "Install Docker yourself, then re-run `nyxgpt ops install`:\n"
    "  Debian/Ubuntu:     sudo apt-get update && sudo apt-get install -y docker.io "
    "docker-compose-v2\n"
    "  Fedora/RHEL:       sudo dnf install -y docker docker-compose-plugin\n"
    "  Amazon Linux 2023: sudo dnf install -y docker  (its repos carry no compose\n"
    "                     package, so fetch the plugin binary as well:\n"
    f"                     sudo mkdir -p {COMPOSE_PLUGIN_DIR} && sudo curl -fsSL -o "
    f"{COMPOSE_PLUGIN_DIR / 'docker-compose'} \\\n"
    "                     https://github.com/docker/compose/releases/latest/download/"
    "docker-compose-linux-$(uname -m) \\\n"
    f"                     && sudo chmod 0755 {COMPOSE_PLUGIN_DIR / 'docker-compose'})\n"
    "  then:              sudo systemctl enable --now docker && sudo usermod -aG docker "
    "$(whoami)"
)


def _docker_daemon_reachable() -> bool:
    """True if `docker info` succeeds -- i.e. the daemon is up AND this user may talk to it.

    Never raises: this runs inside `doctor` and inside install steps, where a
    docker binary that can't even be executed is one more thing to report,
    not a reason to abort the surrounding check.
    """
    if _which("docker") is None:
        return False
    try:
        cp = _run(["docker", "info", "--format", "{{.ServerVersion}}"], check=False, expected=True)
    except Exception as e:
        logger.debug("ops: docker info failed: %s: %s", type(e).__name__, e)
        return False
    return cp.returncode == 0


def _install_packages_from_sets(
    package_sets: tuple[tuple[str, list[str], list[str]], ...],
    *,
    expected_failure: bool = False,
) -> tuple[str, list[str]]:
    """Install the first of `package_sets` whose package manager exists and succeeds.

    Returns `("installed", packages)` on the first successful transaction,
    `("no-root", [])` when root isn't reachable at all (so the caller can say
    so rather than blaming the distro), or `("failed", [])` when every
    matching set was attempted without success -- including the case where no
    package manager on this host matched any set.

    `expected_failure=True` logs a non-zero exit at DEBUG instead of WARNING,
    for sets that are *routinely* absent (no distro packages the Compose
    plugin under every name, and trying is how we find out).
    """
    refreshed_apt = False
    for tool, install_cmd, packages in package_sets:
        if _which(tool) is None:
            continue
        if tool == "apt-get" and not refreshed_apt:
            # Without a package index a fresh cloud image's `install` just
            # reports "Unable to locate package".
            refreshed_apt = True
            _privileged_run(["apt-get", "update"], expected=True)
        cp = _privileged_run([*install_cmd, *packages], expected=expected_failure)
        if cp is None:
            return ("no-root", [])
        if cp.returncode == 0:
            return ("installed", packages)
    return ("failed", [])


def _install_linux_docker_engine() -> list[OpsResult]:
    """Install the Docker engine from the distro's package manager."""
    status, packages = _install_packages_from_sets(_LINUX_DOCKER_ENGINE_PACKAGE_SETS)
    if status == "installed":
        return [OpsResult(True, f"Installed Docker engine packages: {', '.join(packages)}")]
    if status == "no-root":
        return [
            OpsResult(
                False,
                "Docker is not installed and root is not available without a password",
                _DOCKER_MANUAL_INSTALL_HINT,
            )
        ]
    return [
        OpsResult(
            False,
            "Could not install Docker automatically",
            _DOCKER_MANUAL_INSTALL_HINT,
        )
    ]


def _install_compose_plugin_binary() -> list[OpsResult]:
    """Install Docker's own Compose v2 plugin binary into `COMPOSE_PLUGIN_DIR`.

    The escape hatch for distros that package no compose at all. Amazon Linux
    2023 is the case that forced it: `dnf install docker` gives a perfectly
    healthy engine, but there is no `docker-compose-plugin` in its repos, so
    every Compose-backed step of `ops install` -- the observability stack, the
    Grafana admin credential reconcile -- skipped or failed on a host that
    could run them fine (#3760).
    """
    machine = platform.machine()
    arch = _COMPOSE_PLUGIN_ARCHES.get(machine.lower())
    if arch is None:
        return [
            OpsResult(
                False,
                f"Docker publishes no Compose plugin build for architecture {machine!r}",
                _DOCKER_MANUAL_INSTALL_HINT,
            )
        ]
    if _which("curl") is None:
        return [
            OpsResult(
                False,
                "Could not install the Docker Compose plugin (curl not found on PATH)",
                _DOCKER_MANUAL_INSTALL_HINT,
            )
        ]

    dest = COMPOSE_PLUGIN_DIR / "docker-compose"
    url = _COMPOSE_PLUGIN_URL.format(arch=arch)
    for cmd in (
        ["mkdir", "-p", str(COMPOSE_PLUGIN_DIR)],
        ["curl", "-fsSL", "--retry", "3", "-o", str(dest), url],
        ["chmod", "0755", str(dest)],
    ):
        cp = _privileged_run(cmd)
        if cp is None:
            # Root is unreachable (no passwordless sudo) -- name that, rather
            # than reporting the generic "could not install" the engine path
            # distinguishes too.
            return [
                OpsResult(
                    False,
                    f"Could not install the Docker Compose plugin (root required for `{cmd[0]}`)",
                    _DOCKER_MANUAL_INSTALL_HINT,
                )
            ]
        if cp.returncode != 0:
            return [
                OpsResult(
                    False,
                    "Could not install the Docker Compose plugin automatically",
                    _DOCKER_MANUAL_INSTALL_HINT,
                )
            ]

    if not _compose_available():
        return [
            OpsResult(
                False,
                f"Fetched {dest} but `docker compose` is still not usable",
                _DOCKER_MANUAL_INSTALL_HINT,
            )
        ]
    return [
        OpsResult(
            True,
            f"Installed the Docker Compose plugin to {dest}",
            f"Fetched from {url} -- this distro's repos carry no compose package.",
        )
    ]


def _install_linux_compose_plugin() -> list[OpsResult]:
    """Ensure `docker compose` works: distro package first, release binary second."""
    status, packages = _install_packages_from_sets(
        _LINUX_COMPOSE_PACKAGE_SETS, expected_failure=True
    )
    if status == "installed" and _compose_available():
        return [OpsResult(True, f"Installed Docker Compose packages: {', '.join(packages)}")]
    return _install_compose_plugin_binary()


def _ensure_docker_group_membership() -> list[OpsResult]:
    """Add the invoking user to the `docker` group so non-root `docker` calls work.

    The daemon's socket is root:docker 0660, so a fresh `apt-get install
    docker.io` leaves every `docker` call failing with "permission denied
    while trying to connect to the Docker daemon socket" until the user is in
    that group -- and, crucially, until their *login session* is recreated:
    group membership is stamped into a session's credentials at login, so an
    already-running `systemd --user` manager (and every service it spawned,
    including `nyxgpt-api`) keeps the old group set. That is exactly the
    #3632 finding where `nyxgpt ops status` saw Cassandra running from a
    fresh shell while the API-backed web UI reported it absent: the CLI had
    the group, the long-lived API process didn't. Re-login guidance is
    therefore part of the result, not an afterthought.
    """
    user = getpass.getuser()
    if _running_as_root():
        return [OpsResult(True, "Running as root; docker group membership not needed")]
    cp = _privileged_run(["usermod", "-aG", "docker", user])
    if cp is None or cp.returncode != 0:
        return [
            OpsResult(
                False,
                f"Could not add {user!r} to the 'docker' group",
                f"Run: sudo usermod -aG docker {user} && sudo loginctl terminate-user {user}, "
                "reconnect, then re-run `nyxgpt ops install`.",
            )
        ]
    return [
        OpsResult(
            True,
            f"Added {user!r} to the 'docker' group",
            "Group membership only applies to *new* login sessions, so this shell (and "
            "any already-running systemd --user services) still lack it. If docker "
            f"commands still fail: sudo loginctl terminate-user {user}, then reconnect.",
        )
    ]


# Name of the throwaway variable `_docker_hop_preserves_env` passes through a
# candidate hop. It stands in for the real `env=`-forwarded secrets
# (`DJANGO_SUPERUSER_PASSWORD` and friends, see `_glitchtip_ensure_superuser`)
# without putting a real one on a probe's argv.
_HOP_ENV_PROBE_VAR = "NYXGPT_DOCKER_HOP_PROBE"


def _docker_hop_preserves_env(hop: str) -> bool:
    """True if `hop` hands this process's environment through unchanged.

    Two variables are checked because two different mechanisms depend on
    them, and both fail *silently* rather than loudly if the hop resets the
    environment (#3760 review):

    - `HOME`, which `docker-compose.yml` interpolates into every bind-mount
      source. Under sudo's `env_reset` + `always_set_home` (the Amazon
      Linux/RHEL default, i.e. exactly the distro this targets) it becomes
      `/root`, so the observability stack comes up bound to
      `/root/.nyxGPT/volumes/...` while the ownership fixes chown the user's
      home -- Grafana/Prometheus/Loki cannot write their data dirs, and the
      next non-hop run recreates the containers against the user-home mounts,
      abandoning whatever was written under `/root`.
    - an arbitrary caller-supplied variable, standing in for the
      `_run(env=...)` secrets `docker compose exec -e VAR` forwards into a
      container without ever putting the value on argv.

    A hop that fails this check is not used at all: a loud "cannot reach the
    daemon, reconnect" is a better outcome than containers quietly built
    against the wrong paths.
    """
    home = os.environ.get("HOME")
    if not home:  # pragma: no cover - defensive; POSIX logins always set HOME
        return False
    sentinel = "nyxgpt-hop-probe"
    script = f'printf "%s\\n%s" "$HOME" "${_HOP_ENV_PROBE_VAR}"'
    cp = _run(
        _wrap_docker_hop(["sh", "-c", script], hop),
        check=False,
        expected=True,
        env={**os.environ, _HOP_ENV_PROBE_VAR: sentinel},
    )
    return cp.returncode == 0 and cp.stdout == f"{home}\n{sentinel}"


def _docker_hop_reaches_daemon(hop: str) -> bool:
    """True if a `docker` call made through `hop` can talk to the daemon."""
    cp = _run(
        _wrap_docker_hop(["docker", "info", "--format", "{{.ServerVersion}}"], hop),
        check=False,
        expected=True,
    )
    return cp.returncode == 0


def _enable_docker_socket_hop() -> bool:
    """Reach the Docker socket through `sg docker`/`sudo` for the rest of this process.

    `usermod -aG docker` cannot reach an already-open login session: group
    membership is stamped into a session's credentials when it is created. In
    a `nyxgpt cloud deploy` that meant the deploy's second pass died on
    "permission denied while trying to connect to the Docker daemon socket"
    moments after the first pass had created the Cassandra container (#3760).
    Telling the operator to reconnect and start the deploy over is a poor
    answer when ops already holds the privilege it needs.

    `sg docker` is tried first: it applies the group membership just added,
    needs no sudoers assumptions at all, preserves the environment by
    construction, and is the same mechanism the cloud provisioning script
    already validates with `sg docker -c true`. Passwordless sudo
    (`sudo -n --preserve-env`) is the second choice, for a host where the
    group change itself could not be made. Either way the hop must prove it
    preserves the environment before it is used -- see
    `_docker_hop_preserves_env` for why an env-resetting hop is worse than no
    hop.

    Returns True if a hop is now active. The group membership is still added
    either way, so a later login needs no hop at all. Deliberately a last
    resort, tried only *after* the real group change has been attempted and
    found not to have taken effect -- never as a way to skip it.
    """
    global _DOCKER_SOCKET_HOP
    if _DOCKER_SOCKET_HOP is not None:
        return True
    if _running_as_root() or _which("docker") is None:
        return False
    for hop in ("sg", "sudo"):
        if _which(hop) is None:
            continue
        try:
            usable = _docker_hop_reaches_daemon(hop) and _docker_hop_preserves_env(hop)
        except Exception as e:  # pragma: no cover - defensive, mirrors _docker_daemon_reachable
            logger.debug("ops: %s docker probe failed: %s: %s", hop, type(e).__name__, e)
            continue
        if usable:
            _DOCKER_SOCKET_HOP = hop
            return True
    return False


def _ensure_docker_engine() -> list[OpsResult]:
    """Ensure a usable Docker engine + Compose plugin exist before anything needs them.

    `nyxgpt ops install` brings up Cassandra and the whole observability
    stack in containers, so "install Docker first" was an undocumented
    prerequisite the operator had to satisfy by hand -- #3632's finding that
    `install` on a clean Linux box "doesn't install missing docker components
    for observability", and the frictionless-install ask behind it. This step
    reconciles that the same way every other install step reconciles its
    piece: install the packages if missing, start/enable the daemon, and put
    the invoking user in the `docker` group.

    Engine and Compose plugin are reconciled independently, because a distro
    that has one need not have the other: Amazon Linux 2023 packages the
    engine and no compose at all, so its plugin comes from Docker's own
    release binary (#3760). If the group change turns out not to reach this
    already-open session, ops falls back to `sudo -n docker` for the rest of
    the run rather than failing every later Docker step.

    Linux only. macOS's Docker Desktop is a GUI application with a license
    prompt -- installing it unattended is not something `ops install` should
    do behind the operator's back, so there it only reports what's missing.
    Every failure is actionable (the exact command to run by hand) rather
    than fatal to the rest of install: a host that genuinely can't have
    Docker still gets its native api/web/ollama services reconciled.
    """
    if not _is_linux():
        if _which("docker") is None:
            return [
                OpsResult(
                    False,
                    "Docker not found on PATH",
                    "Install Docker Desktop (https://docs.docker.com/desktop/install/mac-install/) "
                    "and start it, then re-run `nyxgpt ops install`.",
                )
            ]
        return [OpsResult(True, "Docker is available")]

    results: list[OpsResult] = []
    if _which("docker") is None:
        results.extend(_install_linux_docker_engine())
        if not any(r.ok for r in results):
            return results

    if _which("docker") is None:
        return [
            *results,
            OpsResult(False, "Docker still not found on PATH", _DOCKER_MANUAL_INSTALL_HINT),
        ]

    if not _compose_available():
        results.extend(_install_linux_compose_plugin())

    # A distro `docker.io` install leaves the unit enabled but, on a
    # container/minimal image, not necessarily started.
    cp = _privileged_run(["systemctl", "enable", "--now", "docker"], expected=True)
    if cp is not None and cp.returncode == 0:
        results.append(OpsResult(True, "Docker daemon enabled and started"))

    if _docker_daemon_reachable():
        results.append(OpsResult(True, "Docker daemon is reachable"))
        return results

    # The group-membership attempt is reported *after* we know whether the
    # daemon ended up reachable: a `usermod` that failed on a host ops then
    # reached through `sudo -n docker` is history, not this step's verdict
    # (#3762). Only when nothing worked does it stay a `[FAIL]`.
    group_results = _ensure_docker_group_membership()
    if _docker_daemon_reachable():
        results.extend(_superseded_attempts(group_results))
        results.append(OpsResult(True, "Docker daemon is reachable"))
    elif _enable_docker_socket_hop():
        hop = _DOCKER_SOCKET_HOP_LABELS[str(_docker_socket_hop())]
        results.extend(_superseded_attempts(group_results))
        results.append(
            OpsResult(
                True,
                f"Docker daemon is reachable via {hop} for the rest of this run",
                "A 'docker' group membership only applies to new login "
                f"sessions, so ops runs Docker through {hop} for the rest of this "
                "process instead of failing every container step. The hop preserves "
                "this session's environment, so Compose bind mounts still resolve "
                "under this user's home. Reconnect (or run: sudo loginctl "
                f"terminate-user {getpass.getuser()}) to drop it.",
            )
        )
    else:
        # Nothing recovered it, so the failed attempt keeps its `[FAIL]`:
        # it is part of why this step failed, not noise to hide.
        results.extend(group_results)
        results.append(
            OpsResult(
                False,
                "Docker is installed but this process cannot reach the daemon",
                "Usually a group-membership change that hasn't reached this login "
                f"session yet. Run: sudo loginctl terminate-user {getpass.getuser()}, "
                "reconnect, then re-run `nyxgpt ops install`.",
            )
        )
    return results


def _docker_access_doctor_issue() -> str | None:
    """`nyxgpt ops doctor` check for a Docker daemon this process can't talk to.

    Distinct from doctor's existing "Missing tool in PATH: docker": here the
    binary *is* present and the daemon may well be running -- the invoking
    user just isn't in the `docker` group, or their session predates the
    membership. That produced #3632's most confusing symptom, `nyxgpt ops
    status` and the web UI disagreeing about whether Cassandra was running,
    because they ran from sessions with different group sets.
    """
    if _which("docker") is None:
        return None
    if _docker_daemon_reachable():
        return None
    hint = ""
    if _is_linux():
        hint = (
            f" -- if you were just added to the 'docker' group, the change only applies to "
            f"new login sessions (run: sudo loginctl terminate-user {getpass.getuser()}, "
            "then reconnect)"
        )
    return (
        "Docker is installed but the daemon is unreachable from this process "
        f"(run: nyxgpt ops install){hint}"
    )


# --- Local Cassandra container lifecycle ---

# Canonical definition of the one ops-managed Docker container in a native-mode
# local deployment (api/web/ollama run natively via Homebrew; see docs/ops.md).
# Mirrors the `cassandra` service in docker-compose.yml so the native and
# Compose paths agree on image/port/volume -- but this container is created and
# managed via plain `docker run`/`docker start`, entirely separate from the
# Compose "cloud/server" stack, so its lifecycle never requires (or pulls in)
# the rest of docker-compose.yml.
CASSANDRA_CONTAINER_NAME = "nyxgpt-cassandra"
# Keep this pin identical to the `cassandra` image tag in docker-compose.yml
# and terraform/main.tf (docker_image.cassandra) -- see docs/docker-compose.md
# for the image-pinning policy and how to bump all three together.
CASSANDRA_IMAGE = "cassandra:5.0.8"
# Must match the cluster name stamped into the Cassandra data directory's
# system keyspace: Cassandra refuses to start when the saved cluster name
# differs from the configured one, so a recreated container without this env
# crash-loops with "Saved cluster name nyxgpt != configured name Test Cluster".
CASSANDRA_CLUSTER_NAME = "nyxgpt"


def _ensure_cassandra_container() -> list[OpsResult]:
    """Ensure the local `nyxgpt-cassandra` Docker container exists and is running.

    Reconciles to the intended state rather than only adding:
    - running: nothing to do.
    - present but not running (exited/created/paused/...): `docker start` it.
    - absent: `docker run` a fresh container from `CASSANDRA_IMAGE`, bind-mounted to
      `volume_dir("cassandra")`, bound to `${NYXGPT_BIND_ADDR:-127.0.0.1}:${CASSANDRA_PORT:-9042}`.

    This is what `nyxgpt ops install` was missing entirely: without it, no
    `nyxgpt` command ever created the container in the first place, so
    `nyxgpt ops restart cassandra` (a plain `docker restart`) had nothing to
    restart on a fresh machine or after the container was removed.
    """
    if _which("docker") is None:
        return [
            OpsResult(
                False,
                "docker not found; cannot ensure local Cassandra container",
                "Install Docker Desktop (or the docker CLI) -- Cassandra is the one "
                "Docker-managed piece of a native-mode local install.",
            )
        ]

    # ~/.nyxGPT/volumes/cassandra is the same host directory docker-compose.yml
    # and terraform/main.tf bind-mount their `cassandra` service/container to --
    # two Cassandra processes writing to it concurrently would corrupt the data
    # directory, so refuse rather than create a second writer (see #3346).
    if terraform_stack_state().get("cassandra") == "running":
        return [
            OpsResult(
                False,
                "Refusing to start native Cassandra: the Terraform-managed Cassandra "
                f"container ({TERRAFORM_CONTAINERS['cassandra']}) is already running and "
                "shares the same ~/.nyxGPT/volumes/cassandra data directory",
                "Run `nyxgpt ops down --terraform` first, or skip native Cassandra.",
            )
        ]

    state = _docker_container_state(CASSANDRA_CONTAINER_NAME)

    if state == "running":
        return [OpsResult(True, f"Cassandra container already running: {CASSANDRA_CONTAINER_NAME}")]

    if state != "absent":
        cp = _run(["docker", "start", CASSANDRA_CONTAINER_NAME], check=False)
        if cp.returncode == 0:
            return [
                OpsResult(True, f"Started existing Cassandra container: {CASSANDRA_CONTAINER_NAME}")
            ]
        details = _output_excerpt(cp)
        return [
            OpsResult(
                False,
                f"Failed to start existing Cassandra container: {CASSANDRA_CONTAINER_NAME}",
                details.strip(),
            )
        ]

    bind_addr = os.environ.get("NYXGPT_BIND_ADDR", "127.0.0.1")
    port = os.environ.get("CASSANDRA_PORT", "9042")
    data_dir = volume_dir("cassandra")
    cmd = [
        "docker",
        "run",
        "-d",
        "--name",
        CASSANDRA_CONTAINER_NAME,
        "--restart",
        "unless-stopped",
        "-p",
        f"{bind_addr}:{port}:9042",
        "-v",
        f"{data_dir}:/var/lib/cassandra",
        "-e",
        f"CASSANDRA_CLUSTER_NAME={CASSANDRA_CLUSTER_NAME}",
        CASSANDRA_IMAGE,
    ]
    cp = _run(cmd, check=False)
    if cp.returncode == 0:
        return [
            OpsResult(
                True,
                f"Created Cassandra container: {CASSANDRA_CONTAINER_NAME} ({CASSANDRA_IMAGE})",
                f"Bound to {bind_addr}:{port}, data persisted in {data_dir}",
            )
        ]
    details = _output_excerpt(cp)
    return [
        OpsResult(
            False,
            f"Failed to create Cassandra container: {CASSANDRA_CONTAINER_NAME}",
            details.strip(),
        )
    ]


# --- Legacy named-volume migration (issue #3346) ---
#
# Before #3346, container data lived in named Docker volumes rather than
# ~/.nyxGPT/volumes/ bind mounts: `nyxgpt_cassandra_data` (native, and -- by
# coincidence of docker-compose.yml's explicit `name: nyxgpt` project name --
# also Compose's `cassandra_data`), `nyxgpt_ollama_data`/`nyxgpt_data` (Compose),
# and `nyxgpt_tf_ollama_data`/`nyxgpt_tf_cassandra_data`/`nyxgpt_tf_nyxgpt_data`
# (Terraform). This copies that data into the new bind-mount directories on
# upgrade so it isn't silently lost. On macOS/Docker Desktop a named volume's
# files live inside the Docker VM, not directly reachable from the host
# filesystem, so the copy runs through a throwaway container rather than a
# plain filesystem copy.

# Pinned to a specific version (no floating/untagged reference), same policy
# as every other third-party image in this file -- see
# docs/docker-compose.md#image-pinning. This one is just a disposable `cp`
# runner, not a long-lived service, so it isn't part of that doc's
# pinned-images table.
MIGRATION_HELPER_IMAGE = "alpine:3.20.3"

# dest volume_dir() component -> legacy Docker volume names to check, in
# priority order (first one found with data wins; see
# `migrate_legacy_volumes`). Cassandra/Ollama/nyxgpt-data can have both a
# Compose-era and a Terraform-era candidate now that both modes share one
# destination directory; only one can be migrated in since merging two
# independent Cassandra data directories isn't safe.
LEGACY_VOLUME_SOURCES: dict[str, list[str]] = {
    "cassandra": ["nyxgpt_cassandra_data", "nyxgpt_tf_cassandra_data"],
    "ollama": ["nyxgpt_ollama_data", "nyxgpt_tf_ollama_data"],
    # Compose's volume key was literally `nyxgpt_data:`, which Compose prefixes
    # with the project name (`name: nyxgpt` in docker-compose.yml) to get
    # `nyxgpt_nyxgpt_data` -- not `nyxgpt_data`.
    "nyxgpt-data": ["nyxgpt_nyxgpt_data", "nyxgpt_tf_nyxgpt_data"],
    "prometheus": ["nyxgpt_prometheus_data"],
    "grafana": ["nyxgpt_grafana_data"],
    "loki": ["nyxgpt_loki_data"],
    "glitchtip-postgres": ["nyxgpt_glitchtip_postgres_data"],
    "glitchtip-uploads": ["nyxgpt_glitchtip_uploads"],
}


def _docker_volume_exists(name: str) -> bool:
    """Return whether a Docker volume named `name` currently exists."""
    if _which("docker") is None:
        return False
    cp = _run(["docker", "volume", "inspect", name], check=False, expected=True)
    return cp.returncode == 0


def _migrate_docker_volume_to_bind_dir(
    volume_name: str, dest_dir: Path, *, label: str
) -> OpsResult:
    """Copy `volume_name`'s contents into `dest_dir` via a throwaway container, then remove it.

    `dest_dir` is assumed already created and empty (checked by the caller,
    `migrate_legacy_volumes`, so this can be tested/called standalone without
    re-deriving that check). Removal is best-effort -- a volume still attached
    to some other container is left behind with a note rather than failing
    the whole migration.
    """
    cp = _run(
        [
            "docker",
            "run",
            "--rm",
            "-v",
            f"{volume_name}:/from:ro",
            "-v",
            f"{dest_dir}:/to",
            MIGRATION_HELPER_IMAGE,
            "sh",
            "-c",
            "cp -a /from/. /to/",
        ],
        check=False,
    )
    if cp.returncode != 0:
        return OpsResult(
            False,
            f"Failed to migrate {label} data from legacy volume '{volume_name}'",
            _cp_details(cp),
        )

    rm = _run(["docker", "volume", "rm", volume_name], check=False, expected=True)
    if rm.returncode == 0:
        return OpsResult(
            True,
            f"Migrated {label} data from legacy volume '{volume_name}' into {dest_dir}",
            "Old volume removed.",
        )
    return OpsResult(
        True,
        f"Migrated {label} data from legacy volume '{volume_name}' into {dest_dir}",
        f"Could not remove the old volume (still in use?): {_cp_details(rm)}",
    )


def _migration_marker_path(dest_name: str) -> Path:
    """Path to `migrate_legacy_volumes`'s per-component "already reconciled" marker.

    Deliberately stored outside `~/.nyxGPT/volumes/<component>/` rather than
    inferred from that directory being non-empty: a freshly-started container
    populates its empty bind mount with new files within seconds of `docker
    compose up`, which an emptiness check can't tell apart from "an earlier
    run already migrated the legacy volume in here" -- that ambiguity is what
    let pre-#3346 data get silently stranded. A marker only appears once this
    function has itself made that determination.
    """
    state_dir = Path.home() / ".nyxGPT" / ".migration-state"
    _ensure_dir(state_dir)
    return state_dir / f"{dest_name}.migrated"


def migrate_legacy_volumes() -> list[OpsResult]:
    """Copy pre-#3346 named-volume data into ~/.nyxGPT/volumes/, then drop the old volumes.

    Idempotent and safe to run on every `nyxgpt ops install` (native and
    `--terraform --local` both do): once a component has been reconciled
    (migrated, or confirmed to have no legacy volume) that's recorded in a
    marker file under `~/.nyxGPT/.migration-state/`, and later runs skip it
    without re-touching `~/.nyxGPT/volumes/<component>/`. Also exposed
    standalone as `nyxgpt ops migrate-volumes` for Compose-only users who
    never run `nyxgpt ops install`.

    If a legacy volume is still found for a component whose destination
    directory is *not yet marked reconciled* but is already non-empty (e.g.
    the new bind-mounted stack was brought up before this ran), migration is
    refused with a loud, actionable failure rather than silently reporting
    success -- auto-merging risks silently overwriting or shadowing whichever
    side holds the data the user actually wants.
    """
    if _which("docker") is None:
        return [OpsResult(True, "Skipped legacy volume migration (docker not found)")]

    results: list[OpsResult] = []
    for dest_name, candidates in LEGACY_VOLUME_SOURCES.items():
        dest_dir = volume_dir(dest_name)
        marker = _migration_marker_path(dest_name)
        if marker.exists():
            results.append(OpsResult(True, f"{dest_name}: already reconciled (nothing to migrate)"))
            continue

        existing = [v for v in candidates if _docker_volume_exists(v)]
        if not existing:
            marker.touch()
            results.append(
                OpsResult(True, f"No legacy volume found for {dest_name} (nothing to migrate)")
            )
            continue

        found, *unmigrated = existing
        if any(dest_dir.iterdir()):
            results.append(
                OpsResult(
                    False,
                    f"{dest_name}: legacy volume '{found}' still holds pre-#3346 data but "
                    f"{dest_dir} is already non-empty -- refusing to auto-migrate. This can "
                    "happen if the new bind-mounted stack was started before running "
                    "`nyxgpt ops migrate-volumes`, which would otherwise silently strand the "
                    "old data.",
                    f"Stop the stack, inspect both {dest_dir} and the legacy volume "
                    f"(docker run --rm -v {found}:/legacy alpine ls -la /legacy), manually merge "
                    f"whichever side holds the data you need, then `docker volume rm {found}` "
                    "once done -- this warning repeats on every run until that volume is gone.",
                )
            )
            continue

        result = _migrate_docker_volume_to_bind_dir(found, dest_dir, label=dest_name)
        if unmigrated:
            note = (
                f"Note: legacy volume(s) {unmigrated} for {dest_name} were also found but not "
                "migrated (only one source can be merged in safely) -- inspect and remove "
                "manually if they hold data you still need."
            )
            result = OpsResult(
                result.ok,
                result.message,
                f"{result.details}\n{note}" if result.details else note,
            )
        if result.ok:
            marker.touch()
        results.append(result)

    return results


def migrate_volumes_cmd(_args) -> int:
    """CLI entrypoint for `nyxgpt ops migrate-volumes`.

    A standalone escape hatch for migrating pre-#3346 named-volume data
    without running the rest of `nyxgpt ops install` -- e.g. for a
    Compose-only user who never runs `install` (that's the native-mode
    reconciler). Safe to re-run; see `migrate_legacy_volumes`.
    """
    results = migrate_legacy_volumes()
    ok = _emit_results("migrate-volumes", results)
    return 0 if ok else 2


# --- Phantom Compose app-tier reconciliation ---


def _detect_phantom_compose_app_containers() -> dict[str, str]:
    """Return {service: state} for app-tier services currently running under Compose.

    In the native mode `nyxgpt ops install` targets, `api`/`web`/`ollama` run
    natively and `cassandra` runs as the one ops-managed Docker container
    (`_ensure_cassandra_container`) -- none of `CORE_APP_SERVICES` should also be
    running as Docker Compose services. A prior raw `docker compose up` (or the
    pre-#3231 observability bring-up, which started every profile-less default
    service too) can leave these running alongside the native ones, colliding on
    the same ports.
    """
    compose = _compose_stack_snapshot()
    return {
        service: state
        for service, state in compose.items()
        if service in CORE_APP_SERVICES and state == "running"
    }


def _reconcile_phantom_compose_app_containers() -> list[OpsResult]:
    """Stop any leaked Compose app-tier containers (api/web/ollama/cassandra).

    Uses `docker compose stop <service>` (not `down`) so containers/volumes are
    preserved -- consistent with `nyxgpt ops` avoiding destructive actions by
    default. This is what makes `nyxgpt ops install` a reconciler instead of an
    additive-only installer: re-running it now cleans up a mixed-mode mess left
    by an earlier run (or a raw `docker compose up`) instead of adding to it.
    """
    if _which("docker") is None:
        return []

    phantoms = _detect_phantom_compose_app_containers()
    if not phantoms:
        return [OpsResult(True, "No phantom Docker Compose app-tier containers detected")]

    results: list[OpsResult] = []
    for service in sorted(phantoms):
        cp = _run(
            ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "stop", service],
            check=False,
        )
        if cp.returncode == 0:
            results.append(
                OpsResult(
                    True,
                    f"Stopped phantom Compose container for {service} (was running "
                    "alongside the native/local deployment)",
                )
            )
        else:
            details = _output_excerpt(cp)
            results.append(
                OpsResult(
                    False,
                    f"Failed to stop phantom Compose container for {service}",
                    details.strip(),
                )
            )
    return results


def _cp_details(cp: subprocess.CompletedProcess[str]) -> str:
    """Concatenate stdout+stderr from a CompletedProcess into one details string."""
    stdout = (cp.stdout or "").strip()
    stderr = (cp.stderr or "").strip()
    return (stdout + ("\n" + stderr if stderr else "")).strip()


def _resolve_locality(args) -> str | None:
    """Validate the `--local`/`--cloud` locality flag shared by `--terraform`/`--kubernetes`.

    Only `--local` is implemented today. `--cloud` is accepted by the CLI
    surface (so it doesn't need a redesign later) but always rejected -- the
    local deployment is the precursor to a future cloud target, not an
    alternative to it (see issue #3344). The AWS substrate itself is
    provisioned by `nyxgpt cloud infra` (#3509); deploying this stack onto
    that instance is #3513, which is what will make `--cloud` meaningful
    here.

    Returns "local" once implemented, or None (having already printed an
    error) if the flag is missing or unimplemented.
    """
    if getattr(args, "cloud", False):
        print(
            "ERROR: --cloud is not yet implemented. Local Terraform/Kubernetes deployment "
            "(--local) is the precursor to a future cloud target -- see docs/terraform.md "
            "and docs/kubernetes.md. To provision the AWS substrate itself, use "
            "`nyxgpt cloud infra apply` (see docs/cloud.md); deploying this stack onto "
            "that instance lands with `nyxgpt cloud deploy`.",
            file=sys.stderr,
        )
        return None
    if not getattr(args, "local", False):
        print(
            "ERROR: --local is required with --terraform/--kubernetes "
            "(the only locality implemented today; pass --local explicitly)",
            file=sys.stderr,
        )
        return None
    return "local"


def _resolve_api_key(explicit: str | None) -> str:
    """Resolve the auth API key for a Terraform/Kubernetes bootstrap: explicit, prompted, or random.

    Prefers an explicitly-passed `--api-key`. Otherwise, when stdin is a TTY,
    prompts for one (hidden input, never echoed or logged) so an operator can
    set a memorable key; if left blank -- or stdin isn't interactive at all
    (e.g. driven from the SRE/admin dashboard or a test) -- falls back to a
    random one so the command still completes non-interactively.
    """
    if explicit:
        return explicit
    if sys.stdin.isatty():
        try:
            entered = getpass.getpass(
                "API key for the deployed stack's [auth] section (blank to auto-generate): "
            )
        except Exception as e:
            logger.warning(
                "Interactive API key prompt failed, auto-generating one instead: %s",
                e,
                extra={"component": "ops"},
            )
            entered = ""
        if entered:
            return entered
    return secrets.token_hex(32)


def _refuse_port_collision(components: list[str]) -> OpsResult | None:
    """Refuse to bring up a new deployment on ports already bound by native/Compose.

    Terraform's containers and the native/Compose stack all default to the
    same host ports (8000/3000/11434/9042). Returns a failing `OpsResult`
    naming the conflicting components -- and what to run instead -- if any of
    `components` are already live natively or via Compose, else None.
    """
    mode = detect_deployment_mode()
    bound = [
        c
        for c in components
        if mode.native.get(c) in ("started", "running") or mode.compose.get(c) == "running"
    ]
    if not bound:
        return None
    return OpsResult(
        False,
        "Refusing to start: port collision with a running native/Compose stack",
        f"{', '.join(sorted(bound))} already serving via native/Compose on the same host "
        "port(s) -- run `nyxgpt ops down` (or stop the conflicting components) before "
        "bringing up the Terraform/Kubernetes deployment.",
    )


# --- Terraform local deployment (`nyxgpt ops install/down --terraform --local`) ---

TERRAFORM_DIR = REPO_ROOT / "terraform"

# Container names terraform/main.tf creates for the core stack (see docs/terraform.md).
TERRAFORM_CONTAINERS: dict[str, str] = {
    "ollama": "nyxgpt-tf-ollama",
    "cassandra": "nyxgpt-tf-cassandra",
    "api": "nyxgpt-tf-api",
    "web": "nyxgpt-tf-web",
}

# Terraform was pulled from homebrew-core after HashiCorp's 2023 BUSL relicense,
# so `brew install terraform` fails -- install from the official tap instead.
HASHICORP_TAP = "hashicorp/tap"

# Matches terraform/variables.tf's `api_image_tag`/`web_image_tag` defaults
# ("local") that terraform/main.tf's `docker_image.api`/`.web` resources
# interpolate into their image `name` -- the tag `_build_terraform_docker_images`
# pre-builds below so `terraform apply`'s own `build {}` block hits Docker's
# layer cache instead of doing real work when the source hasn't changed.
TF_API_IMAGE = "nyxgpt-api:local"
TF_WEB_IMAGE = "nyxgpt-web:local"
# Matches terraform/variables.tf's `web_api_base_url` default.
TF_WEB_API_BASE_URL_DEFAULT = "http://localhost:8000"


def _ensure_terraform_binary() -> list[OpsResult]:
    """Ensure `terraform` is on PATH, installing it via the HashiCorp tap if missing."""
    if _which("terraform") is not None:
        return [OpsResult(True, "terraform already installed")]
    if _which("brew") is None:
        return [
            OpsResult(
                False,
                "terraform not found and Homebrew is unavailable to install it",
                "Install Terraform >= 1.5.0 manually: "
                "https://developer.hashicorp.com/terraform/install",
            )
        ]
    cp = _run(["brew", "tap", HASHICORP_TAP], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, f"brew tap {HASHICORP_TAP} failed", _cp_details(cp))]
    cp = _run(["brew", "install", f"{HASHICORP_TAP}/terraform"], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, f"brew install {HASHICORP_TAP}/terraform failed", _cp_details(cp))]
    if _which("terraform") is None:
        return [OpsResult(False, "terraform install reported success but binary still not on PATH")]
    return [OpsResult(True, f"Installed terraform via {HASHICORP_TAP}")]


def _ensure_terraform_tfvars(api_key: str | None) -> list[OpsResult]:
    """Bootstrap terraform/terraform.tfvars from the example if it doesn't exist yet."""
    tfvars = TERRAFORM_DIR / "terraform.tfvars"
    if tfvars.exists():
        return [OpsResult(True, f"{tfvars} already exists")]
    example = TERRAFORM_DIR / "terraform.tfvars.example"
    if not example.exists():
        return [OpsResult(False, f"Missing {example} to bootstrap tfvars from")]
    key = _resolve_api_key(api_key)
    text = example.read_text(encoding="utf-8")
    text = re.sub(r'repo_path\s*=\s*".*"', lambda _m: f'repo_path    = "{REPO_ROOT}"', text)
    text = re.sub(r'auth_api_key\s*=\s*".*"', lambda _m: f'auth_api_key = "{key}"', text)
    tfvars.write_text(text, encoding="utf-8")
    os.chmod(tfvars, 0o600)
    return [OpsResult(True, f"Bootstrapped {tfvars} from terraform.tfvars.example")]


def _terraform_init_plan_apply() -> list[OpsResult]:
    """Run `terraform init` -> `plan` -> `apply` in terraform/, stopping at the first failure."""
    chdir = f"-chdir={TERRAFORM_DIR}"
    cp = _run(["terraform", chdir, "init", "-input=false"], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, "terraform init failed", _cp_details(cp))]
    results = [OpsResult(True, "terraform init")]

    cp = _run(["terraform", chdir, "plan", "-input=false", "-out=tfplan"], check=False)
    if cp.returncode != 0:
        results.append(OpsResult(False, "terraform plan failed", _cp_details(cp)))
        return results
    results.append(OpsResult(True, "terraform plan"))

    cp = _run(["terraform", chdir, "apply", "-input=false", "-auto-approve", "tfplan"], check=False)
    if cp.returncode != 0:
        results.append(OpsResult(False, "terraform apply failed", _cp_details(cp)))
        return results
    results.append(OpsResult(True, "terraform apply"))
    return results


def _build_terraform_docker_images() -> list[OpsResult]:
    """Build the `nyxgpt-api`/`nyxgpt-web` images the Terraform `--local` deploy
    consumes, skipping each build the app source hasn't changed since (#3414).

    Runs before `terraform init/plan/apply` so `docker_image.api`/`.web` in
    terraform/main.tf (tag `local`, matching `TF_API_IMAGE`/`TF_WEB_IMAGE`
    here) already exist locally in the target state: unchanged source means
    `_docker_build_if_needed` skips the rebuild entirely (reported below,
    mirroring the Homebrew `_install_homebrew_api`/`_web` decision output);
    changed source means it rebuilds now, so terraform's own `build {}` block
    then just hits Docker's layer cache instead of doing the real work again.
    """
    if _which("docker") is None:
        return [OpsResult(False, "docker not found on PATH -- cannot build nyxgpt-api/nyxgpt-web")]

    results: list[OpsResult] = []
    try:
        decision = _docker_build_if_needed(
            TF_API_IMAGE,
            REPO_ROOT,
            fingerprint_paths=_API_IMAGE_FINGERPRINT_PATHS,
            marker_dir=DOCKER_IMAGE_MARKER_DIR,
        )
        results.append(OpsResult(True, f"{TF_API_IMAGE}: {decision}"))
    except RuntimeError as e:
        results.append(OpsResult(False, f"docker build {TF_API_IMAGE} failed", str(e)))

    try:
        decision = _docker_build_if_needed(
            TF_WEB_IMAGE,
            REPO_ROOT / "web",
            fingerprint_paths=[REPO_ROOT / "web"],
            excludes=_WEB_VENDOR_EXCLUDES,
            build_args={"NEXT_PUBLIC_API_BASE_URL": TF_WEB_API_BASE_URL_DEFAULT},
            marker_dir=DOCKER_IMAGE_MARKER_DIR,
        )
        results.append(OpsResult(True, f"{TF_WEB_IMAGE}: {decision}"))
    except RuntimeError as e:
        results.append(OpsResult(False, f"docker build {TF_WEB_IMAGE} failed", str(e)))

    return results


def terraform_stack_state() -> dict[str, str]:
    """{component: docker state} for the Terraform-managed containers (used by status/doctor)."""
    return {
        component: _docker_container_state(name) for component, name in TERRAFORM_CONTAINERS.items()
    }


def _terraform_state_has_resources() -> bool:
    """True if terraform.tfstate records any managed resources.

    ``terraform destroy`` (what ``nyxgpt ops down --terraform`` runs) always
    leaves ``terraform.tfstate`` in place with an empty ``resources`` list --
    that's a clean post-destroy state, not stale state. Only a tfstate that
    still records resources (with no matching containers running) is stale.
    """
    tfstate = TERRAFORM_DIR / "terraform.tfstate"
    try:
        data = json.loads(tfstate.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return True
    return bool(data.get("resources"))


def _terraform_stack_health() -> list[OpsResult]:
    """Report each Terraform-managed container's state, plus the stack's output URLs."""
    results = [
        OpsResult(
            state == "running", f"terraform {component}: {state}", TERRAFORM_CONTAINERS[component]
        )
        for component, state in terraform_stack_state().items()
    ]
    cp = _run(["terraform", f"-chdir={TERRAFORM_DIR}", "output", "-json"], check=False)
    if cp.returncode == 0 and (cp.stdout or "").strip():
        try:
            outputs = json.loads(cp.stdout)
            urls = ", ".join(f"{k}={v.get('value')}" for k, v in outputs.items())
            results.append(OpsResult(True, f"terraform outputs: {urls}"))
        except (ValueError, AttributeError):
            pass
    return results


def _install_terraform_steps(api_key: str | None) -> list[OpsResult]:
    """Run the Terraform bring-up steps and return structured results (no printing).

    Ensures terraform is present (installing via the hashicorp tap if
    missing), bootstraps terraform.tfvars from the example if absent, runs
    init -> plan -> apply, and reports the resulting stack health. Stops at
    the first failing step since each depends on the last (installing the
    binary before generating tfvars before running init, etc.) -- unlike
    `install()`'s native steps, which are independent and best-effort.

    Shared by the `nyxgpt ops install --terraform --local` CLI entrypoint
    (`_install_terraform`) and `install_terraform_local`, the SRE/admin
    dashboard API's structured equivalent.
    """
    collision = _refuse_port_collision(["api", "web", "ollama", "cassandra"])
    if collision is not None:
        _record_ops_action("install", "terraform", "refused", collision.message)
        return [collision]

    logger.info(
        "ops: install --terraform --local starting",
        extra={"component": "ops", "action": "install-terraform"},
    )
    results: list[OpsResult] = []
    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        # Must run first: `_start_observability_stack_terraform` targets
        # self_heal.COMPOSE_FILE and TERRAFORM_NET_OVERRIDE, both of which
        # live under NYXGPT_HOME once synced from the packaged resources
        # (#3621).
        ("sync packaged ops resources", _sync_packaged_resources),
        (
            "clear intentional-stop markers",
            lambda: _clear_intentional_stops(["api", "web", "ollama", "cassandra"]),
        ),
        # Must run before terraform apply: main.tf no longer declares the
        # `nyxgpt_tf_*` docker_volume resources (#3346), so apply would
        # otherwise destroy them -- along with any not-yet-migrated data --
        # as part of reconciling state to the new host-bind-mount config.
        ("migrate legacy volumes", migrate_legacy_volumes),
        ("terraform binary", _ensure_terraform_binary),
        ("terraform tfvars", lambda: _ensure_terraform_tfvars(api_key)),
        # Must run before apply: terraform/main.tf bind-mounts
        # docker/config.docker.ini into the api container (same pattern as
        # docker-compose.yml), so the derived file has to exist first or
        # Docker creates an empty directory in its place.
        ("compose config (derive from native)", _generate_compose_config),
        # Must run before apply: pre-builds (or skips, if source is unchanged
        # since the last build -- #3414) the images `docker_image.api`/`.web`
        # reference by tag, so terraform's own build hits Docker's cache
        # instead of doing the work again.
        ("docker images (source-change detection)", _build_terraform_docker_images),
        ("terraform init/plan/apply", _terraform_init_plan_apply),
        # Must run before the observability stack starts: Grafana's Compose
        # bind-mount auto-creates a missing ~/.nyxGPT/secrets root-owned on
        # Linux (#3432), which then blocks the token write below.
        ("glitchtip secrets dir", _ensure_glitchtip_secrets_dir),
        # Must run before the observability stack starts: Grafana's alerting
        # provisioning (docker/grafana/provisioning/alerting/contact-points.yml)
        # unconditionally reads $__file{/etc/nyxgpt-secrets/slack-webhook-url}
        # and refuses to boot if it's missing -- the native install() path
        # writes this placeholder-or-real secret via the same function before
        # starting its observability stack; the terraform path must too (#3588).
        ("slack webhook secret", _sync_grafana_slack_webhook_secret),
        # After apply (network + core containers exist): bring the observability
        # stack up on the terraform network and auto-provision GlitchTip, so the
        # terraform deploy has the same full SRE view as the native install.
        ("observability stack (terraform network)", _start_observability_stack_terraform),
        ("glitchtip auto-provisioning", _provision_glitchtip),
    ]
    for step_name, fn in steps:
        try:
            step_results = fn()
        except Exception as e:
            results.append(
                OpsResult(False, f"terraform {step_name} raised", f"{type(e).__name__}: {e}")
            )
            step_results = []
        results += step_results
        if step_results and not all(r.ok for r in step_results):
            break
    else:
        results += _terraform_stack_health()

    result, message = _ops_action_outcome(results)
    _record_ops_action("install", "terraform", result, message)
    return results


def install_terraform_local(api_key: str | None = None) -> list[OpsResult]:
    """Structured (non-printing) Terraform local bring-up, for the SRE/admin dashboard API.

    Runs the same steps as `nyxgpt ops install --terraform --local` --
    locality is implicitly "local" here since that's the only target this
    endpoint offers (see `_resolve_locality`) -- and returns the OpsResult
    list directly instead of routing it through `_emit_results`, so a
    FastAPI endpoint can translate it straight to JSON.
    """
    return _install_terraform_steps(api_key)


def _install_terraform(args) -> int:
    """`nyxgpt ops install --terraform --local`: the full Terraform bring-up in one command."""
    if _resolve_locality(args) is None:
        return 2
    results = _install_terraform_steps(getattr(args, "api_key", None))
    ok = _emit_results("install --terraform", results)
    return 0 if ok else 2


def _down_terraform_steps() -> list[OpsResult]:
    """Tear down the Terraform-managed stack and return structured results.

    Brings the observability Compose stack down FIRST: `install --terraform
    --local` starts it on the `nyxgpt-terraform` network, and `terraform
    destroy` can't remove that network while those containers are still
    attached (it times out on the network delete). Then runs `terraform
    destroy` for the core stack.
    """
    if _which("terraform") is None:
        results = [OpsResult(False, "terraform not found on PATH -- nothing to destroy")]
    else:
        results = _stop_observability_stack_terraform()
        cp = _run(
            ["terraform", f"-chdir={TERRAFORM_DIR}", "destroy", "-input=false", "-auto-approve"],
            check=False,
        )
        if cp.returncode == 0:
            results.append(OpsResult(True, "terraform destroy", _cp_details(cp)))
        else:
            results.append(OpsResult(False, "terraform destroy failed", _cp_details(cp)))

    # The `--terraform --local` deploy builds the nyxgpt-api/web images via
    # `docker build`, whose BuildKit layer cache balloons across repeated
    # deploys (17GB+ observed). Reclaim it on teardown -- "down" means we're
    # done, so the cache has served its purpose and the next deploy rebuilds it
    # as needed. NOTE: Docker's build cache is host-global, not per-project, so
    # this also clears cache for any other local Docker builds; that's an
    # acceptable trade on a dev/ops box and is what keeps disk from creeping up.
    # Best-effort: a prune failure never fails the teardown.
    if _which("docker") is not None:
        cp = _run(["docker", "builder", "prune", "-f"], check=False)
        reclaimed = next(
            (ln.strip() for ln in (cp.stdout or "").splitlines() if "reclaimed" in ln.lower()),
            "",
        )
        if cp.returncode == 0:
            results.append(
                OpsResult(
                    True, "docker build cache pruned" + (f" -- {reclaimed}" if reclaimed else "")
                )
            )
        else:
            results.append(OpsResult(True, f"docker build cache prune skipped ({_cp_details(cp)})"))

    result, message = _ops_action_outcome(results)
    _record_ops_action("down", "terraform", result, message)
    return results


def down_terraform() -> list[OpsResult]:
    """Structured (non-printing) `terraform destroy`, for the SRE/admin dashboard API."""
    return _down_terraform_steps()


def _down_terraform(_args) -> int:
    """`nyxgpt ops down --terraform`: `terraform destroy` the Terraform-managed stack."""
    results = _down_terraform_steps()
    ok = _emit_results("down --terraform", results)
    return 0 if ok else 2


# --- Kubernetes local deployment (`nyxgpt ops install/down --kubernetes --local`) ---

K8S_DIR = REPO_ROOT / "k8s"
K8S_NAMESPACE = "nyxgpt"
K8S_IMAGE = "nyxgpt-api:local"

# The local cluster `nyxgpt ops install --kubernetes --local` provisions via `kind`
# when kubectl's current context has no reachable cluster (#3596, owner decision
# 2026-08-03). The name is reserved for nyxgpt: `nyxgpt ops down --kubernetes` only
# ever deletes a kind cluster with this exact name, which is what lets it tell a
# cluster it provisioned apart from a bring-your-own one (minikube, Docker Desktop,
# an operator's own differently-named kind cluster) without needing separate state.
KIND_CLUSTER_NAME = "nyxgpt-local"
KIND_CONTEXT = f"kind-{KIND_CLUSTER_NAME}"

# Official download endpoints for the two CLI tools the local Kubernetes path
# needs. Both are "latest/stable" aliases rather than pinned versions, so a
# clean machine gets a currently-supported binary without nyxGPT having to
# ship (and age out) a version table. kind publishes per-platform release
# assets under GitHub's `releases/latest/download` alias; kubectl publishes
# its current stable version number at `stable.txt`, which then names the
# binary path (see `_kubectl_download_url`).
KIND_DOWNLOAD_URL = (
    "https://github.com/kubernetes-sigs/kind/releases/latest/download/kind-{os}-{arch}"
)
KUBECTL_STABLE_URL = "https://dl.k8s.io/release/stable.txt"
KUBECTL_DOWNLOAD_URL = "https://dl.k8s.io/release/{version}/bin/{os}/{arch}/kubectl"


def _tool_platform() -> tuple[str, str] | None:
    """Return (os, arch) slugs for kind/kubectl release assets, or None if unsupported.

    Both projects use the same Go-style naming (`darwin`/`linux` x
    `amd64`/`arm64`), which covers every platform nyxGPT targets (macOS and
    Linux on Intel or ARM). Anything else falls back to an actionable
    "install it yourself" error rather than guessing at an asset name.
    """
    system = {"Darwin": "darwin", "Linux": "linux"}.get(platform.system())
    arch = {
        "x86_64": "amd64",
        "amd64": "amd64",
        "arm64": "arm64",
        "aarch64": "arm64",
    }.get(platform.machine().lower())
    if system is None or arch is None:
        return None
    return system, arch


def _ensure_nyxgpt_bin_on_path() -> Path:
    """Put `~/.nyxGPT/bin` on this process's PATH (idempotent) and return it.

    Anything `_ensure_cli_tool` downloads lands there, and every later
    `_which`/`_run` in the same process has to be able to find it -- a tool
    installed mid-run is useless if the run that installed it can't invoke
    it. Prepending to `os.environ["PATH"]` covers the current process and
    every subprocess it spawns; `_ensure_kubectl_and_cluster` and
    `_down_kubernetes_steps` call this first so a later `nyxgpt ops` run
    finds the tools again even if the operator never touched their shell
    profile. Creating the directory is left to `_download_tool_binary` (the
    only thing that writes into it) -- a PATH entry that doesn't exist yet is
    simply skipped by the lookup.
    """
    entry = str(NYXGPT_BIN_DIR)
    current = os.environ.get("PATH", "")
    if entry not in current.split(os.pathsep):
        os.environ["PATH"] = f"{entry}{os.pathsep}{current}" if current else entry
    return NYXGPT_BIN_DIR


def _download_tool_binary(name: str, url: str) -> tuple[bool, str]:
    """Download a single-file CLI binary from `url` into `~/.nyxGPT/bin/<name>`.

    Writes to a temp path and `replace()`s it into position so an interrupted
    download can never leave a truncated, executable binary behind. Returns
    (ok, details) rather than an OpsResult so callers can fold the details
    into whatever message fits their context.
    """
    bin_dir = _ensure_nyxgpt_bin_on_path()
    _ensure_dir(bin_dir)
    dest = bin_dir / name
    tmp = dest.with_name(f".{name}.download")
    try:
        with httpx.stream("GET", url, follow_redirects=True, timeout=300.0) as resp:
            resp.raise_for_status()
            with tmp.open("wb") as fh:
                for chunk in resp.iter_bytes():
                    fh.write(chunk)
        tmp.chmod(0o755)
        tmp.replace(dest)
    except (httpx.HTTPError, OSError) as e:
        with contextlib.suppress(OSError):
            tmp.unlink(missing_ok=True)
        return False, f"{url}: {type(e).__name__}: {e}"
    return True, f"downloaded {url} -> {dest}"


def _kind_download_url(system: str, arch: str) -> str:
    """Release-asset URL for the current kind build on this platform."""
    return KIND_DOWNLOAD_URL.format(os=system, arch=arch)


def _kubectl_download_url(system: str, arch: str) -> str:
    """Release URL for the current *stable* kubectl on this platform.

    kubectl has no "latest" alias, so the stable version number is fetched
    first (a few bytes of plain text) and interpolated into the binary path.
    """
    resp = httpx.get(KUBECTL_STABLE_URL, follow_redirects=True, timeout=30.0)
    resp.raise_for_status()
    version = resp.text.strip()
    return KUBECTL_DOWNLOAD_URL.format(version=version, os=system, arch=arch)


def _ensure_cli_tool(
    name: str,
    *,
    brew_formula: str,
    url_for: Callable[[str, str], str],
    manual_url: str,
) -> list[OpsResult]:
    """Ensure `name` is on PATH, installing it for the operator if it isn't (#3724).

    `nyxgpt ops install --kubernetes --local` is specified to bring a local
    Kubernetes deployment up on a machine that has nothing set up yet, so a
    missing `kind`/`kubectl` is nyxGPT's job to resolve, not a prompt to hand
    back to the operator (#3724: telling the user to go install kind was an
    acceptance failure against #3596). Two acquisition paths, in order:

    1. Homebrew, when present -- it's already the native-install prerequisite
       on macOS, and it keeps the tool upgradable through the operator's own
       package manager.
    2. A direct download of the official release binary into
       `~/.nyxGPT/bin` -- the Linux/no-brew path, and the fallback when a
       brew install fails (e.g. no formula for the platform). Needs no root.

    Only if both are unavailable does this fail, and then with a link the
    operator can follow -- never a raw command to paste (CLAUDE.md's
    Operational Command Wrapping rule).
    """
    _ensure_nyxgpt_bin_on_path()
    found = _which(name)
    if found is not None:
        return [OpsResult(True, f"{name} already installed", f"path: {found}")]

    notes: list[str] = []
    if _which("brew") is not None:
        cp = _run(["brew", "install", brew_formula], check=False)
        if cp.returncode == 0 and _which(name) is not None:
            return [OpsResult(True, f"Installed {name} via Homebrew", _cp_details(cp))]
        notes.append(
            f"Homebrew could not supply {name} (falling back to a direct download): "
            + (_cp_details(cp) or "install reported success but the binary was still missing")
        )

    target = _tool_platform()
    if target is None:
        notes.append(
            f"No prebuilt {name} for {platform.system()}/{platform.machine()}. "
            f"Install it manually: {manual_url}"
        )
        return [
            OpsResult(
                False, f"{name} is missing and nyxgpt cannot install it here", "\n".join(notes)
            )
        ]

    try:
        url = url_for(*target)
    except httpx.HTTPError as e:
        notes.append(f"Could not resolve the {name} download URL: {type(e).__name__}: {e}")
        return [
            OpsResult(
                False,
                f"{name} is missing and nyxgpt could not download it",
                "\n".join([*notes, f"Install it manually: {manual_url}"]),
            )
        ]

    ok, details = _download_tool_binary(name, url)
    notes.append(details)
    if not ok:
        notes.append(f"Install it manually: {manual_url}")
        return [
            OpsResult(
                False, f"{name} is missing and nyxgpt could not download it", "\n".join(notes)
            )
        ]
    if _which(name) is None:
        notes.append(f"Install it manually: {manual_url}")
        return [OpsResult(False, f"Installed {name} but it is still not on PATH", "\n".join(notes))]
    return [OpsResult(True, f"Installed {name} into {NYXGPT_BIN_DIR}", "\n".join(notes))]


def _ensure_kind_binary() -> list[OpsResult]:
    """Install `kind` if it's missing so a local cluster can be provisioned (#3724)."""
    return _ensure_cli_tool(
        "kind",
        brew_formula="kind",
        url_for=_kind_download_url,
        manual_url="https://kind.sigs.k8s.io/#installation",
    )


def _ensure_kubectl_binary() -> list[OpsResult]:
    """Install `kubectl` if it's missing -- same rationale as `_ensure_kind_binary` (#3724)."""
    return _ensure_cli_tool(
        "kubectl",
        brew_formula="kubernetes-cli",
        url_for=_kubectl_download_url,
        manual_url="https://kubernetes.io/docs/tasks/tools/",
    )


def _kind_cluster_exists(name: str = KIND_CLUSTER_NAME) -> bool:
    """Return whether a kind cluster named `name` already exists."""
    cp = _run(["kind", "get", "clusters"], check=False, expected=True)
    if cp.returncode != 0:
        return False
    return name in (cp.stdout or "").split()


def _create_kind_cluster(name: str = KIND_CLUSTER_NAME) -> list[OpsResult]:
    """Create the local `kind` cluster nyxgpt provisions when no cluster is reachable."""
    cp = _run(["kind", "create", "cluster", "--name", name, "--wait", "60s"], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, f"kind create cluster --name {name} failed", _cp_details(cp))]
    return [OpsResult(True, f"Created local kind cluster: {name}", _cp_details(cp))]


def _delete_kind_cluster(name: str = KIND_CLUSTER_NAME) -> list[OpsResult]:
    """Delete the named kind cluster if it exists; no-op (not a failure) if it doesn't."""
    if not _kind_cluster_exists(name):
        return [OpsResult(True, f"kind cluster {name} already absent -- nothing to delete")]
    cp = _run(["kind", "delete", "cluster", "--name", name], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, f"kind delete cluster --name {name} failed", _cp_details(cp))]
    return [OpsResult(True, f"Deleted local kind cluster: {name}", _cp_details(cp))]


def _ensure_kubectl_and_cluster() -> list[OpsResult]:
    """Check `kubectl` is on PATH and a cluster is reachable, provisioning one if not.

    Bring-your-own-cluster stays supported unchanged: if kubectl's current context
    already reaches a cluster (minikube, Docker Desktop, an existing kind cluster,
    a remote context, ...) that cluster is used as-is and nothing is provisioned.
    Only when no cluster is reachable at all does this fall back to `kind` (#3596,
    owner decision 2026-08-03: kind is the provisioned local substrate) --
    reusing the `nyxgpt-local` cluster from a previous run if one is already there,
    or creating it fresh otherwise. `kubectl` and `kind` are installed here when
    they're missing (`_ensure_cli_tool`, #3724) rather than being handed back to
    the operator as homework: `--local` is meant to work on a machine with
    nothing set up. Docker stays a genuine external prerequisite (it needs a
    privileged system install / Docker Desktop), so a missing one produces an
    actionable error naming where to get it rather than a raw command to run.
    """
    results: list[OpsResult] = []
    _ensure_nyxgpt_bin_on_path()
    if _which("kubectl") is None:
        results += _ensure_kubectl_binary()
        if not all(r.ok for r in results):
            return results

    cp = _run(["kubectl", "cluster-info"], check=False, expected=True)
    if cp.returncode == 0:
        return results + [
            OpsResult(True, "Kubernetes cluster reachable", f"context: {_kubectl_context()}")
        ]

    if _which("kind") is None:
        results += _ensure_kind_binary()
        if not all(r.ok for r in results):
            return results
    if _which("docker") is None:
        return results + [
            OpsResult(
                False,
                "No reachable Kubernetes cluster, and kind needs Docker to create one",
                "Install/start Docker so `nyxgpt ops install --kubernetes --local` can "
                "provision a local kind cluster.",
            )
        ]

    if _kind_cluster_exists():
        cp = _run(["kubectl", "config", "use-context", KIND_CONTEXT], check=False)
        if cp.returncode != 0:
            return results + [
                OpsResult(
                    False, f"kubectl config use-context {KIND_CONTEXT} failed", _cp_details(cp)
                )
            ]
        results.append(OpsResult(True, f"Reusing existing kind cluster: {KIND_CLUSTER_NAME}"))
    else:
        results += _create_kind_cluster()
        if not all(r.ok for r in results):
            return results

    cp = _run(["kubectl", "cluster-info"], check=False)
    if cp.returncode != 0:
        return results + [
            OpsResult(False, "Provisioned kind cluster is not reachable", _cp_details(cp))
        ]
    return results + [
        OpsResult(True, "Kubernetes cluster reachable", f"context: {_kubectl_context()}")
    ]


def _kubectl_context() -> str:
    """Return kubectl's current context name (e.g. `kind-nyxgpt`, `docker-desktop`), or "" if unset."""
    cp = _run(["kubectl", "config", "current-context"], check=False, expected=True)
    return (cp.stdout or "").strip()


def _build_and_load_k8s_image(
    image: str = K8S_IMAGE,
    *,
    context: Path = REPO_ROOT,
    fingerprint_paths: list[Path] | None = None,
    excludes: frozenset[str] = frozenset(),
    build_args: dict[str, str] | None = None,
) -> list[OpsResult]:
    """Build `image` from `context` and load it into the current cluster's image cache.

    Docker Desktop's built-in cluster shares the host's image cache, so a
    build alone is enough there. kind/minikube each need an explicit
    load step; an unrecognized cluster type is treated the same way the
    documented manual flow would be -- skip the load and tell the operator
    to do it themselves if their cluster doesn't share the host cache.

    `image` defaults to the mutable `nyxgpt-api:local` tag `nyxgpt ops
    install --kubernetes` uses; `nyxgpt ops deploy --kubernetes` (via
    `canary.deploy`) passes a versioned tag instead (see
    `build_and_load_k8s_image` / #3409). `context`/`fingerprint_paths`/
    `excludes`/`build_args` default to the `nyxgpt-api` image's build (repo
    root, `_API_IMAGE_FINGERPRINT_PATHS`); `canary.deploy` overrides them for
    the `web` component to build `web/` with `_WEB_VENDOR_EXCLUDES` and the
    `NEXT_PUBLIC_API_BASE_URL` build arg (#3419), mirroring
    `_build_terraform_docker_images`'s web build. Either way the build
    itself is gated by `_docker_build_if_needed` (#3414): a versioned tag is
    always missing locally the first time (so it always builds), while the
    repeated `:local` tag skips the rebuild once the source stops changing
    between installs, mirroring the Homebrew reinstall-if-needed behavior
    from #3406.
    """
    if _which("docker") is None:
        return [OpsResult(False, f"docker not found on PATH -- cannot build the {image} image")]
    try:
        decision = _docker_build_if_needed(
            image,
            context,
            fingerprint_paths=fingerprint_paths or _API_IMAGE_FINGERPRINT_PATHS,
            excludes=excludes,
            build_args=build_args,
            marker_dir=DOCKER_IMAGE_MARKER_DIR,
        )
    except RuntimeError as e:
        return [OpsResult(False, "docker build failed", str(e))]
    results = [OpsResult(True, f"{image}: {decision}")]

    cluster_context = _kubectl_context()
    if "docker-desktop" in cluster_context:
        results.append(
            OpsResult(True, "Docker Desktop cluster shares the host image cache -- skipped load")
        )
        return results
    if cluster_context.startswith("kind-") and _which("kind") is not None:
        cluster_name = cluster_context.removeprefix("kind-")
        cp = _run(["kind", "load", "docker-image", image, "--name", cluster_name], check=False)
        if cp.returncode != 0:
            results.append(OpsResult(False, "kind load docker-image failed", _cp_details(cp)))
        else:
            results.append(OpsResult(True, f"Loaded {image} into kind cluster {cluster_name}"))
        return results
    if _which("minikube") is not None:
        cp = _run(["minikube", "image", "load", image], check=False)
        if cp.returncode != 0:
            results.append(OpsResult(False, "minikube image load failed", _cp_details(cp)))
        else:
            results.append(OpsResult(True, f"Loaded {image} into minikube"))
        return results
    results.append(
        OpsResult(
            True,
            f"Unrecognized cluster context {cluster_context!r} -- skipped image load",
            "If this cluster doesn't share the host's image cache, load "
            f"{image} into it manually before the Pods can start.",
        )
    )
    return results


def build_and_load_k8s_image(
    image: str,
    *,
    context: Path | None = None,
    fingerprint_paths: list[Path] | None = None,
    excludes: frozenset[str] = frozenset(),
    build_args: dict[str, str] | None = None,
) -> list[OpsResult]:
    """Build and load a specific, caller-chosen image tag (used by `nyxgpt ops deploy --kubernetes`).

    Public wrapper around `_build_and_load_k8s_image` for cross-module use
    (`canary.deploy`) -- the mutable-`:local`-tag install flow keeps calling
    the private function directly with its default. `canary.deploy` calls
    this with no extra kwargs for the `api` component (forwarding only
    `image`, identical to the original single-argument call) and with
    `web/`'s context/fingerprint/build-args for the `web` component (#3419)
    -- only kwargs the caller actually supplied are forwarded, so the `api`
    call path is unchanged.
    """
    kwargs: dict[str, Any] = {}
    if context is not None:
        kwargs["context"] = context
    if fingerprint_paths is not None:
        kwargs["fingerprint_paths"] = fingerprint_paths
    if excludes:
        kwargs["excludes"] = excludes
    if build_args is not None:
        kwargs["build_args"] = build_args
    return _build_and_load_k8s_image(image, **kwargs)


def _ensure_k8s_secret(api_key: str | None) -> list[OpsResult]:
    """Bootstrap k8s/secret.yaml from the example if it doesn't exist yet (never committed)."""
    secret_path = K8S_DIR / "secret.yaml"
    if secret_path.exists():
        return [OpsResult(True, f"{secret_path} already exists")]
    example = K8S_DIR / "secret.example.yaml"
    if not example.exists():
        return [OpsResult(False, f"Missing {example} to bootstrap the secret from")]
    key = _resolve_api_key(api_key)
    text = example.read_text(encoding="utf-8")
    text = re.sub(r'api-key:\s*".*"', lambda _m: f'api-key: "{key}"', text)
    secret_path.write_text(text, encoding="utf-8")
    os.chmod(secret_path, 0o600)
    return [OpsResult(True, f"Bootstrapped {secret_path} from secret.example.yaml")]


def _kubectl_apply_kustomization() -> list[OpsResult]:
    """Apply `k8s/`'s kustomization (namespace, RBAC, ConfigMap, Secret, Deployments, Service)."""
    cp = _run(["kubectl", "apply", "-k", str(K8S_DIR)], check=False)
    if cp.returncode != 0:
        return [OpsResult(False, "kubectl apply -k k8s/ failed", _cp_details(cp))]
    return [OpsResult(True, "kubectl apply -k k8s/", _cp_details(cp))]


def _k8s_stack_health() -> list[OpsResult]:
    """Snapshot of Pod/Service health in the `nyxgpt` namespace right after apply.

    A one-shot snapshot, not a wait-until-ready loop -- Pods may still be
    starting when this runs; re-check with `nyxgpt ops status`. No HPA check
    here -- the stable/canary Deployments deliberately have none (autoscaling
    would fight canary.py's replica-count-based traffic split; see #3409).
    """
    results: list[OpsResult] = []

    cp = _run(
        [
            "kubectl",
            "-n",
            K8S_NAMESPACE,
            "get",
            "pods",
            "-o",
            "jsonpath={range .items[*]}{.metadata.name}={.status.phase};{end}",
        ],
        check=False,
    )
    if cp.returncode != 0:
        results.append(OpsResult(False, "Could not read pod status", _cp_details(cp)))
    else:
        entries = [e for e in (cp.stdout or "").split(";") if e]
        if not entries:
            results.append(OpsResult(False, f"No pods found in namespace {K8S_NAMESPACE}"))
        for entry in entries:
            name, _, phase = entry.partition("=")
            results.append(OpsResult(phase == "Running", f"pod {name}: {phase}"))

    for svc in ("nyxgpt-api", "nyxgpt-web"):
        cp = _run(
            ["kubectl", "-n", K8S_NAMESPACE, "get", "svc", svc, "--no-headers"],
            check=False,
            expected=True,
        )
        results.append(
            OpsResult(
                cp.returncode == 0,
                f"Service {svc}" + (" found" if cp.returncode == 0 else " not found"),
            )
        )
    return results


def _build_and_load_k8s_web_image() -> list[OpsResult]:
    """Build/load `nyxgpt-web:local`, the web canary pair's image (#3419).

    Mirrors `_build_terraform_docker_images`'s web build: context is `web/`
    (not the repo root), fingerprinted on `web/` itself (excluding
    `_WEB_VENDOR_EXCLUDES` build artifacts) rather than the whole build
    context, with the same `NEXT_PUBLIC_API_BASE_URL` build arg default
    Terraform's local deploy uses -- this is inlined into the browser bundle
    at build time, and like Terraform's containers, a k8s Pod is only
    reachable from the operator's own workstation (via `kubectl
    port-forward`), so the same host-local default applies.
    """
    return _build_and_load_k8s_image(
        TF_WEB_IMAGE,
        context=REPO_ROOT / "web",
        fingerprint_paths=[REPO_ROOT / "web"],
        excludes=_WEB_VENDOR_EXCLUDES,
        build_args={"NEXT_PUBLIC_API_BASE_URL": TF_WEB_API_BASE_URL_DEFAULT},
    )


def _install_kubernetes_steps(api_key: str | None) -> list[OpsResult]:
    """Run the Kubernetes bring-up steps and return structured results (no printing).

    Prereq checks (cluster reachable, kubectl present), builds and loads
    `nyxgpt-api:local` and `nyxgpt-web:local`, bootstraps k8s/secret.yaml
    (prompting for the API key, never committing it), applies the
    kustomization (which now includes the web stable/canary pair -- #3419),
    and snapshots Pod/Service health. Stops at the first failing step, same
    rationale as `_install_terraform_steps`.

    Shared by the `nyxgpt ops install --kubernetes --local` CLI entrypoint
    (`_install_kubernetes`) and `install_kubernetes_local`, the SRE/admin
    dashboard API's structured equivalent.
    """
    collision = _refuse_port_collision(["api", "web"])
    if collision is not None:
        _record_ops_action("install", "kubernetes", "refused", collision.message)
        return [collision]

    logger.info(
        "ops: install --kubernetes --local starting",
        extra={"component": "ops", "action": "install-kubernetes"},
    )
    results: list[OpsResult] = []
    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        ("clear intentional-stop markers", lambda: _clear_intentional_stops(["api", "web"])),
        ("cluster prerequisites", _ensure_kubectl_and_cluster),
        ("build/load api image", _build_and_load_k8s_image),
        ("build/load web image", _build_and_load_k8s_web_image),
        ("secret bootstrap", lambda: _ensure_k8s_secret(api_key)),
        ("apply kustomization", _kubectl_apply_kustomization),
    ]
    for step_name, fn in steps:
        try:
            step_results = fn()
        except Exception as e:
            results.append(
                OpsResult(False, f"kubernetes {step_name} raised", f"{type(e).__name__}: {e}")
            )
            step_results = []
        results += step_results
        if step_results and not all(r.ok for r in step_results):
            break
    else:
        results += _k8s_stack_health()

    result, message = _ops_action_outcome(results)
    _record_ops_action("install", "kubernetes", result, message)
    return results


def install_kubernetes_local(api_key: str | None = None) -> list[OpsResult]:
    """Structured (non-printing) Kubernetes local bring-up, for the SRE/admin dashboard API.

    Runs the same steps as `nyxgpt ops install --kubernetes --local` --
    locality is implicitly "local" here since that's the only target this
    endpoint offers (see `_resolve_locality`) -- and returns the OpsResult
    list directly instead of routing it through `_emit_results`, so a
    FastAPI endpoint can translate it straight to JSON.
    """
    return _install_kubernetes_steps(api_key)


def _install_kubernetes(args) -> int:
    """`nyxgpt ops install --kubernetes --local`: the full k8s bring-up in one command."""
    if _resolve_locality(args) is None:
        return 2
    results = _install_kubernetes_steps(getattr(args, "api_key", None))
    ok = _emit_results("install --kubernetes", results)
    return 0 if ok else 2


def _down_kubernetes_steps() -> list[OpsResult]:
    """Remove the `nyxgpt` namespace's Kubernetes resources and return structured results.

    Also tears down the local `kind` cluster (#3596) *iff* kubectl's current context is
    the `nyxgpt-local` cluster nyxgpt reserves for itself (see `_ensure_kubectl_and_cluster`)
    -- a bring-your-own cluster (minikube, Docker Desktop, an operator's own differently
    named kind cluster) is never destroyed, only the deployment inside it is. This is what
    keeps "never destroys a cluster nyxgpt did not create" true without needing a separate
    flag or state file: the reserved name is the only signal, and it's authoritative by
    construction -- `_ensure_kubectl_and_cluster` is the only code path that ever creates a
    cluster by that name.

    Puts `~/.nyxGPT/bin` on PATH first so a `kubectl`/`kind` that a previous
    `install --kubernetes --local` downloaded there (#3724) is still found by
    the teardown that has to undo it, even from a shell that never had that
    directory on its own PATH.
    """
    _ensure_nyxgpt_bin_on_path()
    if _which("kubectl") is None:
        results = [OpsResult(False, "kubectl not found on PATH -- nothing to tear down")]
    else:
        cp = _run(["kubectl", "delete", "-k", str(K8S_DIR), "--ignore-not-found"], check=False)
        if cp.returncode == 0:
            results = [
                OpsResult(
                    True, "kubectl delete -k k8s/ (namespace and all resources)", _cp_details(cp)
                )
            ]
        else:
            results = [OpsResult(False, "kubectl delete -k k8s/ failed", _cp_details(cp))]

        if results[-1].ok and _kubectl_context() == KIND_CONTEXT and _which("kind") is not None:
            results += _delete_kind_cluster()

    result, message = _ops_action_outcome(results)
    _record_ops_action("down", "kubernetes", result, message)
    return results


def down_kubernetes() -> list[OpsResult]:
    """Structured (non-printing) `kubectl delete -k k8s/`, for the SRE/admin dashboard API."""
    return _down_kubernetes_steps()


def _down_kubernetes(_args) -> int:
    """`nyxgpt ops down --kubernetes`: remove the `nyxgpt` namespace's Kubernetes resources."""
    results = _down_kubernetes_steps()
    ok = _emit_results("down --kubernetes", results)
    return 0 if ok else 2


def port_forward(args) -> int:
    """`nyxgpt ops port-forward`: forward the Kubernetes web Service to localhost.

    `k8s/`'s Services are ClusterIP-only -- there's no Ingress/LoadBalancer
    (see docs/kubernetes.md#4-verify) -- so `kubectl port-forward` is the
    only way to reach `nyxgpt-web` from the operator's own workstation. This
    wraps that invocation so operators never type the raw `kubectl` command
    themselves, per CLAUDE.md's Operational Command Wrapping requirement;
    `nyxgpt up --kubernetes` points here instead of printing it directly.

    Runs in the foreground until interrupted (Ctrl-C), same as `kubectl
    port-forward` itself -- there's no "done" state to return early from.
    """
    if _which("kubectl") is None:
        print("[FAIL] kubectl not found on PATH", file=sys.stderr)
        return 2

    local_port = getattr(args, "port", 3000) or 3000
    logger.info(
        "ops: port-forward starting",
        extra={"component": "ops", "action": "port-forward", "local_port": local_port},
    )
    print(
        f"Forwarding http://127.0.0.1:{local_port} -> "
        f"{K8S_NAMESPACE}/svc/nyxgpt-web:3000 (Ctrl-C to stop)..."
    )
    try:
        cp = subprocess.run(
            [
                "kubectl",
                "-n",
                K8S_NAMESPACE,
                "port-forward",
                "svc/nyxgpt-web",
                f"{local_port}:3000",
            ]
        )
    except KeyboardInterrupt:
        return 0
    return cp.returncode


def infra_status() -> dict[str, Any]:
    """Honest, status-only deployment status for the Infrastructure admin page (see #3410).

    Reports which mode is actually running (native/compose/terraform/
    kubernetes/none) and each mode's component state, mirroring the
    sections `nyxgpt ops status` prints (see `status`) as JSON. Distinguishes
    a probe that couldn't be run at all from this vantage point --
    `probe_available: False` -- from a probe that ran and found nothing, so
    a caller (the web UI) can render "cannot determine from this deployment
    mode" instead of a false "NOT DEPLOYED" when e.g. the API process has no
    docker socket. This page has no install/destroy actions: those are
    `nyxgpt ops` CLI-only (see docs/terraform.md / docs/kubernetes.md). Also
    reports `serving`, which instance/service is currently handling traffic
    (see `_serving_status`) -- traffic *control* stays on the canary page.

    Kubernetes refines this further (#3468): `configured` reports whether a
    kubeconfig current-context exists at all (kubectl missing counts as not
    configured, since there's then no context to read). No configured
    cluster means there was never anything to be unreachable -- that's a
    confidently-determined NOT DEPLOYED, not CANNOT DETERMINE. The latter is
    reserved for a *configured* context the probe couldn't reach (timeout,
    connection refused to a cluster that's meant to exist, auth failure),
    preserving #3410's original false-NOT-DEPLOYED protection for that case.

    `compose_probe_available` extends the same "can't determine" distinction
    to the `compose` section (#3588): `False` means `docker compose ps`
    couldn't be queried from this vantage point at all (no `docker`, or the
    Compose file isn't reachable -- e.g. a Terraform-managed api container
    missing the bind mount), so an empty `compose` dict must not be read as
    "nothing running" -- see `self_heal.compose_probe_available`.
    """
    mode_info = detect_deployment_mode()

    docker_available = _which("docker") is not None
    tf_state = terraform_stack_state()
    terraform = {
        "probe_available": docker_available,
        "deployed": docker_available and any(state != "absent" for state in tf_state.values()),
        "containers": tf_state,
    }

    kubectl_available = _which("kubectl") is not None
    kubernetes_context = _kubectl_context() if kubectl_available else ""
    kubernetes_configured = bool(kubernetes_context)
    pods: list[str] = []
    # No kubeconfig/current-context means no cluster was ever configured here --
    # that's a confidently-determined NOT DEPLOYED (#3468), not the CANNOT
    # DETERMINE state reserved for a *configured* cluster the probe couldn't
    # reach (kubectl missing entirely is folded into "not configured" too,
    # since there's no context to read either way).
    kubernetes_probe_available = not kubernetes_configured
    if kubernetes_configured:
        cp = _run(
            ["kubectl", "-n", K8S_NAMESPACE, "get", "pods", "--no-headers"],
            check=False,
            expected=True,
        )
        kubernetes_probe_available = cp.returncode == 0
        if kubernetes_probe_available:
            pods = [line for line in (cp.stdout or "").splitlines() if line.strip()]
    kubernetes = {
        "available": kubectl_available,
        "configured": kubernetes_configured,
        "probe_available": kubernetes_probe_available,
        "deployed": bool(pods),
        "namespace": K8S_NAMESPACE,
        "pods": pods,
        # (#3596) which cluster is configured, and whether it's the local `kind`
        # cluster nyxgpt provisions when nothing else is reachable, vs. a
        # bring-your-own cluster (minikube, Docker Desktop, a remote context, ...).
        "context": kubernetes_context,
        "provisioned": kubernetes_context == KIND_CONTEXT,
    }

    native_running = any(state in ("started", "running") for state in mode_info.native.values())
    if terraform["deployed"]:
        running_mode = "terraform"
    elif kubernetes["deployed"]:
        running_mode = "kubernetes"
    elif mode_info.compose:
        running_mode = "compose"
    elif native_running:
        running_mode = "native"
    else:
        running_mode = "none"

    return {
        "mode": running_mode,
        "native": mode_info.native,
        "compose": mode_info.compose,
        "compose_probe_available": self_heal.compose_probe_available(),
        "conflicts": sorted(mode_info.conflicts),
        "terraform": terraform,
        "kubernetes": kubernetes,
        "serving": _serving_status(running_mode),
    }


def _serving_status(running_mode: str) -> dict[str, Any]:
    """Which instance/service is currently serving traffic (#3410's third duty for this page).

    Traffic splitting only exists in Kubernetes mode -- native/Compose/
    Terraform each run exactly one instance of every component, so it
    serves 100% of traffic by construction. Only Kubernetes mode delegates
    to `canary.status()` for the stable/canary weight and per-track health;
    everywhere else this reports the single-instance fact directly rather
    than duplicating canary's Kubernetes-only probing. Traffic *control*
    stays on the canary page (#3409) -- this only reports the current split.

    Reports every canary-capable component (api, web -- see #3419) under
    `components`, plus the `api` fields spread at the top level unchanged
    for backward compatibility with existing callers/tests that only knew
    about a single component.
    """
    if running_mode != "kubernetes":
        return {
            "supported": False,
            "message": (
                "Single instance serving 100% of traffic -- traffic splitting is a "
                "Kubernetes-mode feature (see the Canary page)."
            ),
        }

    from nyxgpt import canary as canary_module

    components: dict[str, Any] = {}
    for key in ("api", "web"):
        component_status = canary_module.status(component=key)
        components[key] = {
            "active": component_status["active"],
            "weight_percent": component_status["weight_percent"],
            "stable": component_status["stable"],
            "canary": component_status["canary"],
        }

    return {
        "supported": True,
        "components": components,
        **components["api"],
    }


def _install_config() -> list[OpsResult]:
    """Ensure ``~/.nyxGPT/config.ini`` exists, running the setup wizard if missing.

    First-run experience: on a fresh machine `nyxgpt ops install` has no
    config to install services against, so this step launches the interactive
    wizard (the same one behind `nyxgpt wizard`) to create it before any other
    step runs. When stdin is not a TTY (CI, scripted installs) the wizard
    cannot prompt, so the step fails with instructions instead of hanging.
    """
    dst = Path.home() / ".nyxGPT" / "config.ini"
    if dst.exists():
        return [OpsResult(True, "Config already exists", str(dst))]

    if not sys.stdin.isatty():
        return [
            OpsResult(
                False,
                "No config.ini found and stdin is not a TTY -- run `nyxgpt wizard` first",
                str(dst),
            )
        ]

    from nyxgpt.wizard import run_wizard

    print("\nNo config.ini found. Launching setup wizard...\n")
    if run_wizard(output_path=dst) != 0:
        return [OpsResult(False, "Wizard did not complete", str(dst))]
    return [OpsResult(True, "Created config.ini via wizard", str(dst))]


def install(args) -> int:
    """CLI entrypoint for `nyxgpt ops install`.

    Reconciles the local machine to the intended native-mode topology (see
    docs/ops.md): first ensuring ~/.nyxGPT/config.ini exists (launching the
    interactive setup wizard on a fresh machine -- see `_install_config`),
    then migrating any pre-#3346 named-volume data into
    ~/.nyxGPT/volumes/ (see `migrate_legacy_volumes`), then stopping any
    phantom Docker Compose app-tier containers leaked from an earlier run or
    a raw `docker compose up`, then ensuring the
    local Cassandra container plus every other install step (scripts, web deps,
    MCP deps, Cassandra LaunchAgent, Ollama logs LaunchAgent, Ollama env
    LaunchAgent, Homebrew formulas, the native Ollama service (including
    pointing it at the shared model store -- see `_ensure_ollama_service`,
    #3431), log symlinks, env sync from config.ini, the observability stack)
    -- printing an OK/FAIL line per result. A failure in one step doesn't
    stop the rest from running.

    The observability step (Grafana/Loki/Jaeger/GlitchTip) runs by default so
    a fresh install comes up with the full SRE view already populated --
    pass `--skip-observability` to opt out (e.g. on a host with no Docker,
    or to keep those Compose profiles stopped for resource reasons).

    Returns 0 if every step succeeded, else 2.
    """
    if getattr(args, "terraform", False) and getattr(args, "kubernetes", False):
        print("ERROR: --terraform and --kubernetes are mutually exclusive", file=sys.stderr)
        return 2
    if getattr(args, "terraform", False):
        return _install_terraform(args)
    if getattr(args, "kubernetes", False):
        return _install_kubernetes(args)

    logger.info("ops: install starting", extra={"component": "ops", "action": "install"})

    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        # Must run first: every step below that reads a Compose file, config
        # template, launchd/systemd unit template, or helper script assumes
        # the packaged copies are already synced to NYXGPT_HOME (#3621).
        ("sync packaged ops resources", _sync_packaged_resources),
        (
            "clear intentional-stop markers",
            lambda: _clear_intentional_stops(["api", "web", "ollama", "cassandra"]),
        ),
        ("config", _install_config),
        # Everything container-backed below (Cassandra, the observability
        # stack) needs a working engine, and requiring the operator to
        # install Docker by hand first was itself an acceptance failure
        # (#3632) -- so reconcile it here rather than assuming it.
        ("docker engine", _ensure_docker_engine),
        ("migrate legacy volumes", migrate_legacy_volumes),
        ("phantom compose reconciliation", _reconcile_phantom_compose_app_containers),
        ("web deps", _ensure_web_deps),
        ("mcp deps", _ensure_mcp_deps),
        ("cassandra container", _ensure_cassandra_container),
        ("cassandra log follower service", _install_cassandra_log_follower_service),
        ("ollama logs follower service", _install_ollama_log_follower_service),
        ("ollama env agent", _install_ollama_env_agent),
        ("native api service", _install_native_api),
        ("native web service", _install_native_web),
        ("ollama service", _ensure_native_ollama_service),
        ("stale log symlink cleanup", _cleanup_stale_log_symlinks),
        ("env sync", sync_env_from_config),
        ("compose config (derive from native)", _generate_compose_config),
    ]
    if not getattr(args, "skip_observability", False):
        # Must run before the observability stack starts: dockerd creates a
        # missing bind-mount source root-owned, which leaves
        # Prometheus/Grafana/Loki's non-root uids unable to write their own
        # data dirs (#3632) -- the same failure mode ~/.nyxGPT/secrets hit in
        # #3432, handled by the glitchtip secrets dir step below.
        steps.append(("observability volume dirs", _ensure_observability_volume_dirs))
        steps.append(("glitchtip secrets dir", _ensure_glitchtip_secrets_dir))
        steps.append(("slack webhook secret", _sync_grafana_slack_webhook_secret))
        steps.append(("observability stack", _reconcile_grafana_provisioning))
        steps.append(("glitchtip auto-provisioning", _provision_glitchtip))

    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("install", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: install %s (%d/%d steps ok)",
        "succeeded" if ok else "failed",
        sum(1 for r in results if r.ok),
        len(results),
        extra={"component": "ops", "action": "install", "ok": ok, "steps": len(results)},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("install", "all", result, message)

    return 0 if ok else 2


def _wait_for_stack_healthy(timeout: float = 180.0, poll_interval: float = 3.0) -> bool:
    """Poll every desired component's health until all report healthy, or `timeout` elapses.

    Reuses `self_heal.list_component_status()` -- the same cross-mode
    (native/Compose/Terraform/Kubernetes) probe set `nyxgpt self-heal status`
    and the automatic heal loop already rely on -- so `up`'s health-wait can't
    drift from what the rest of the system considers "healthy". A component
    with `desired=False` (an operator-disabled observability profile, or one
    marked intentionally stopped) is excluded, same as `heal_now`'s automatic
    pass.
    """
    deadline = time.monotonic() + timeout
    while True:
        pending = [
            s.service for s in self_heal.list_component_status() if s.desired and not s.healthy
        ]
        if not pending:
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(poll_interval)


def up(args) -> int:
    """CLI entrypoint for `nyxgpt up` -- a thin alias for `nyxgpt ops install`.

    Runs the exact same reconciliation `install()` does -- mode flags
    (`--terraform`, `--kubernetes`, `--local`, `--skip-observability`, etc.)
    pass straight through, no forked behavior -- then waits for every desired
    component to report healthy via `_wait_for_stack_healthy` and prints the
    web UI URL once it's reachable. Idempotent, same as `install()` itself:
    re-running it just reconciles and re-waits.

    Pass `--no-wait` to return as soon as `install()` finishes, without
    waiting for component health; `--timeout` controls how long to wait
    before giving up (default 180s).

    Returns whatever `install()` returned if it failed or `--no-wait` was
    passed; 2 if the health-wait times out; 0 once every desired component is
    healthy.
    """
    rc = install(args)
    if rc != 0 or getattr(args, "no_wait", False):
        return rc

    print("\nWaiting for components to report healthy...")
    if not _wait_for_stack_healthy(timeout=getattr(args, "timeout", 180.0)):
        print(
            "WARNING: not every component reported healthy within the timeout -- "
            "run `nyxgpt ops status` or `nyxgpt self-heal status` for details.",
            file=sys.stderr,
        )
        return 2

    if getattr(args, "kubernetes", False):
        print(
            "nyxGPT is up. Kubernetes Services are ClusterIP-only -- run "
            "`nyxgpt ops port-forward` in another terminal, then open "
            f"{WEB_URL} (see docs/kubernetes.md#4-verify)."
        )
    else:
        print(f"nyxGPT is up: {WEB_URL}")
    return 0


def status(_args) -> int:
    """CLI entrypoint for `nyxgpt ops status`.

    Prints the detected deployment mode (native vs. Compose per component),
    a native/Compose port-conflict warning if both are live, Homebrew
    service states, the Cassandra log-follower LaunchAgent's load state,
    whether the ops-managed Cassandra Docker container is running, and (in
    Kubernetes mode, when pods are present) each canary-capable component's
    stable/canary rollout state via `_serving_status` (see #3419).

    Always returns 0.
    """
    logger.info("ops: status starting", extra={"component": "ops", "action": "status"})
    print("nyxGPT ops status")

    mode = detect_deployment_mode()

    print("\nDeployment mode:")
    for component in ("api", "web", "ollama"):
        print(f"  native  {component}: {mode.native.get(component, 'none')}")
    # Cassandra is the one Docker-managed piece of a local-first install --
    # labeling it "native" here misstated the topology.
    print(f"  docker  cassandra: {mode.native.get('cassandra', 'absent')}")
    if mode.compose:
        for component, state in sorted(mode.compose.items()):
            print(f"  compose {component}: {state}")
    else:
        print("  compose: not detected (no Docker Compose stack running)")
    running_terraform = {c: s for c, s in mode.terraform.items() if s != "absent"}
    if running_terraform:
        for component, state in sorted(running_terraform.items()):
            print(f"  terraform {component}: {state}")

    if mode.conflicts:
        stop_examples = ", ".join(f"nyxgpt ops stop {c}" for c in sorted(mode.conflicts))
        print(
            "\nWARNING: "
            + ", ".join(sorted(mode.conflicts))
            + " reported running in BOTH native and Docker Compose. Only one is actually "
            "serving traffic on the shared port -- the other is a phantom backend. Config "
            f"edits to {NATIVE_CONFIG_HINT} only reach the native process; if Compose is the "
            f"one answering, edit {COMPOSE_CONFIG_HINT} instead. Run `{stop_examples}` to stop "
            "both and pick one, or `nyxgpt ops down --app-only` to drop the Compose app tier "
            "entirely."
        )
    else:
        config_hint = NATIVE_CONFIG_HINT
        if mode.compose:
            config_hint += f" (native components) / {COMPOSE_CONFIG_HINT} (Compose components)"
        print(f"\nConfig in use: {config_hint}")

    if mode.terraform_conflicts:
        print(
            "\nWARNING: "
            + ", ".join(sorted(mode.terraform_conflicts))
            + " reported running under BOTH native/Compose and Terraform -- an incomplete "
            "mode switch (e.g. `nyxgpt ops down` without `--terraform` before `nyxgpt ops "
            "install`) left two whole core stacks up at once, each answering on its own "
            "network. Run `nyxgpt ops down --terraform` to tear down the Terraform stack, "
            "then `nyxgpt ops install` to reconcile the native/Compose one -- or the reverse "
            "if Terraform is the mode you want to keep."
        )

    if _is_linux():
        if _which("systemctl"):
            cp = _run(
                [
                    "systemctl",
                    "--user",
                    "list-units",
                    "--all",
                    "--type=service",
                    "--no-legend",
                    "nyxgpt-*.service",
                ],
                check=False,
                expected=True,
            )
            print("\nsystemd --user services:\n" + (cp.stdout or "").strip())
        else:
            print("\nsystemd --user services: systemctl not found")

        unit = "nyxgpt-cassandra-logs.service"
        try:
            cp = _run(["systemctl", "--user", "is-active", unit], check=False, expected=True)
            state = (cp.stdout or "").strip() or "inactive"
            print(f"\nsystemd unit {unit}: {state.upper()}")
        except Exception as e:
            print(f"\nsystemd unit {unit}: ERROR ({e})")
    else:
        if _which("brew"):
            cp = _run(["brew", "services", "list"], check=False, expected=True)
            print("\nHomebrew services:\n" + (cp.stdout or "").strip())
        else:
            print("\nHomebrew services: brew not found")

        label = "com.nyxgpt.cassandra-logs"
        try:
            cp = _run(["launchctl", "list"], check=False, expected=True)
            loaded = label in (cp.stdout or "")
            print(f"\nLaunchAgent {label}: {'LOADED' if loaded else 'NOT LOADED'}")
        except Exception as e:
            print(f"\nLaunchAgent {label}: ERROR ({e})")

    if _which("docker") is None:
        print("\nDocker: docker not found")

    tf_state = terraform_stack_state()
    if any(state != "absent" for state in tf_state.values()):
        print("\nTerraform-managed stack (nyxgpt ops down --terraform to tear down):")
        for component, state in sorted(tf_state.items()):
            print(f"  terraform {component}: {state}")

    if _which("kubectl") is not None:
        cp = _run(
            ["kubectl", "-n", K8S_NAMESPACE, "get", "pods", "--no-headers"],
            check=False,
            expected=True,
        )
        pod_lines = [line for line in (cp.stdout or "").splitlines() if line.strip()]
        if cp.returncode == 0 and pod_lines:
            context = _kubectl_context()
            cluster_note = (
                " (kind cluster nyxgpt provisioned -- torn down together on "
                "nyxgpt ops down --kubernetes)"
                if context == KIND_CONTEXT
                else f" (bring-your-own cluster, context: {context})"
            )
            print(
                f"\nKubernetes ({K8S_NAMESPACE} namespace, nyxgpt ops down --kubernetes to "
                f"tear down): {len(pod_lines)} pod(s){cluster_note}"
            )
            for line in pod_lines:
                print(f"  {line}")

            serving = _serving_status("kubernetes")
            if serving["supported"]:
                print("\nCanary (per component -- see the Canary page in the web admin):")
                for component, c in serving["components"].items():
                    rollout = f"active -- {c['weight_percent']}%" if c["active"] else "idle"
                    print(
                        f"  {component}: rollout {rollout} | "
                        f"stable={c['stable']['state']} ({c['stable']['version'] or 'n/a'}) | "
                        f"canary={c['canary']['state']} ({c['canary']['version'] or 'n/a'})"
                    )

    print(
        "\nCleanup: `nyxgpt ops stop <target>` stops one component (native and/or Compose), "
        "`nyxgpt ops down` tears down the whole stack."
    )

    logger.info(
        "ops: status complete (native=%s, compose=%s, conflicts=%s)",
        mode.native,
        mode.compose,
        mode.conflicts,
        extra={
            "component": "ops",
            "action": "status",
            "native": mode.native,
            "compose": mode.compose,
            "conflicts": mode.conflicts,
        },
    )

    return 0


def _promtail_container_id() -> str | None:
    """Return the running promtail container's ID, or None if it isn't up."""
    cp = _run(
        ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "ps", "-q", "promtail"],
        check=False,
        expected=True,
    )
    container_id = (cp.stdout or "").strip().splitlines()[0] if cp.stdout else ""
    return container_id or None


def _promtail_native_mount_missing(container_id: str) -> bool:
    """Return True if the running promtail container has no native-logs bind mount.

    Inspects the actual container's mounts via `docker inspect` rather than
    grepping docker-compose.yml's text for the mount marker -- a promtail
    container created before a compose-file edit (or otherwise missing the
    bind for any reason) has a stale mount list that still passes a text-only
    check, even though the running container can't see native-mode logs.
    """
    cp = _run(
        ["docker", "inspect", "--format", "{{json .Mounts}}", container_id],
        check=False,
        expected=True,
    )
    if cp.returncode != 0:
        return True
    try:
        mounts = json.loads(cp.stdout or "[]")
    except Exception as e:
        logger.warning(
            "Failed to parse `docker inspect` mounts for %s, assuming misconfigured: %s",
            container_id,
            e,
            extra={"component": "ops"},
        )
        return True
    return not any(m.get("Destination") == PROMTAIL_NATIVE_LOG_MOUNT_MARKER for m in mounts)


def _log_aggregation_wiring_issue(cfg_path: Path | None = None) -> str | None:
    """Detect the #3277 failure mode: native-mode logs never reaching Loki.

    promtail always runs as a Compose container regardless of whether the
    core app is deployed native or Compose (see `OBSERVABILITY_PROFILES`).
    In native mode, api/self-heal/ops write logs to the host `~/.nyxGPT/logs`
    directly -- a plain directory, not the `nyxgpt_data` Docker-managed
    volume promtail otherwise mounts for Compose-mode logs. If the running
    promtail container ever loses its host bind mount for that directory,
    native logs silently stop reaching Loki -- Grafana just shows nothing
    rather than erroring, so this needs an explicit check rather than
    relying on someone noticing an empty dashboard.

    Only reports an issue when there's something to actually verify: log
    aggregation is enabled, promtail is confirmed running, and native-mode
    log files actually exist to be missed. Returns None otherwise (nothing
    to check yet, or the wiring is intact).
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return None

    parser = ConfigParser()
    try:
        parser.read(cfg_path)
    except Exception as e:
        logger.warning(
            "Failed to parse %s, skipping promtail wiring check: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return None
    if not get_log_aggregation_enabled(parser):
        return None

    if _compose_stack_snapshot().get("promtail") != "running":
        return None

    native_log_dir = Path.home() / ".nyxGPT" / "logs"
    if not native_log_dir.exists() or not any(native_log_dir.glob("*.log*")):
        return None

    container_id = _promtail_container_id()
    if container_id is None or not _promtail_native_mount_missing(container_id):
        return None

    return (
        f"Log aggregation is enabled and native-mode logs exist under {native_log_dir}, "
        "but the running promtail container has no bind mount for them -- "
        "native logs are not reaching Loki. See docs/docker-compose.md#log-aggregation."
    )


def _tracing_wiring_issue(cfg_path: Path | None = None) -> str | None:
    """Detect the #3350 failure mode: native-mode spans never reaching the collector.

    The api's OTLPSpanExporter is a fire-and-forget HTTP client: when nothing
    listens on `[tracing] otlp_endpoint`, it silently drops every span after
    retrying, rather than failing the request or raising anywhere visible.
    That leaves the Distributed Tracing panel reporting "active" (it only
    checks that `init_tracing` ran, not that the collector is reachable)
    while Jaeger's store stays permanently empty. This does a real TCP
    connect (via `tracing.otlp_endpoint_reachable`) to the endpoint's
    host/port so `doctor` catches the gap, e.g. the otel-collector Compose
    service missing its host `ports:` mapping in native mode.

    Only reports an issue when tracing is actually enabled. Returns None
    otherwise (nothing to check yet, or the collector is reachable).
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return None

    parser = ConfigParser()
    try:
        parser.read(cfg_path)
    except Exception as e:
        logger.warning(
            "Failed to parse %s, skipping tracing wiring check: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return None
    if not get_tracing_enabled(parser):
        return None

    tracing_config = get_tracing_config(parser)
    endpoint = tracing_config["otlp_endpoint"]
    if tracing.otlp_endpoint_reachable(endpoint):
        return None

    return (
        f"Tracing is enabled ([tracing] otlp_endpoint={endpoint}) but nothing is "
        "listening there -- spans are being silently dropped and Jaeger will stay "
        "empty. Confirm the otel-collector Compose service (tracing profile) is "
        "running and publishes that port to the host (nyxgpt ops observability). "
        "See docs/docker-compose.md#distributed-tracing."
    )


def _prometheus_api_scrape_issue(cfg_path: Path | None = None) -> str | None:
    """Detect the #3721 failure mode: prometheus can't reach the native API.

    Twin of `_tracing_wiring_issue` for the metrics half of the stack. A failed
    scrape is just as silent: prometheus itself stays healthy and green, the
    Monitoring panel reports "enabled" (it only checks the flag), and every
    Grafana dashboard renders with no data at all. The classic cause is a plain
    Linux docker engine, where `host.docker.internal` resolves to the bridge
    gateway and a loopback-bound native uvicorn isn't listening there -- which
    is what `host-api-relay` exists to bridge.

    Asks prometheus for its own view of the `nyxgpt-api` target rather than
    re-deriving reachability, so it reports the same `lastError` an operator
    would see on prometheus's /targets page. Only runs when monitoring is
    enabled and prometheus is actually up; any transport/parse failure returns
    None (prometheus not reachable is the existing "stack is down" story, not
    this check's finding).
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return None

    parser = ConfigParser()
    try:
        parser.read(cfg_path)
    except Exception as e:
        logger.warning(
            "Failed to parse %s, skipping prometheus scrape check: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return None

    monitoring_config = get_monitoring_config(parser)
    if not monitoring_config["enabled"]:
        return None

    base_url = str(monitoring_config["prometheus_ui_url"]).rstrip("/")
    try:
        resp = httpx.get(f"{base_url}/api/v1/targets", params={"state": "active"}, timeout=5.0)
        resp.raise_for_status()
        active = resp.json()["data"]["activeTargets"]
    except Exception as e:
        logger.debug(
            "Prometheus targets unavailable at %s, skipping scrape check: %s",
            base_url,
            e,
            extra={"component": "ops"},
        )
        return None

    api_targets = [t for t in active if t.get("labels", {}).get("job") == "nyxgpt-api"]
    if not api_targets or any(t.get("health") == "up" for t in api_targets):
        return None

    last_error = next(
        (t.get("lastError") for t in api_targets if t.get("lastError")),
        "no error reported",
    )
    hint = ""
    if _is_linux():
        hint = (
            " On Linux this is usually the container->host-loopback gap (#3721): re-run "
            "`nyxgpt ops observability` to (re)enable the host-api-relay service, and check "
            "`nyxgpt ops logs host-api-relay`."
        )
    return (
        "Prometheus cannot scrape the API's /metrics endpoint "
        f"(job nyxgpt-api is down: {last_error}) -- every Grafana dashboard will render "
        f"empty even though the stack looks healthy.{hint} "
        "See docs/troubleshooting.md#grafana-dashboards-are-empty-on-linux."
    )


def _tracing_packages_doctor_issue(cfg_path: Path | None = None) -> str | None:
    """Detect the #3484 failure mode: a venv predating the #3430 OTel backbone
    (or missing a package `pip uninstall`'d since) is missing an
    `opentelemetry-instrumentation-*`/exporter package.

    `nyxgpt.tracing` no longer crashes on import when a package is missing
    (that's the #3484 fix), but if tracing is enabled in config the operator
    is silently running degraded -- missing instrumentors are skipped, or
    tracing is disabled outright if the exporter itself is missing -- until
    they reinstall. Only reports an issue when tracing is actually enabled,
    same gating as `_tracing_wiring_issue`.
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return None

    parser = ConfigParser()
    try:
        parser.read(cfg_path)
    except Exception as e:
        logger.warning(
            "Failed to parse %s, skipping tracing packages check: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return None
    if not get_tracing_enabled(parser):
        return None

    missing = tracing.missing_tracing_packages()
    if not missing:
        return None

    return (
        "Tracing is enabled but these OTel packages are missing from this venv: "
        f"{', '.join(missing)}. Tracing is running degraded (missing instrumentors "
        "are skipped, or tracing is disabled if the exporter itself is missing) "
        "until you run: nyxgpt ops install."
    )


def _ollama_env_drift_issue() -> str | None:
    """Detect the #3431 boot-race failure mode: native Ollama's OLLAMA_MODELS
    env drifting back to Ollama's default `~/.ollama/models` store.

    `launchctl setenv` only applies to the launchd GUI session it's run in,
    and the `com.nyxgpt.ollama-env` LaunchAgent that reapplies it is a
    *separate* RunAtLoad agent from Homebrew's own `ollama` one -- launchd
    doesn't guarantee their relative ordering. If Homebrew's agent wins that
    race on a given login, `ollama serve` starts before OLLAMA_MODELS is set
    and silently falls back to the default store for the rest of the
    session, reproducing the split-library bug this issue exists to fix.
    `set-ollama-models-env.sh` now force-restarts the brew service every
    login to close that race, but this check surfaces drift here too in case
    something else (a manual `launchctl unsetenv`, a non-nyxgpt Ollama
    install) undoes it between doctor runs.

    Only reports an issue once the shared store has actually been configured
    (`nyxgpt ops install` has run at least once) and there's a `launchctl` to
    check (macOS). Returns None otherwise.
    """
    if _which("launchctl") is None:
        return None
    marker = _ollama_migration_state_path("ollama-native-env.configured")
    if not marker.exists():
        return None

    expected = _shared_ollama_models_dir()
    cp = _run(["launchctl", "getenv", "OLLAMA_MODELS"], check=False, expected=True)
    actual = (cp.stdout or "").strip()
    if cp.returncode != 0 or not actual:
        return (
            f"Native Ollama's OLLAMA_MODELS env is not set for this login session "
            f"(expected {expected}) -- models pulled/read natively may split from the "
            "shared store again (run: nyxgpt ops install)"
        )
    if Path(actual) != expected:
        return (
            f"Native Ollama's OLLAMA_MODELS is set to {actual}, not the shared store "
            f"{expected} -- models pulled/read natively may split from the shared store "
            "again (run: nyxgpt ops install)"
        )
    return None


def _linux_ollama_port_conflict_issue() -> str | None:
    """Detect the #3632 port-11434 conflict: a system-wide `ollama.service`
    contending with the `nyxgpt-ollama.service` nyxgpt owns.

    Fires whenever the distro's system unit is active or enabled on Linux --
    it either already holds the port (so `nyxgpt-ollama.service` crash-loops)
    or will grab it back at the next boot. `nyxgpt ops install` reconciles
    this itself now (`_takeover_system_ollama_service` stops and disables the
    system unit), so re-running install is the first remediation offered,
    with the explicit `sudo` command for a host where install couldn't get
    root without a prompt. Linux only; returns None on macOS/other or when
    nothing conflicts.
    """
    if not _is_linux():
        return None
    if not _system_ollama_service_conflicts():
        return None
    return (
        "System-wide ollama.service is active/enabled and contends for port 11434 with "
        "nyxgpt-ollama.service, which nyxgpt manages (run: nyxgpt ops install, or if it "
        "reported it could not get root: sudo systemctl disable --now ollama.service && "
        "nyxgpt ops install)"
    )


# Curated per-component loggers surfaced in the Log Aggregation panel and
# the "Operational Logs" Grafana dashboard (see app._loki_curated_queries).
# `_loki_recent_volume_by_logger` reports each one's recent line count so
# `doctor` output can distinguish "pipeline healthy, component just idle"
# (e.g. deploy/canary legitimately silent on a native install that's never
# run a k8s operation) from "no logs reaching Loki at all" (every logger at
# zero, including ones that just definitely logged something) -- see #3349.
LOKI_CURATED_LOGGERS: dict[str, str] = {
    "self_heal": "nyxgpt.self_heal",
    "deploy": "nyxgpt.deploy",
    "canary": "nyxgpt.canary",
    "chat": "nyxgpt.chat",
    "rag": "nyxgpt.rag.rag",
}


def _grafana_doctor_token_path() -> Path:
    """Where the Grafana service-account token for doctor's Loki log-volume
    check is written -- see `_provision_grafana_doctor_token`.

    A dedicated Viewer-scoped service account, not the shared `admin`
    credential the rest of this module's Grafana calls use: that password
    lives in config.ini and can drift from whatever a long-running Grafana
    container's own database actually has (a regenerated config.ini, a
    hand-edited `.env`, ...), which is what let the datasource-proxy query
    below 401 on an otherwise-healthy stack (#3438). A token minted once and
    read straight off disk sidesteps that drift entirely -- same pattern as
    `_glitchtip_grafana_token_path`'s token file, just consumed by this
    process instead of by Grafana itself.
    """
    return Path.home() / ".nyxGPT" / "secrets" / "grafana-doctor-token"


def _loki_recent_volume_by_logger(
    grafana_ui_url: str, *, hours: int = 24
) -> tuple[dict[str, int] | None, str | None]:
    """Query Loki (via Grafana's provisioned datasource proxy, authenticated
    with the service-account token `_provision_grafana_doctor_token` mints)
    for each curated logger's line count over the last `hours`.

    Returns `(volumes, issue)`. `volumes` is None when nothing could be
    queried. `issue` is set to an actionable `doctor` finding only for the
    fixable auth failure modes (token file missing, or Grafana rejects the
    token) -- #3438 was specifically about that case degrading into a
    debug-level log line no operator would see. Any other failure (Grafana
    or Loki simply unreachable) still returns `issue=None`: that's not
    itself a failure here, since the rest of `doctor` already covers overall
    stack reachability.
    """
    token_path = _grafana_doctor_token_path()
    token = token_path.read_text().strip() if token_path.exists() else ""
    if not token:
        return None, (
            f"Missing Grafana service-account token at {token_path} -- the Loki "
            "log-volume check can't authenticate (run: nyxgpt ops install)"
        )

    volumes: dict[str, int] = {}
    try:
        with httpx.Client(
            base_url=grafana_ui_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=5.0,
        ) as client:
            for name, logger_name in LOKI_CURATED_LOGGERS.items():
                query = f'sum(count_over_time({{job="nyxgpt", logger="{logger_name}"}}[{hours}h]))'
                resp = client.get(
                    "/api/datasources/proxy/uid/loki/loki/api/v1/query",
                    params={"query": query},
                )
                if resp.status_code == 401:
                    return None, (
                        f"Grafana rejected the doctor service-account token at {token_path} "
                        "(401) -- delete the file and re-run `nyxgpt ops install` to mint a "
                        "fresh one"
                    )
                if resp.status_code >= 400:
                    raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
                result = resp.json().get("data", {}).get("result", [])
                volumes[name] = int(float(result[0]["value"][1])) if result else 0
    except Exception as e:
        logger.warning(
            "Failed to query Loki log volumes via %s, skipping: %s",
            grafana_ui_url,
            e,
            extra={"component": "ops"},
        )
        return None, None
    return volumes, None


def doctor(_args) -> int:
    """CLI entrypoint for `nyxgpt ops doctor`.

    Checks for common misconfigurations: missing ~/.nyxGPT/config.ini,
    non-executable helper scripts, missing native-service-manager/docker/
    node/npm tools on PATH (brew on macOS, systemctl on Linux),
    missing/incomplete web dependencies (node_modules, undici),
    (when log aggregation is enabled and native logs exist) whether
    promtail is actually wired to see native-mode host logs, (when tracing
    is enabled) whether the configured OTLP endpoint actually has something
    listening on it, (when monitoring is enabled and Prometheus is up)
    whether Prometheus's `nyxgpt-api` scrape target is actually up -- a
    failed scrape leaves every Grafana dashboard empty while the stack
    still looks healthy (#3721), (once the shared Ollama store has been configured)
    whether native Ollama's OLLAMA_MODELS env has drifted from it (#3431),
    and whether `~/.nyxGPT/secrets` is writable / holds the GlitchTip
    Grafana token when the observability stack is up (#3432), whether a
    configured error-tracking DSN's public key still matches a live
    GlitchTip project key -- a stale/re-minted key silently drops every
    event with no other visible symptom (#3565) -- and whether the
    installed environment actually has every dependency declared in
    `pyproject.toml` -- catches a venv that wasn't refreshed after a `git
    pull` added or bumped one (#3487).
    Also prints a per-logger recent log volume
    (last 24h, via Loki) when log aggregation
    and the monitoring stack are both up, so idle curated components aren't
    mistaken for a broken pipeline -- and, if that check's Grafana
    service-account token is missing or rejected, reports it as an issue
    rather than silently omitting the log volume line (#3438). Prints each
    issue found.

    Returns 0 if no issues were found, else 2.
    """
    logger.info("ops: doctor starting", extra={"component": "ops", "action": "doctor"})
    issues: list[str] = []

    cfg = Path.home() / ".nyxGPT" / "config.ini"
    if not cfg.exists():
        issues.append(f"Missing config {cfg}")

    volume_info: str | None = None
    cfg_parser: ConfigParser | None = None
    if cfg.exists():
        try:
            parsed = ConfigParser()
            parsed.read(cfg)
            cfg_parser = parsed
        except Exception as e:
            logger.warning(
                "Failed to parse %s, skipping config-dependent doctor checks: %s",
                cfg,
                e,
                extra={"component": "ops"},
            )
            cfg_parser = None
    if (
        cfg_parser is not None
        and get_log_aggregation_enabled(cfg_parser)
        and _compose_stack_snapshot().get("promtail") == "running"
    ):
        monitoring_config = get_monitoring_config(cfg_parser)
        volumes, loki_issue = _loki_recent_volume_by_logger(monitoring_config["grafana_ui_url"])
        if volumes is not None:
            volume_info = ", ".join(f"{k}={v}" for k, v in volumes.items())
        if loki_issue is not None:
            issues.append(loki_issue)

    for name in (
        "run-web.sh",
        "follow-cassandra-logs.sh",
        "follow-ollama-logs.sh",
        "set-ollama-models-env.sh",
    ):
        p = Path.home() / ".nyxGPT" / "scripts" / name
        if p.exists() and not os.access(p, os.X_OK):
            issues.append(f"Script not executable {p}")

    if _is_linux():
        required_native_tools: tuple[str, ...] = ("systemctl", "docker")
    elif _is_macos():
        required_native_tools = ("brew", "docker")
    else:
        required_native_tools = ("docker",)
    for tool in required_native_tools:
        if _which(tool) is None:
            issues.append(f"Missing tool in PATH: {tool}")

    if (
        _which("docker") is not None
        and _docker_container_state(CASSANDRA_CONTAINER_NAME) == "absent"
    ):
        issues.append(
            f"Missing local Cassandra container: {CASSANDRA_CONTAINER_NAME} "
            "(run: nyxgpt ops install)"
        )

    if _which("docker") is not None:
        restarting = sorted(
            service for service, state in _compose_stack_snapshot().items() if state == "restarting"
        )
        if restarting:
            issues.append(
                "Compose service(s) stuck in a restart/crash loop: "
                f"{', '.join(restarting)} (run: nyxgpt ops logs <service> to see why it's "
                "failing to start)"
            )

    web_dir = REPO_ROOT / "web"
    if web_dir.exists():

        def _can_resolve(pkg: str) -> bool:
            try:
                cp = subprocess.run(
                    ["node", "-p", f"require.resolve('{pkg}')"],
                    cwd=str(web_dir),
                    text=True,
                    capture_output=True,
                )
                return cp.returncode == 0
            except Exception as e:
                logger.warning(
                    "Failed to resolve node package %r, assuming missing: %s",
                    pkg,
                    e,
                    extra={"component": "ops"},
                )
                return False

        if _which("node") is None:
            issues.append("Missing tool in PATH: node")
        if _which("npm") is None:
            issues.append("Missing tool in PATH: npm")
        if not (web_dir / "node_modules").exists():
            issues.append(f"Missing web deps: {web_dir / 'node_modules'} (run: nyxgpt ops install)")
        elif not _can_resolve("undici"):
            issues.append("Missing web dependency: undici (run: nyxgpt ops install)")

    log_issue = _log_aggregation_wiring_issue()
    if log_issue:
        issues.append(log_issue)

    tracing_issue = _tracing_wiring_issue()
    if tracing_issue:
        issues.append(tracing_issue)

    tracing_packages_issue = _tracing_packages_doctor_issue()
    if tracing_packages_issue:
        issues.append(tracing_packages_issue)

    scrape_issue = _prometheus_api_scrape_issue()
    if scrape_issue:
        issues.append(scrape_issue)

    if _is_macos():
        # Linux has no equivalent drift to check: nyxgpt-ollama.service's
        # Environment=OLLAMA_MODELS is part of the unit file itself (applied
        # fresh on every start), unlike launchd's per-session `launchctl
        # setenv` -- see _install_ollama_env_agent.
        ollama_env_issue = _ollama_env_drift_issue()
        if ollama_env_issue:
            issues.append(ollama_env_issue)

    linux_ollama_conflict_issue = _linux_ollama_port_conflict_issue()
    if linux_ollama_conflict_issue:
        issues.append(linux_ollama_conflict_issue)

    docker_access_issue = _docker_access_doctor_issue()
    if docker_access_issue:
        issues.append(docker_access_issue)

    issues += _observability_volume_doctor_issues()
    issues += _glitchtip_secrets_doctor_issues()
    error_tracking_drift_issue = _error_tracking_dsn_drift_issue()
    if error_tracking_drift_issue:
        issues.append(error_tracking_drift_issue)
    issues += _stale_venv_doctor_issues()

    if (
        TERRAFORM_DIR.joinpath("terraform.tfstate").exists()
        and _terraform_state_has_resources()
        and all(state == "absent" for state in terraform_stack_state().values())
    ):
        issues.append(
            "Terraform state exists but no nyxgpt-tf-* containers are running "
            "(run: nyxgpt ops install --terraform --local, or nyxgpt ops down --terraform "
            "to clean up the stale state)"
        )

    try:
        dual_stack_conflicts = detect_deployment_mode().terraform_conflicts
    except Exception as e:  # never let dual-stack detection block the rest of doctor
        logger.warning(
            "ops: dual-stack detection failed, skipping: %s: %s",
            type(e).__name__,
            e,
            extra={"component": "ops", "action": "doctor"},
        )
        dual_stack_conflicts = []
    if dual_stack_conflicts:
        issues.append(
            ", ".join(sorted(dual_stack_conflicts))
            + " reported running under BOTH native/Compose and Terraform at once -- an "
            "incomplete mode switch left two core stacks up (run: nyxgpt ops down "
            "--terraform, or nyxgpt ops down, to drop the mode you don't want)"
        )

    if issues:
        print("nyxGPT ops doctor: FAIL")
        for i in issues:
            print(f"- {i}")
        if volume_info is not None:
            print(f"Log volume (last 24h) by logger: {volume_info}")
        logger.warning(
            "ops: doctor found %d issue(s): %s",
            len(issues),
            "; ".join(issues),
            extra={"component": "ops", "action": "doctor", "ok": False, "issues": issues},
        )
        return 2

    print("nyxGPT ops doctor: OK")
    if volume_info is not None:
        print(f"Log volume (last 24h) by logger: {volume_info}")
    logger.info(
        "ops: doctor found no issues",
        extra={"component": "ops", "action": "doctor", "ok": True, "issues": []},
    )
    return 0


def _clear_intentional_stops(components: list[str]) -> list[OpsResult]:
    """Clear the intentional-stop marker for `components` (they're being brought back up).

    Called from `install`/`restart` for whatever they bring up -- doing so is
    itself the "this is desired again" signal, so self-heal resumes guarding
    the component against future crashes (see self_heal.py's intentional-stop
    registry and its module docstring, #3406). A component never marked
    stopped is a no-op, so this is safe to call unconditionally.
    """
    for component in components:
        self_heal.clear_intentionally_stopped(component)
    return [OpsResult(True, f"Cleared intentional-stop marker(s): {', '.join(components)}")]


# --- Restart public API ---


def _compose_conflict_result(component: str, compose: dict[str, str]) -> OpsResult | None:
    """Return a refusal OpsResult if a Compose deployment of `component` is live."""
    if compose.get(component) != "running":
        return None
    port = COMPOSE_COMPONENT_PORTS.get(component)
    port_note = f" on port {port}" if port else ""
    return OpsResult(
        False,
        f"Refusing to restart local {component}: a Docker Compose deployment of "
        f"{component} is already running{port_note}",
        "Both deployments would try to bind the same port. Stop the Compose deployment "
        "of this component (or manage it there) before restarting the local one.",
    )


def _restart_component(component: str, compose: dict[str, str]) -> list[OpsResult]:
    """Restart a native (Homebrew/systemd) component, refusing first if Compose already runs it.

    Shared by `restart()`'s api/web/ollama steps (#3558) -- factored out of
    the old inline per-component `if` blocks so each component becomes a
    single named step for the live-progress step runner. Restarts via
    `_restart_native_service`, which dispatches to the OS-appropriate
    mechanism (brew on macOS, systemd on Linux).
    """
    conflict = _compose_conflict_result(component, compose)
    if conflict:
        return [conflict]
    self_heal.clear_intentionally_stopped(component)
    return _restart_native_service(component)


def _restart_cassandra_component(compose: dict[str, str]) -> list[OpsResult]:
    """Restart the Cassandra Docker container, refusing first if Compose already runs it.

    Cassandra restarts via `_restart_docker_container` rather than
    `_restart_brew_service` (it has no Homebrew service), so it needs its own
    step function alongside `_restart_component` (#3558).
    """
    conflict = _compose_conflict_result("cassandra", compose)
    if conflict:
        return [conflict]
    self_heal.clear_intentionally_stopped("cassandra")
    return _restart_docker_container("nyxgpt-cassandra")


def restart(args) -> int:
    """Restart operational components.

    target: all|api|web|ollama|cassandra|cassandra-logs|observability

    Before touching a native component, checks whether a Docker Compose deployment
    of that same component is already live and, if so, refuses rather than starting
    a second process/container that would collide on the same port.

    Unlike `stop`/`down` (where `observability` is opt-in via its own target and
    excluded from `all`), `restart all` also restarts every currently running
    observability Compose service (monitoring/logging/tracing/errors profiles) --
    so a single wrapped command can bounce the whole local stack, core services
    plus dashboards, after a config change. Observability services that aren't
    enabled/running are skipped cleanly rather than started.
    """
    target = getattr(args, "target", "all") or "all"
    logger.info(
        "ops: restart starting (target=%s)",
        target,
        extra={"component": "ops", "action": "restart", "target": target},
    )

    compose = _compose_stack_snapshot()

    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = []
    if target in ("all", "api"):
        steps.append(("restart api", lambda: _restart_component("api", compose)))
    if target in ("all", "web"):
        steps.append(("restart web", lambda: _restart_component("web", compose)))
    if target in ("all", "ollama"):
        steps.append(("restart ollama", lambda: _restart_component("ollama", compose)))
    if target in ("all", "cassandra"):
        steps.append(("restart cassandra", lambda: _restart_cassandra_component(compose)))
    if target in ("all", "cassandra-logs"):
        steps.append(
            (
                "restart cassandra-logs agent",
                lambda: _restart_native_log_follower("cassandra-logs"),
            )
        )
    if target in ("all", "observability"):
        steps.append(("restart observability stack", _restart_observability_stack))

    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("restart", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: restart %s (target=%s, %d/%d ok)",
        "succeeded" if ok else "failed",
        target,
        sum(1 for r in results if r.ok),
        len(results),
        extra={"component": "ops", "action": "restart", "target": target, "ok": ok},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("restart", target, result, message)

    return 0 if ok else 2


# --- Stop/down helpers ---


def _stop_brew_service(name: str) -> list[OpsResult]:
    """Stop Homebrew service `name` via `brew services stop`.

    Returns a single-element list: an OpsResult reporting brew missing, the
    stop command's success, or its failure with captured stdout/stderr.
    """
    if _which("brew") is None:
        return [OpsResult(False, f"brew not found; cannot stop {name}")]
    try:
        cp = _run(["brew", "services", "stop", name], check=False)
        if cp.returncode == 0:
            return [OpsResult(True, f"Stopped brew service: {name}")]
        details = _output_excerpt(cp)
        return [OpsResult(False, f"Failed to stop brew service: {name}", details.strip())]
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to stop brew service: {name}",
                f"{type(e).__name__}: {e}",
            )
        ]


def _stop_docker_container(name: str) -> list[OpsResult]:
    """Stop Docker container `name` via `docker stop` (container is preserved, not removed)."""
    if _which("docker") is None:
        return [OpsResult(False, f"docker not found; cannot stop {name}")]
    try:
        cp = _run(["docker", "stop", name], check=False)
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to stop docker container: {name}",
                f"{type(e).__name__}: {e}",
            )
        ]
    if cp.returncode == 0:
        return [OpsResult(True, f"Stopped docker container: {name}")]
    details = _output_excerpt(cp)
    return [OpsResult(False, f"Failed to stop docker container: {name}", details.strip())]


def _stop_launchagent(label: str) -> list[OpsResult]:
    """Unload the LaunchAgent `label` via `launchctl bootout` in the current GUI domain.

    Unlike `_restart_launchagent`'s kickstart, `bootout` actually unloads the
    agent so it stops for good instead of being immediately relaunched by
    launchd. A "not loaded" failure (already stopped) is reported as success.
    """
    domain = f"gui/{os.getuid()}/{label}"
    try:
        cp = _run(["launchctl", "bootout", domain], check=False, expected=True)
        details = _output_excerpt(cp)
        if cp.returncode == 0:
            return [OpsResult(True, f"Stopped LaunchAgent: {label}")]
        if "no such process" in details.lower() or "could not find" in details.lower():
            return [OpsResult(True, f"LaunchAgent already stopped: {label}")]
        return [OpsResult(False, f"Failed to stop LaunchAgent: {label}", details.strip())]
    except Exception as e:
        return [
            OpsResult(
                False,
                f"Failed to stop LaunchAgent: {label}",
                f"{type(e).__name__}: {e}",
            )
        ]


def _compose_stop_service(service: str) -> list[OpsResult]:
    """Stop (but don't remove) a single running Compose service: `docker compose stop`."""
    if _which("docker") is None:
        return [OpsResult(False, f"docker not found; cannot stop compose service: {service}")]
    cp = _run(
        ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "stop", service], check=False
    )
    if cp.returncode == 0:
        return [OpsResult(True, f"Stopped Compose service: {service}")]
    details = _output_excerpt(cp)
    return [OpsResult(False, f"Failed to stop Compose service: {service}", details.strip())]


def _resolve_observability_services() -> tuple[list[str] | None, OpsResult | None]:
    """Resolve the Compose service names for the observability profiles.

    Mirrors `_start_observability_stack`'s own resolution (profiles minus
    `CORE_APP_SERVICES`) so `stop`/`down` agree with `install`/`observability`
    on what "observability" means. Returns `(services, None)` on success or
    `(None, failure_result)` if the services list couldn't be resolved.
    """
    base_cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE)]
    for profile in OBSERVABILITY_PROFILES:
        base_cmd += ["--profile", profile]
    cp = _run(base_cmd + ["config", "--services"], check=False)
    if cp.returncode != 0:
        return None, OpsResult(
            False,
            "Failed to resolve observability services",
            _output_excerpt(cp),
        )
    services = sorted({s.strip() for s in cp.stdout.splitlines() if s.strip()} - CORE_APP_SERVICES)
    return services, None


def _resolve_app_services() -> tuple[list[str] | None, OpsResult | None]:
    """Resolve the Compose service names for the core app tier (`CORE_APP_SERVICES`).

    Returns `(services, None)` on success or `(None, failure_result)` if the
    services list couldn't be resolved.
    """
    cp = _run(
        ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "config", "--services"],
        check=False,
    )
    if cp.returncode != 0:
        return None, OpsResult(
            False,
            "Failed to resolve app services",
            _output_excerpt(cp),
        )
    services = sorted({s.strip() for s in cp.stdout.splitlines() if s.strip()} & CORE_APP_SERVICES)
    return services, None


def _stop_observability_stack() -> list[OpsResult]:
    """Stop (but don't remove) every running observability Compose service."""
    if not _compose_available():
        return [OpsResult(True, "Skipped observability stack (Docker not found)")]

    services, err = _resolve_observability_services()
    if err is not None:
        return [err]
    if not services:
        return [OpsResult(True, "No observability services resolved to stop")]

    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "stop"] + services
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [
            OpsResult(
                False,
                "Failed to stop observability stack",
                _output_excerpt(cp),
            )
        ]
    return [OpsResult(True, "Observability stack stopped (containers and data preserved)")]


def _restart_observability_stack() -> list[OpsResult]:
    """Restart every currently running observability Compose service.

    Resolves the monitoring/logging/tracing/errors profile services --
    the same set `_start_observability_stack`/`_stop_observability_stack` use --
    and restarts only the ones actually running. A profile service that isn't
    enabled/up is reported as skipped rather than started, since `restart`
    should bounce what's live, not change which services are enabled (that's
    `nyxgpt ops observability`'s job).
    """
    if not _compose_available():
        return [OpsResult(True, "Skipped observability stack (Docker not found)")]

    services, err = _resolve_observability_services()
    if err is not None:
        return [err]
    if not services:
        return [OpsResult(True, "No observability services resolved to restart")]

    running = _compose_stack_snapshot()
    to_restart = [s for s in services if running.get(s) == "running"]
    skipped = [s for s in services if s not in to_restart]

    results: list[OpsResult] = [
        OpsResult(True, f"Observability service not running (skipped): {s}") for s in skipped
    ]

    if not to_restart:
        results.append(OpsResult(True, "No running observability services to restart"))
        return results

    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "restart"] + to_restart
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        results.append(
            OpsResult(
                False,
                "Failed to restart observability stack",
                _output_excerpt(cp),
            )
        )
        return results

    results.append(OpsResult(True, f"Restarted observability services: {', '.join(to_restart)}"))
    return results


# Compose service name -> volume_dir() component(s) it bind-mounts (see
# VOLUME_DIR_NAMES). `_compose_down` uses this to actually delete data when
# `--volumes` is passed: `docker compose down --volumes` only removes
# Docker-managed named volumes, and since #3346 these are plain host bind
# mounts, so that flag alone is a silent no-op against the data it used to
# delete. glitchtip/glitchtip-worker share one uploads directory.
SERVICE_VOLUME_DIRS: dict[str, list[str]] = {
    "ollama": ["ollama"],
    "cassandra": ["cassandra"],
    "api": ["nyxgpt-data"],
    "prometheus": ["prometheus"],
    "grafana": ["grafana"],
    "loki": ["loki"],
    "glitchtip-postgres": ["glitchtip-postgres"],
    "glitchtip": ["glitchtip-uploads"],
    "glitchtip-worker": ["glitchtip-uploads"],
}


def _remove_volume_dirs(services: list[str]) -> list[OpsResult]:
    """Delete the host bind-mount directories owned by `services` (see `SERVICE_VOLUME_DIRS`).

    Called only when `docker compose down --volumes` is requested -- that
    flag no longer touches bind-mounted data itself (see `_compose_down`), so
    this is what actually makes `--volumes` destructive again.
    """
    dirs = sorted({d for s in services for d in SERVICE_VOLUME_DIRS.get(s, [])})
    if not dirs:
        return []
    results: list[OpsResult] = []
    for name in dirs:
        path = volume_dir(name)
        try:
            shutil.rmtree(path)
            results.append(OpsResult(True, f"Removed data directory: {path}"))
        except Exception as e:
            results.append(
                OpsResult(
                    False, f"Failed to remove data directory: {path}", f"{type(e).__name__}: {e}"
                )
            )
    return results


def _compose_down(services: list[str], *, volumes: bool) -> list[OpsResult]:
    """Tear down the given Compose `services` via `docker compose down`.

    Removes containers/networks for exactly the listed services; `volumes`
    additionally deletes their ~/.nyxGPT/volumes/ bind-mount directories
    (destructive -- data loss; see `_remove_volume_dirs`).
    """
    if not _compose_available():
        return [OpsResult(True, "Skipped Compose teardown (Docker not found)")]
    if not services:
        return [OpsResult(True, "No Compose services to tear down for this scope")]

    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "down"] + services
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [
            OpsResult(
                False,
                "Failed to tear down Compose services",
                _output_excerpt(cp),
            )
        ]
    suffix = " and their data directories" if volumes else " (data directories preserved)"
    results = [OpsResult(True, f"Removed Compose containers{suffix}: {', '.join(services)}")]
    if volumes:
        results += _remove_volume_dirs(services)
    return results


def _stop_dual_mode(
    component: str,
    native_stop: Callable[[], list[OpsResult]],
    mode: DeploymentMode,
    tf_or_k8s: Container[str],
) -> list[OpsResult]:
    """Stop `component` in whichever mode(s) it's actually running -- native, Compose, or both.

    Factored out of `stop()`'s old inline per-component closure (#3558) so
    each component becomes a single named step for the live-progress step
    runner. Marks the component intentionally stopped first (unless it's
    Terraform/Kubernetes-managed, which this call never touches) so self-heal
    doesn't immediately restart what this stops.
    """
    if component in tf_or_k8s:
        return [
            OpsResult(
                True,
                f"{component}: running under Terraform/Kubernetes, not native/Compose -- "
                "left alone (self-heal still guards it; use --terraform/--kubernetes to "
                "tear it down)",
            )
        ]
    results: list[OpsResult] = []
    try:
        self_heal.mark_intentionally_stopped(component)
    except Exception as e:  # never let self-heal bookkeeping block a stop
        results.append(
            OpsResult(
                True,
                f"Could not mark {component} as intentionally stopped "
                f"({type(e).__name__}: {e})",
            )
        )
    native_running = mode.native.get(component) in ("started", "running")
    compose_running = mode.compose.get(component) == "running"
    if not native_running and not compose_running:
        results.append(OpsResult(True, f"{component}: already stopped"))
        return results
    if native_running and compose_running:
        results.append(
            OpsResult(
                True,
                f"{component}: running in BOTH native and Compose (mixed mode) -- stopping both",
            )
        )
    if native_running:
        results.extend(native_stop())
    if compose_running:
        results.extend(_compose_stop_service(component))
    return results


def stop(args) -> int:
    """Stop operational components.

    target: all|api|web|ollama|cassandra|cassandra-logs|observability

    For components that can run either natively or under Docker Compose
    (api/web/ollama/cassandra), detects which mode is actually running and
    stops the right one -- if both are live (mixed mode), stops both and
    reports it clearly. Does not delete data volumes or remove containers
    (Compose services are stopped, not brought down).

    `observability` has no native equivalent, so -- like `restart` -- it is
    not included in `all`; select it explicitly to stop the Grafana/Loki/
    Jaeger/GlitchTip Compose profiles.
    """
    target = getattr(args, "target", "all") or "all"
    logger.info(
        "ops: stop starting (target=%s)",
        target,
        extra={"component": "ops", "action": "stop", "target": target},
    )

    mode = detect_deployment_mode()
    tf_or_k8s = _terraform_or_kubernetes_managed_components()

    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = []
    if target in ("all", "api"):
        steps.append(
            (
                "stop api",
                lambda: _stop_dual_mode(
                    "api", lambda: _stop_native_service("api"), mode, tf_or_k8s
                ),
            )
        )
    if target in ("all", "web"):
        steps.append(
            (
                "stop web",
                lambda: _stop_dual_mode(
                    "web", lambda: _stop_native_service("web"), mode, tf_or_k8s
                ),
            )
        )
    if target in ("all", "ollama"):
        steps.append(
            (
                "stop ollama",
                lambda: _stop_dual_mode(
                    "ollama", lambda: _stop_native_service("ollama"), mode, tf_or_k8s
                ),
            )
        )
    if target in ("all", "cassandra"):
        steps.append(
            (
                "stop cassandra",
                lambda: _stop_dual_mode(
                    "cassandra",
                    lambda: _stop_docker_container("nyxgpt-cassandra"),
                    mode,
                    tf_or_k8s,
                ),
            )
        )
    if target in ("all", "cassandra-logs"):
        steps.append(
            (
                "stop cassandra-logs agent",
                lambda: _stop_native_log_follower("cassandra-logs"),
            )
        )
    if target == "observability":
        # Not part of "all" -- like `restart`, "all" only covers the core
        # api/web/ollama/cassandra/cassandra-logs components; observability
        # has no native equivalent and is opt-in via its own target/command.
        steps.append(("stop observability stack", _stop_observability_stack))

    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("stop", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: stop %s (target=%s, %d/%d ok)",
        "succeeded" if ok else "failed",
        target,
        sum(1 for r in results if r.ok),
        len(results),
        extra={"component": "ops", "action": "stop", "target": target, "ok": ok},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("stop", target, result, message)

    return 0 if ok else 2


def _down_mark_intentional_stops() -> list[OpsResult]:
    """Mark api/web/ollama/cassandra intentionally stopped before `down` tears them down.

    Extracted from `down()`'s inline prelude (#3558) into its own named step
    for the live-progress step runner -- see `down()`'s own docstring/comment
    for why this has to happen before any component is actually stopped.
    """
    tf_or_k8s = _terraform_or_kubernetes_managed_components()
    results: list[OpsResult] = []
    try:
        marked = [
            component
            for component in ("api", "web", "ollama", "cassandra")
            if component not in tf_or_k8s
        ]
        for component in marked:
            self_heal.mark_intentionally_stopped(component)
        if marked:
            results.append(
                OpsResult(
                    True,
                    f"Marked {', '.join(marked)} as intentionally stopped "
                    "(self-heal will leave them alone until brought back up)",
                )
            )
        skipped = [c for c in ("api", "web", "ollama", "cassandra") if c in tf_or_k8s]
        if skipped:
            results.append(
                OpsResult(
                    True,
                    f"Left {', '.join(skipped)} alone -- running under Terraform/"
                    "Kubernetes, not native/Compose (self-heal still guards them; "
                    "use --terraform/--kubernetes to tear those down)",
                )
            )
    except Exception as e:  # never let self-heal bookkeeping block a teardown
        results.append(
            OpsResult(
                True,
                f"Could not mark components as intentionally stopped ({type(e).__name__}: {e})",
            )
        )
    return results


def _down_compose_teardown(scope: str, volumes: bool) -> list[OpsResult]:
    """Tear down the Compose app/observability tiers for `down`'s `scope`.

    Extracted from `down()`'s inline Compose block (#3558) into its own
    named step for the live-progress step runner. Runs for every scope
    (including `--app-only`/`--observability-only`) since it's the single
    place that resolves and tears down whichever Compose services the scope
    selects.
    """
    if not _compose_available():
        return [OpsResult(True, "Skipped Compose teardown (Docker not found)")]

    compose_services: list[str] = []
    results: list[OpsResult] = []
    if scope in ("all", "app"):
        app_services, err = _resolve_app_services()
        if err is not None:
            results.append(err)
        elif app_services:
            compose_services += app_services

    if scope in ("all", "observability"):
        obs_services, err = _resolve_observability_services()
        if err is not None:
            results.append(err)
        elif obs_services:
            compose_services += obs_services

    if compose_services:
        results.extend(_compose_down(compose_services, volumes=volumes))
    else:
        results.append(OpsResult(True, "No Compose services running for this scope"))
    return results


def down(args) -> int:
    """Tear down the local stack: native services plus the Compose app/observability tiers.

    Native services (api/web/ollama/cassandra/cassandra-logs) are stopped;
    Compose containers for the selected scope are removed via `docker
    compose down` (networks too, volumes preserved unless `--volumes` is
    also given). `--app-only`/`--observability-only` scope the teardown to
    one tier so, e.g., a stale Compose app tier can be dropped while
    observability (or vice versa) stays up.

    `--terraform`/`--kubernetes` tear down those deployments instead
    (`terraform destroy` / removing the `nyxgpt` namespace's resources) --
    mutually exclusive with the native/Compose scope flags above.
    """
    if getattr(args, "terraform", False) and getattr(args, "kubernetes", False):
        print("ERROR: --terraform and --kubernetes are mutually exclusive", file=sys.stderr)
        return 2
    if getattr(args, "terraform", False):
        return _down_terraform(args)
    if getattr(args, "kubernetes", False):
        return _down_kubernetes(args)

    app_only = bool(getattr(args, "app_only", False))
    observability_only = bool(getattr(args, "observability_only", False))
    volumes = bool(getattr(args, "volumes", False))
    yes_really = bool(getattr(args, "yes_really", False))

    if volumes and not yes_really:
        print(
            "ERROR: refusing to remove volumes without --yes-really "
            "(this deletes Cassandra/Postgres/Grafana data)",
            file=sys.stderr,
        )
        return 2

    scope = "observability" if observability_only else ("app" if app_only else "all")
    logger.info(
        "ops: down starting (scope=%s, volumes=%s)",
        scope,
        volumes,
        extra={"component": "ops", "action": "down", "scope": scope, "volumes": volumes},
    )

    # Mark api/web/ollama/cassandra as intentionally stopped BEFORE stopping
    # anything. Otherwise the next heal pass sees them as unhealthy and
    # restarts them (`brew services restart` / `docker restart`), fighting
    # the teardown -- the ports get re-occupied within seconds, which then
    # blocks `nyxgpt ops install --terraform --local` with a spurious port
    # collision. This is per-component (self_heal.py's intentional-stop
    # registry, #3406), not a global watchdog disable: an armed watchdog
    # keeps healing genuine crashes of every other component the whole
    # time. `nyxgpt ops install`/`restart`/`up` of a component clears its
    # marker automatically.
    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = []
    if scope in ("all", "app"):
        steps.append(("mark intentionally stopped", _down_mark_intentional_stops))
        steps.append(("stop api", lambda: _stop_native_service("api")))
        steps.append(("stop web", lambda: _stop_native_service("web")))
        steps.append(("stop ollama", lambda: _stop_native_service("ollama")))
        steps.append(
            ("stop cassandra container", lambda: _stop_docker_container("nyxgpt-cassandra"))
        )
        steps.append(
            (
                "stop cassandra-logs agent",
                lambda: _stop_native_log_follower("cassandra-logs"),
            )
        )
    steps.append(("compose teardown", lambda: _down_compose_teardown(scope, volumes)))

    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("down", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: down %s (scope=%s, volumes=%s, %d/%d ok)",
        "succeeded" if ok else "failed",
        scope,
        volumes,
        sum(1 for r in results if r.ok),
        len(results),
        extra={"component": "ops", "action": "down", "scope": scope, "ok": ok},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("down", scope, result, message)

    return 0 if ok else 2


def logs(args) -> int:
    """Print recent logs for a single component, in whichever mode it's actually running.

    Wraps `docker compose logs`/`docker logs`/`kubectl logs`/the component's
    own log files so operators never need to run a raw `docker`/`docker
    compose`/`kubectl` command (or hunt for a native log path) themselves --
    e.g. to read the `errors` profile's GlitchTip container output for the
    first-account registration confirmation link its console email backend
    prints there, or the native API's own log file. See
    `self_heal.component_logs` for the per-mode dispatch (#3442).
    """
    service = args.service
    tail = getattr(args, "tail", None)
    if tail is None:
        tail = 200

    logger.info(
        "ops: logs requested for %s (tail=%d)",
        service,
        tail,
        extra={"component": "ops", "action": "logs", "service": service, "tail": tail},
    )

    result = self_heal.component_logs(service, tail=tail)
    if not result.ok:
        print(f"[FAIL] {result.message}")
        if result.details:
            print(f"  {result.details}")
        logger.warning(
            "ops: logs failed for %s: %s",
            service,
            result.message,
            extra={
                "component": "ops",
                "action": "logs",
                "service": service,
                "ok": False,
                "result_message": result.message,
                "details": result.details,
            },
        )
        return 2

    print(f"--- {result.message} ---")
    print(result.details or "(no output)")
    # Log the outcome, not the log body itself -- the tailed output can be
    # large and would otherwise duplicate the target service's own logs.
    logger.info(
        "ops: logs %s",
        result.message,
        extra={"component": "ops", "action": "logs", "service": service, "ok": True},
    )
    return 0


# --- Observability stack (Grafana/Prometheus/Loki/Jaeger/GlitchTip) ---

# Docker Compose profiles that make up the SRE observability suite. These
# tools have no native/Homebrew path (see docker/config.docker.ini) -- they
# only ever run as Compose services, regardless of whether the core app
# (api/web/cassandra/ollama) is deployed native or Compose.
OBSERVABILITY_PROFILES: list[str] = ["monitoring", "logging", "tracing", "errors"]

# Core app services in docker-compose.yml that have no `profiles:` key, which
# makes Compose treat them as "default" services started on *every* `up`
# regardless of which `--profile` flags are passed -- `--profile` only adds
# services, it never filters the always-on ones. `_start_observability_stack`
# must explicitly exclude these from the service list it starts, or `nyxgpt
# ops install` would silently bring up a full Dockerized copy of the app
# (building api/web images) alongside a native install.
CORE_APP_SERVICES: frozenset[str] = frozenset({"nyxgpt", "ollama", "cassandra", "api", "web"})

# config.ini sections flipped to `enabled = true` once their matching
# Compose profile is confirmed up, so the SRE/admin dashboard (and, for
# tracing, the API's own span-export init) reflect that the stack is
# actually live instead of still showing "opt-in, not running". Deliberately
# excludes `error_tracking`: GlitchTip is only reachable once its container
# passes its health check (well after `up -d` returns), so it's flipped on
# by `_provision_glitchtip` instead, once a DSN actually exists to report to.
OBSERVABILITY_ENABLE_SECTIONS: list[str] = ["monitoring", "log_aggregation", "tracing"]


def _compose_available() -> bool:
    """Return True if both `docker` and `docker compose` are usable on this host."""
    if _which("docker") is None:
        return False
    cp = _run(["docker", "compose", "version"], check=False, expected=True)
    return cp.returncode == 0


def _enable_observability_config(cfg_path: Path | None = None) -> None:
    """Flip `enabled = true` for `OBSERVABILITY_ENABLE_SECTIONS` in config.ini.

    Only writes the file if a change is actually needed, so re-running
    `nyxgpt ops install`/`nyxgpt ops observability` after the first time is a
    no-op here. Silently does nothing if config.ini doesn't exist yet (run
    `nyxgpt wizard` first) -- this is a follow-on convenience, not something
    that should fail the observability step itself.
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return

    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(cfg_path)

    changed = False
    for section in OBSERVABILITY_ENABLE_SECTIONS:
        if not parser.has_section(section):
            parser.add_section(section)
        if parser.get(section, "enabled", fallback="false").strip().lower() != "true":
            parser.set(section, "enabled", "true")
            changed = True

    if not changed:
        return

    with cfg_path.open("w", encoding="utf-8") as f:
        parser.write(f)
    os.chmod(cfg_path, 0o600)


def _grafana_datasources_dir() -> Path:
    """`~/.nyxGPT/docker/grafana/provisioning/datasources/` (synced from the
    packaged `nyxgpt.resources` tree by `_sync_packaged_resources`) -- one
    YAML file per datasource group (GlitchTip lives in its own file,
    `glitchtip.yml`, separate from `datasource.yml`'s Prometheus/Loki/Jaeger
    -- #3432 -- so a `$__file{}` interpolation failure in one file can't take
    the others down; see `docker/grafana/provisioning/datasources/glitchtip.yml`)."""
    return OPS_DOCKER_DIR / "grafana" / "provisioning" / "datasources"


def _grafana_provisioning_fingerprint() -> str:
    """sha256 over everything that only takes effect when the `grafana`
    container is recreated: every datasource provisioning file (new/changed
    datasources) and the Compose file itself (image tag, `GF_INSTALL_PLUGINS`,
    any other env). `docker compose up -d` alone does NOT pick up an env or
    image change on an already-running container -- it needs
    `--force-recreate`. This fingerprint lets `_start_observability_stack`
    detect that drift deterministically (#3424) instead of leaving dashboards
    silently pointed at a stale container missing a plugin or datasource.
    """
    digest = hashlib.sha256()
    datasources_dir = _grafana_datasources_dir()
    paths = sorted(datasources_dir.glob("*.yml")) if datasources_dir.exists() else []
    for path in (*paths, self_heal.COMPOSE_FILE):
        if path.exists():
            digest.update(path.read_bytes())
    return digest.hexdigest()


def _grafana_provisioning_fingerprint_marker() -> Path:
    """Host-side marker recording the provisioning fingerprint last applied.

    Stored outside Grafana's own bind-mounted data dir (like
    `_migration_marker_path`) so it survives independently of the
    container/volume lifecycle and reflects what THIS tool last reconciled,
    not what the container happens to contain.
    """
    state_dir = Path.home() / ".nyxGPT" / ".migration-state"
    _ensure_dir(state_dir)
    return state_dir / "grafana-provisioning.fingerprint"


def _grafana_provisioning_drifted() -> bool:
    """True if the datasource provisioning file or Compose grafana config
    changed since the last time this tool recreated the container for it."""
    marker = _grafana_provisioning_fingerprint_marker()
    if not marker.exists():
        return True
    try:
        return marker.read_text().strip() != _grafana_provisioning_fingerprint()
    except OSError:
        return True


def _record_grafana_provisioning_fingerprint() -> None:
    """Persist the current provisioning fingerprint as "already applied"."""
    _grafana_provisioning_fingerprint_marker().write_text(_grafana_provisioning_fingerprint())


def _grafana_provisioned_datasource_uids() -> list[str]:
    """Datasource `uid`s declared across every file in
    `docker/grafana/provisioning/datasources/`.

    Deliberately regex-scraped rather than parsed with PyYAML: PyYAML isn't a
    runtime dependency of this package (only a test-suite one), and these
    files are repo-controlled config, not user input, so a targeted regex
    over their known `uid: <value>` shape is sufficient.
    """
    datasources_dir = _grafana_datasources_dir()
    if not datasources_dir.exists():
        return []
    uids: list[str] = []
    for path in sorted(datasources_dir.glob("*.yml")):
        uids += re.findall(r"^\s*uid:\s*(\S+)\s*$", path.read_text(), re.MULTILINE)
    return uids


def _grafana_admin_password_path() -> Path:
    """Where the ops-managed Grafana admin password is stored.

    Thin alias for `config.grafana_admin_password_path` -- kept as a
    module-level name here so existing call sites/tests in this module don't
    need to change, but the actual resolution logic lives in `config.py` so
    `health.py` can share it (#3466) instead of drifting apart (#3458).
    """
    return grafana_admin_password_path()


def _grafana_admin_password(cfg: ConfigParser) -> str:
    """Resolve the Grafana admin password `nyxgpt ops` should reconcile the
    container to.

    Thin alias for `config.resolve_grafana_admin_password` -- see that
    function's docstring for the resolution order.
    """
    return resolve_grafana_admin_password(cfg)


def _grafana_admin_client(grafana_ui_url: str, grafana_admin_password: str) -> httpx.Client:
    """Single source of truth for how ops's install-time checks authenticate
    against Grafana's API -- one place to change the URL/credential wiring
    instead of three separate `auth=("admin", ...)` call sites (#3458)."""
    return httpx.Client(
        base_url=grafana_ui_url,
        auth=("admin", grafana_admin_password),
        timeout=5.0,
    )


@contextlib.contextmanager
def _quiet_httpx_retries() -> Iterator[None]:
    """Suppress httpx's per-request INFO log line for the duration of a
    bounded retry loop against Grafana.

    Each attempt otherwise logs an `HTTP Request: GET ... "200 OK"` line at
    INFO -- pure noise for a handful of retries polled every couple seconds,
    the same "expected outcome shouldn't spam the console" philosophy #3436
    applied to subprocess probe failures.
    """
    httpx_logger = logging.getLogger("httpx")
    previous_level = httpx_logger.level
    httpx_logger.setLevel(logging.WARNING)
    try:
        yield
    finally:
        httpx_logger.setLevel(previous_level)


def _grafana_admin_auth_status(grafana_ui_url: str, grafana_admin_password: str) -> str:
    """Probe `grafana_admin_password` against the running Grafana instance.

    Returns one of `"ok"` (200), `"unauthorized"` (401 -- Grafana answered,
    the credential is genuinely wrong), or `"unreachable"` (connection
    error, or any other status) -- e.g. Grafana still starting, or stuck in
    a crash loop. `_reconcile_grafana_admin_credential` (#3538) uses this
    distinction to give a failure message that points at the right fix: a
    rejected credential and an unreachable/crash-looping Grafana need
    opposite operator responses.
    """
    try:
        with _grafana_admin_client(grafana_ui_url, grafana_admin_password) as client:
            status_code = client.get("/api/org").status_code
    except httpx.HTTPError:
        return "unreachable"
    if status_code == 200:
        return "ok"
    if status_code == 401:
        return "unauthorized"
    return "unreachable"


def _grafana_admin_authenticates(grafana_ui_url: str, grafana_admin_password: str) -> bool:
    """Whether `grafana_admin_password` currently authenticates as `admin`
    against the running Grafana instance."""
    return _grafana_admin_auth_status(grafana_ui_url, grafana_admin_password) == "ok"


def _reset_grafana_admin_password(password: str) -> OpsResult:
    """Force Grafana's actual admin password to `password` via `grafana cli
    admin reset-admin-password` run inside the container.

    Unlike `GF_SECURITY_ADMIN_PASSWORD`, this takes effect regardless of
    whether the volume is fresh (first boot) or long-lived (env var is only
    applied at first boot -- irrelevant to an existing volume, which is
    exactly the deployment shape that reproduced #3458's 401s).

    `password` is piped in over stdin rather than appended to `cmd` as a
    positional argv value: `_redact_cmd`'s masking only recognizes secrets
    that follow a secret-named flag (`--api-key VALUE`) or an inline
    `--flag=value`, so a bare positional value like this one would reach
    `_run`'s non-zero-exit logging -- and `ps`/shell history -- in clear
    text (#3644, CodeQL py/clear-text-logging-sensitive-data #105/#106).
    """
    if not _compose_available():
        return OpsResult(
            False,
            "Cannot reset Grafana admin password",
            "Docker Compose not found -- install Docker to manage the observability stack.",
        )
    cmd = [
        "docker",
        "compose",
        "-f",
        str(self_heal.COMPOSE_FILE),
        "exec",
        "-T",
        "grafana",
        "sh",
        "-c",
        'grafana cli admin reset-admin-password "$(cat)"',
    ]
    cp = _run(cmd, check=False, input=password)
    if cp.returncode != 0:
        return OpsResult(
            False,
            "Failed to reset Grafana admin password",
            _output_excerpt(cp),
        )
    return OpsResult(True, "Reset Grafana admin password to the ops-managed credential")


def _reconcile_grafana_admin_credential(
    grafana_ui_url: str,
    cfg: ConfigParser,
    *,
    attempts: int = 3,
    delay_s: float = 2.0,
) -> tuple[str | None, OpsResult]:
    """Make the Grafana admin credential deterministic before anything else
    authenticates with it (#3458).

    Never authenticates with an empty password: `_grafana_admin_password`
    always returns a real value. Tries that value against the running
    instance first (retrying briefly for Grafana's own startup window); if
    it doesn't work -- unset config default drifted from an existing
    volume's real password, a hand-edited `.env`, whatever -- resets the
    container's password to it via `grafana cli admin reset-admin-password`
    and re-verifies. Returns `(password, result)`: `password` is `None` and
    `result.ok` is `False` when reconciliation could not be completed, so
    callers can skip credential-dependent follow-on checks and surface this
    ONE actionable failure instead of each of them separately 401ing.

    The final failure message distinguishes a genuinely rejected credential
    (Grafana answered 401 -- the stored password is wrong) from Grafana
    being unreachable or crash-looping the whole time (#3538: these need
    opposite operator responses, and were previously reported with the same
    "still doesn't authenticate" message regardless of which one happened).
    """
    password = _grafana_admin_password(cfg)
    last_status = "unreachable"

    with _quiet_httpx_retries():
        for attempt in range(attempts):
            last_status = _grafana_admin_auth_status(grafana_ui_url, password)
            if last_status == "ok":
                return password, OpsResult(True, "Grafana admin credential already reconciled")
            if attempt < attempts - 1:
                time.sleep(delay_s)

        reset_result = _reset_grafana_admin_password(password)
        if not reset_result.ok:
            return None, OpsResult(
                False,
                "Could not reconcile Grafana admin credential",
                f"{reset_result.message}"
                + (f": {reset_result.details}" if reset_result.details else "")
                + " -- check `nyxgpt ops logs grafana` and confirm the grafana container "
                "is running.",
            )

        for attempt in range(attempts):
            last_status = _grafana_admin_auth_status(grafana_ui_url, password)
            if last_status == "ok":
                return password, OpsResult(
                    True,
                    f"{reset_result.message} (stored at {_grafana_admin_password_path()})",
                )
            if attempt < attempts - 1:
                time.sleep(delay_s)

    if last_status == "unreachable":
        return None, OpsResult(
            False,
            "Grafana is unreachable after reset",
            "Reset via `grafana cli admin reset-admin-password` succeeded but Grafana never "
            "answered GET /api/org afterward -- this looks like Grafana crash-looping or still "
            "starting, not a rejected credential. Check `nyxgpt ops status` (a compose service "
            "stuck `restarting` is the tell) and `nyxgpt ops logs grafana` for the boot error.",
        )
    return None, OpsResult(
        False,
        "Grafana admin credential still doesn't authenticate after reset",
        f"Reset via `grafana cli admin reset-admin-password` succeeded but GET /api/org "
        f"still rejects the password stored at {_grafana_admin_password_path()} -- check "
        "`nyxgpt ops logs grafana` for a startup error.",
    )


def _verify_grafana_datasources_resolve(
    grafana_ui_url: str,
    grafana_admin_password: str,
    *,
    attempts: int = 5,
    delay_s: float = 2.0,
) -> OpsResult:
    """Confirm every datasource declared in provisioning actually resolves in
    the running Grafana instance -- i.e. `GET /api/datasources` lists it.

    This directly targets the #3424 failure mode: a provisioning/plugin/env
    change that silently fails to apply (stale container, broken plugin
    download, a provisioning YAML error for one entry) leaves a declared
    datasource unreachable, and every panel that queries it shows "Datasource
    was not found" instead of a clear ops-level error. Retries briefly since
    Grafana may still be inside its startup/provisioning window right after
    `up -d`.
    """
    expected = set(_grafana_provisioned_datasource_uids())
    if not expected:
        return OpsResult(True, "No datasources declared in provisioning -- nothing to verify")

    last_error: Exception | None = None
    with _quiet_httpx_retries():
        for attempt in range(attempts):
            try:
                with _grafana_admin_client(grafana_ui_url, grafana_admin_password) as client:
                    resp = client.get("/api/datasources")
                    if resp.status_code >= 400:
                        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
                    actual = {ds.get("uid") for ds in resp.json()}
                missing = expected - actual
                if not missing:
                    return OpsResult(
                        True,
                        f"Verified {len(expected)} provisioned Grafana datasource(s) resolve",
                    )
                if attempt < attempts - 1:
                    time.sleep(delay_s)
                    continue
                return OpsResult(
                    False,
                    f"Grafana datasource(s) failed to provision: {', '.join(sorted(missing))}",
                    "Declared in docker/grafana/provisioning/datasources/*.yml but not "
                    "returned by GET /api/datasources -- check `nyxgpt ops logs grafana` for a "
                    "provisioning error (bad plugin id, YAML syntax, unreachable datasource "
                    "type) near 'inserting datasource from configuration'.",
                )
            except Exception as e:
                last_error = e
                if attempt < attempts - 1:
                    time.sleep(delay_s)
                    continue
    return OpsResult(
        False,
        "Could not reach Grafana to verify provisioned datasources",
        str(last_error) if last_error else "",
    )


def _grafana_expected_plugin_ids() -> list[str]:
    """Plugin ids declared in `docker-compose.yml`'s `GF_INSTALL_PLUGINS`.

    Regex-scraped for the same reason as `_grafana_provisioned_datasource_uids`
    -- no PyYAML runtime dependency, and this is repo-controlled config.
    """
    if not self_heal.COMPOSE_FILE.exists():
        return []
    match = re.search(r'GF_INSTALL_PLUGINS:\s*"([^"]*)"', self_heal.COMPOSE_FILE.read_text())
    if not match:
        return []
    return [p.strip() for p in match.group(1).split(",") if p.strip()]


def _verify_grafana_plugins_installed(
    grafana_ui_url: str,
    grafana_admin_password: str,
    *,
    attempts: int = 5,
    delay_s: float = 2.0,
) -> OpsResult:
    """Confirm every plugin listed in `GF_INSTALL_PLUGINS` is actually
    installed, rather than assuming a successful env-var-driven download
    (#3424's "plugin installation is confirmed... rather than assumed from
    GF_INSTALL_PLUGINS" AC). `GF_INSTALL_PLUGINS` downloads each plugin from
    the network at container startup and fails silently (a logged error, not
    a crash) if that download fails -- e.g. no network access, registry
    outage, or a renamed/typo'd plugin id. On any such failure the plugin is
    never registered, so `GET /api/plugins/<id>/settings` 404s -- that's the
    signal used for every plugin type.

    `enabled` in that response is only meaningful for `type: "app"` plugins,
    which have an explicit on/off toggle; datasource/panel/renderer plugins
    have no such toggle and always report `enabled: false` even once fully
    installed and loaded (#3560 -- `yesoreyeram-infinity-datasource` false-
    failed here despite its provisioned datasource resolving fine in the very
    next check). So `enabled` is only enforced for app plugins; for every
    other type, the 200 itself is proof Grafana registered the plugin.
    """
    expected = _grafana_expected_plugin_ids()
    if not expected:
        return OpsResult(True, "No plugins declared in GF_INSTALL_PLUGINS -- nothing to verify")

    last_error: Exception | None = None
    with _quiet_httpx_retries():
        for attempt in range(attempts):
            try:
                missing: list[str] = []
                missing_details: list[str] = []
                with _grafana_admin_client(grafana_ui_url, grafana_admin_password) as client:
                    for plugin_id in expected:
                        resp = client.get(f"/api/plugins/{plugin_id}/settings")
                        if resp.status_code != 200:
                            missing.append(plugin_id)
                            missing_details.append(
                                f"{plugin_id}: HTTP {resp.status_code}: {resp.text[:500]}"
                            )
                            continue
                        settings = resp.json()
                        if settings.get("type") == "app" and not settings.get("enabled"):
                            missing.append(plugin_id)
                            missing_details.append(f"{plugin_id}: not enabled: {resp.text[:500]}")
                if not missing:
                    return OpsResult(
                        True, f"Verified {len(expected)} GF_INSTALL_PLUGINS plugin(s) installed"
                    )
                if attempt < attempts - 1:
                    time.sleep(delay_s)
                    continue
                return OpsResult(
                    False,
                    f"Grafana plugin(s) failed to install: {', '.join(missing)}",
                    "Listed in docker-compose.yml's GF_INSTALL_PLUGINS but not registered (or, "
                    "for app-type plugins, not enabled) per GET /api/plugins/<id>/settings -- "
                    "check `nyxgpt ops logs grafana` for a plugin download error (no network "
                    "access, registry outage, renamed/typo'd plugin id).\n"
                    + "\n".join(missing_details),
                )
            except Exception as e:
                last_error = e
                if attempt < attempts - 1:
                    time.sleep(delay_s)
                    continue
    return OpsResult(
        False,
        "Could not reach Grafana to verify installed plugins",
        str(last_error) if last_error else "",
    )


# Grafana service account minted for `nyxgpt ops doctor`'s Loki log-volume
# check -- see `_grafana_doctor_token_path` and `_provision_grafana_doctor_token`.
GRAFANA_DOCTOR_SA_NAME = "nyxgpt-ops-doctor"
GRAFANA_DOCTOR_TOKEN_NAME = "nyxgpt-ops-doctor"


def _provision_grafana_doctor_token(grafana_ui_url: str, grafana_admin_password: str) -> OpsResult:
    """Mint a Viewer-scoped Grafana service-account token for doctor's Loki
    check, so it authenticates without depending on the shared admin
    password at query time (#3438).

    Grafana only returns a service-account token's secret at creation time
    (like a GitHub PAT) -- it can't be re-fetched later even to confirm it
    still works -- so this only mints a fresh one when
    `_grafana_doctor_token_path()` doesn't already hold one. A token that's
    since been revoked/gone stale is instead caught (and reported as an
    actionable `doctor` finding, not a silent skip) by
    `_loki_recent_volume_by_logger` at query time.
    """
    token_path = _grafana_doctor_token_path()
    if token_path.exists() and token_path.read_text().strip():
        return OpsResult(True, f"{token_path} already holds a Grafana service-account token")

    try:
        with _grafana_admin_client(grafana_ui_url, grafana_admin_password) as client:
            sa_id: Any = None
            resp = client.get(
                "/api/serviceaccounts/search", params={"query": GRAFANA_DOCTOR_SA_NAME}
            )
            if resp.status_code >= 400:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
            for sa in resp.json().get("serviceAccounts", []):
                if isinstance(sa, dict) and sa.get("name") == GRAFANA_DOCTOR_SA_NAME:
                    sa_id = sa.get("id")
                    break
            if sa_id is None:
                resp = client.post(
                    "/api/serviceaccounts",
                    json={"name": GRAFANA_DOCTOR_SA_NAME, "role": "Viewer"},
                )
                if resp.status_code >= 400:
                    raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
                sa_id = resp.json().get("id")

            resp = client.post(
                f"/api/serviceaccounts/{sa_id}/tokens",
                json={"name": GRAFANA_DOCTOR_TOKEN_NAME},
            )
            if resp.status_code >= 400:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
            token: Any = resp.json().get("key")
    except Exception as e:
        return OpsResult(
            False,
            "Failed to provision Grafana service-account token for doctor's Loki check",
            f"{type(e).__name__}: {e}",
        )

    if not token:
        return OpsResult(
            False,
            "Grafana service-account token response missing a key",
            "Check `nyxgpt ops logs grafana` for a /api/serviceaccounts error.",
        )

    try:
        token_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        token_path.write_text(str(token))
        token_path.chmod(0o600)
    except OSError as e:
        return OpsResult(
            False, f"Failed to write Grafana service-account token to {token_path}", str(e)
        )

    return OpsResult(True, f"Provisioned Grafana service-account token for doctor at {token_path}")


def _recreate_grafana_if_provisioning_drifted() -> OpsResult | None:
    """Force-recreate just the `grafana` Compose container when provisioning
    or env has drifted since this tool last reconciled it.

    `docker compose up -d` is a no-op for a container whose image/env didn't
    change from Compose's point of view even when the datasource YAML it
    mounts read-only did -- and env vars like `GF_INSTALL_PLUGINS` only take
    effect at container start. Recreating (not merely restarting) guarantees
    both are picked up on the next boot. Returns None if there's nothing to
    do (not drifted, Docker unavailable, or grafana isn't running yet -- the
    normal `up -d` right after this call handles first-boot).
    """
    if not _compose_available():
        return None
    if not _grafana_provisioning_drifted():
        return None
    if _compose_stack_snapshot().get("grafana") != "running":
        # Nothing running yet to be stale -- the normal `up -d` below will
        # create it fresh with current provisioning/env already.
        return None

    cmd = [
        "docker",
        "compose",
        "-f",
        str(self_heal.COMPOSE_FILE),
        "--profile",
        "monitoring",
        "up",
        "-d",
        "--force-recreate",
        "grafana",
    ]
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return OpsResult(
            False,
            "Failed to recreate Grafana for provisioning/env drift",
            _output_excerpt(cp),
        )
    return OpsResult(
        True,
        "Recreated Grafana (provisioning/env drift detected) so plugin installs and "
        "datasource changes actually take effect",
    )


# --- Linux bridge->loopback relay for the native API (#3721) ---

# Compose profile the `host-api-relay` service joins when it's needed, and the
# inert profile name that keeps it out of every `--profile` selection when it
# isn't. `monitoring` rather than a profile of its own, so the relay starts,
# stops, restarts, and comes down in lockstep with prometheus -- it exists
# purely to make prometheus's scrape of the native API reachable.
HOST_RELAY_ENABLED_PROFILE = "monitoring"
HOST_RELAY_DISABLED_PROFILE = "disabled"

# Compose `.env` variables `_sync_host_relay_env` owns end-to-end. Like
# COMPOSE_ENV_SECRET_MAP's secrets these are derived, never hand-edited: every
# observability bring-up recomputes them from the OS, the docker bridge, and
# config.ini, so a machine that changes (docker reinstalled on a different
# subnet, `[api] host` widened by hand) reconciles on the next run.
HOST_RELAY_ENV_PROFILE_VAR = "NYXGPT_HOST_RELAY_PROFILE"
HOST_RELAY_ENV_GATEWAY_VAR = "NYXGPT_HOST_GATEWAY_IP"

# `[api] host` values that leave the native API reachable only from the host
# itself -- exactly the case the relay exists to bridge. Anything else already
# listens on an address containers can reach (and, per app.py's P6-1 gate,
# already required auth to start), so the relay would be redundant *and* would
# fail to bind its own listener against the API's wildcard socket.
LOOPBACK_API_HOSTS: frozenset[str] = frozenset({"", "127.0.0.1", "localhost", "::1"})


def _docker_bridge_gateway_ip() -> str | None:
    """Return the IPv4 gateway of docker's default `bridge` network.

    This is the address `extra_hosts: host.docker.internal:host-gateway`
    resolves to inside a container on a plain Linux engine (docker defaults
    `--host-gateway-ip` to it), so it is the address the relay must listen on
    for `host.docker.internal:8000` to reach the native API.

    Returns None when docker isn't usable, the network has no IPv4 gateway, or
    the output can't be parsed -- callers treat that as "leave the relay off"
    rather than guessing at 172.17.0.1.
    """
    cp = _run(
        [
            "docker",
            "network",
            "inspect",
            "bridge",
            "--format",
            "{{range .IPAM.Config}}{{.Gateway}} {{end}}",
        ],
        check=False,
        expected=True,
    )
    if cp.returncode != 0:
        return None
    for token in (cp.stdout or "").split():
        try:
            addr = ipaddress.ip_address(token.strip())
        except ValueError:
            continue
        if addr.version == 4:
            return str(addr)
    return None


def _native_api_host(cfg_path: Path) -> str:
    """Read `[api] host` from config.ini without importing the full config stack.

    Falls back to the same `127.0.0.1` default the native wrapper scripts use
    (`_NATIVE_API_WRAPPER_TEMPLATE`) when the file is missing or unparseable,
    which is also the value that makes the relay necessary.
    """
    parser = ConfigParser()
    try:
        parser.read(cfg_path, encoding="utf-8")
    except Exception as e:
        logger.warning(
            "Failed to parse %s while resolving the native API bind host; "
            "assuming the 127.0.0.1 default: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return "127.0.0.1"
    return parser.get("api", "host", fallback="127.0.0.1").strip()


def _host_relay_decision(cfg_path: Path) -> tuple[bool, str, str]:
    """Decide whether the `host-api-relay` Compose service should run here.

    Returns `(enabled, gateway_ip, reason)`. `gateway_ip` is always a usable
    literal (the loopback placeholder when disabled) so the generated `.env`
    never leaves Compose interpolating an empty `bind=` argument.
    """
    if not _is_linux():
        # Docker Desktop proxies host.docker.internal to the host's loopback
        # itself, so prometheus already reaches a native API on 127.0.0.1.
        return False, "127.0.0.1", f"not needed on {platform.system()}"

    api_host = _native_api_host(cfg_path)
    if api_host.lower() not in LOOPBACK_API_HOSTS:
        return (
            False,
            "127.0.0.1",
            f"[api] host = {api_host} already listens beyond loopback",
        )

    gateway = _docker_bridge_gateway_ip()
    if gateway is None:
        return False, "127.0.0.1", "could not resolve the docker bridge gateway address"

    return True, gateway, f"relaying {gateway} -> 127.0.0.1 for container scrapes"


def _apply_env_updates(lines: list[str], updates: dict[str, str]) -> list[str]:
    """Rewrite `VAR=...` lines in a `.env` file body, appending any that are absent.

    Mirrors `sync_env_from_config`'s line-based rewrite so comments, ordering,
    and every variable this function doesn't own survive verbatim.
    """
    patched = list(lines)
    for var_name, value in updates.items():
        new_line = f"{var_name}={value}"
        for i, line in enumerate(patched):
            if line.startswith(f"{var_name}="):
                patched[i] = new_line
                break
        else:
            patched.append(new_line)
    return patched


def _sync_host_relay_env(cfg_path: Path | None = None, env_path: Path | None = None) -> OpsResult:
    """Write the `host-api-relay` toggle + bind address into Compose's `.env`.

    On a plain Linux docker engine a container has no route to the host's
    127.0.0.1, so prometheus cannot scrape a natively-installed `nyxgpt-api`
    and every Grafana panel stays empty (#3721). Widening `[api] host` to
    `0.0.0.0` fixes the scrape but publishes the API on every interface and
    trips app.py's P6-1 bind-security gate (forcing auth on with it), which is
    exactly the "no 0.0.0.0 ingress" posture P6-4 is meant to hold. Instead,
    enable the `host-api-relay` Compose service: it shares the host's network
    namespace, listens only on the docker bridge gateway, and forwards to the
    host's own loopback.

    Reconciles in both directions -- a host that no longer needs the relay
    (moved to macOS's Docker Desktop, `[api] host` widened by hand, docker
    removed) gets the profile written back to its inert `disabled` value, so
    the next `up` drops the container instead of leaving it bound.

    Never fails the caller: a `.env` that can't be written means Compose falls
    back to the compose-file defaults (relay off), which is the pre-#3721
    behaviour, not a broken stack.
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    # Anchored to the compose file every `docker compose -f ...` in this module
    # passes, not to NYXGPT_HOME directly: Compose resolves `.env` relative to
    # the compose file's own directory, and `self_heal.COMPOSE_FILE` is the one
    # place that path can be overridden (NYXGPT_COMPOSE_FILE, used from inside
    # the api container). Normally the two are the same `~/.nyxGPT`.
    env_path = env_path or (self_heal.COMPOSE_FILE.parent / ".env")
    example_path = env_path.parent / ".env.example"

    enabled, gateway, reason = _host_relay_decision(cfg_path)
    profile = HOST_RELAY_ENABLED_PROFILE if enabled else HOST_RELAY_DISABLED_PROFILE

    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8").splitlines()
    elif example_path.exists():
        lines = example_path.read_text(encoding="utf-8").splitlines()
    else:
        # `_sync_packaged_resources` hasn't run yet (or this is a bare test
        # home). Compose has no `.env` to read either, so its own
        # `disabled`/loopback defaults already describe the desired state.
        return OpsResult(
            True,
            "Skipped host API relay (no Compose .env yet)",
            f"Neither {env_path} nor {example_path} exists -- run `nyxgpt ops install`.",
        )

    updates = {
        HOST_RELAY_ENV_PROFILE_VAR: profile,
        HOST_RELAY_ENV_GATEWAY_VAR: gateway,
    }
    patched = _apply_env_updates(lines, updates)
    if patched != lines or not env_path.exists():
        try:
            _ensure_dir(env_path.parent)
            env_path.write_text("\n".join(patched) + "\n", encoding="utf-8")
            os.chmod(env_path, 0o600)
        except OSError as e:
            return OpsResult(
                True,
                "Could not update the host API relay settings in .env",
                f"{env_path}: {e}. Prometheus may not be able to scrape a native "
                "API on Linux until this is writable.",
            )

    if enabled:
        return OpsResult(
            True,
            f"Host API relay enabled ({reason})",
            "Prometheus scrapes the native API through the docker bridge gateway; "
            "`[api] host` stays loopback-only, so the API is not exposed to the LAN.",
        )
    return OpsResult(True, f"Host API relay disabled ({reason})")


def _start_observability_stack(
    extra_compose_files: list[Path] | None = None, force_recreate: bool = False
) -> list[OpsResult]:
    """Start the Grafana/Loki/Jaeger/GlitchTip Compose profiles (idempotent).

    Wraps `docker compose --profile monitoring --profile logging --profile
    tracing --profile errors up -d <services>` so operators never type that
    raw command themselves (the ops-wrapper principle) -- dashboards are
    already pre-provisioned as code via docker/grafana/provisioning, so
    bringing the stack up is the only step needed to get a populated SRE
    view. Re-running is safe: `docker compose up -d` only (re)creates what's
    missing/changed.

    The service list passed to `up -d` is resolved dynamically via `docker
    compose config --services` and explicitly excludes `CORE_APP_SERVICES`.
    This matters because `ollama`/`cassandra`/`api`/`web` have no `profiles:`
    key in docker-compose.yml, so Compose treats them as always-on default
    services -- `--profile` flags alone would NOT stop `up -d` from also
    building and starting the entire core app stack, which would collide
    with a native install's own processes on the same ports.

    Skips (without failing `ops install`) on hosts without Docker: these
    tools have no native/Homebrew path, so a native-only host simply won't
    have dashboards until Docker is installed.
    """
    if not _compose_available():
        return [
            OpsResult(
                True,
                "Skipped observability stack (Docker not found)",
                "Grafana/Loki/Jaeger/GlitchTip only ship as Docker Compose profiles -- "
                "install Docker, then re-run `nyxgpt ops install` (or `nyxgpt ops "
                "observability`) to get dashboards. See docs/docker-compose.md.",
            )
        ]

    base_cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE)]
    for extra in extra_compose_files or []:
        base_cmd += ["-f", str(extra)]
    for profile in OBSERVABILITY_PROFILES:
        base_cmd += ["--profile", profile]

    services_cp = _run(base_cmd + ["config", "--services"], check=False)
    if services_cp.returncode != 0:
        return [
            OpsResult(
                False,
                "Failed to resolve observability services",
                (services_cp.stderr or services_cp.stdout or "").strip(),
            )
        ]

    observability_services = sorted(
        {s.strip() for s in services_cp.stdout.splitlines() if s.strip()} - CORE_APP_SERVICES
    )
    if not observability_services:
        return [
            OpsResult(
                False,
                "No observability services resolved",
                "`docker compose config --services` returned no services outside the "
                "core app stack for the monitoring/logging/tracing/errors profiles -- "
                "check docker-compose.yml.",
            )
        ]

    cmd = base_cmd + ["up", "-d"]
    if force_recreate:
        # Ensure containers attach to the current network even if ones from an
        # earlier bring-up linger on a different network (e.g. switching to the
        # terraform-net override) -- otherwise glitchtip-migrate et al. can't
        # resolve their peers and the stack silently half-starts.
        cmd += ["--force-recreate"]
    cmd += observability_services

    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [
            OpsResult(
                False,
                "Failed to start observability stack",
                _output_excerpt(cp),
            )
        ]

    _enable_observability_config()

    return [
        OpsResult(
            True,
            "Observability stack up: Grafana http://localhost:3001, "
            "Jaeger http://localhost:16686, Loki via Grafana Explore, "
            "GlitchTip http://localhost:8080",
            "Dashboards, tracing, and log search are live with no further steps. "
            "GlitchTip's admin user/org/project/DSN are auto-provisioned next by "
            "`nyxgpt ops glitchtip-init` (run automatically as part of `nyxgpt ops "
            "install`) once its container passes its health check.",
        )
    ]


def _reconcile_grafana_provisioning() -> list[OpsResult]:
    """Bring the observability stack up AND make Grafana's provisioning
    state deterministic: recreate on drift before starting, reconcile the
    admin credential (#3458), then verify the declared datasources and
    GF_INSTALL_PLUGINS plugins actually resolve afterward (#3424), and mint
    doctor's Loki service-account token if it doesn't already have one
    (#3438).

    This is the entrypoint `nyxgpt ops install` / `nyxgpt ops observability`
    / wizard toggles use instead of calling `_start_observability_stack`
    directly, so the extra drift/verification steps apply everywhere the
    stack gets (re)started but stay out of `_start_observability_stack`
    itself (which several other call sites -- including the terraform-network
    variant and tests -- use as a narrower "just run compose up" primitive).

    Assumes the packaged ops resources (`self_heal.COMPOSE_FILE`, the
    Grafana provisioning directory) are already synced to `NYXGPT_HOME` --
    `install()` sequences its own `_sync_packaged_resources` step before this
    one; standalone callers (`observability()`) sync first themselves.
    """
    drift_result = _recreate_grafana_if_provisioning_drifted()
    results = [drift_result] if drift_result is not None else []
    if drift_result is not None and not drift_result.ok:
        return results

    # Must run before the stack starts: it decides whether Compose resolves
    # the `host-api-relay` service into the monitoring profile at all, which
    # is what gives prometheus a route to a natively-installed API on Linux
    # (#3721). `_start_observability_stack` reads `.env` when it enumerates
    # services, so the write has to land first.
    results.append(_sync_host_relay_env())

    start_results = _start_observability_stack()
    results += start_results
    if not all(r.ok for r in start_results):
        return results

    _record_grafana_provisioning_fingerprint()

    cfg_path = Path.home() / ".nyxGPT" / "config.ini"
    if cfg_path.exists():
        try:
            cfg_parser = ConfigParser()
            cfg_parser.read(cfg_path)
            monitoring_config = get_monitoring_config(cfg_parser)
            grafana_ui_url = monitoring_config["grafana_ui_url"]

            # Bounded wait-for-healthy (#3538) before anything authenticates
            # against Grafana: `_start_observability_stack`/the drift
            # recreate above may have just (re)started the container, and a
            # container stuck crash-looping (e.g. a broken alerting-
            # provisioning file) should surface here as one clear failure
            # rather than as a misleading "credential doesn't authenticate".
            # Skipped as a no-op when Grafana isn't part of the running
            # Compose stack at all (e.g. Docker not found) -- the
            # credential-reconcile call below already handles that host
            # shape on its own terms.
            grafana_running = _compose_stack_snapshot().get("grafana") == "running"
            if grafana_running and not _wait_for_grafana_healthy():
                results.append(
                    OpsResult(
                        False,
                        "Grafana never became healthy",
                        "Check `nyxgpt ops status` (a compose service stuck `restarting` is "
                        "the tell) and `nyxgpt ops logs grafana` for the boot error.",
                    )
                )
                return results

            grafana_admin_password, credential_result = _reconcile_grafana_admin_credential(
                grafana_ui_url, cfg_parser
            )
            results.append(credential_result)
            # Only attempt the credential-dependent checks once the admin
            # password is known-good -- otherwise each would independently
            # 401 and turn one auth problem into three separate FAILs.
            if grafana_admin_password is not None:
                results.append(
                    _verify_grafana_plugins_installed(grafana_ui_url, grafana_admin_password)
                )
                results.append(
                    _verify_grafana_datasources_resolve(grafana_ui_url, grafana_admin_password)
                )
                results.append(
                    _provision_grafana_doctor_token(grafana_ui_url, grafana_admin_password)
                )
        except Exception as e:
            logger.warning(
                "Failed to verify Grafana plugins/datasources, skipping: %s",
                e,
                extra={"component": "ops"},
            )

    return results


def _start_observability_stack_terraform() -> list[OpsResult]:
    """Start the observability Compose profiles on the terraform network.

    A step in `nyxgpt ops install --terraform --local`, run after `terraform
    apply` has created the `nyxgpt-terraform` network and the core containers.
    Reuses `_start_observability_stack` with the terraform-net override so the
    observability containers join that network and interoperate with the
    terraform-managed core (Prometheus scrapes the tf-api, the api reaches
    otel-collector/glitchtip, etc.).
    """
    if not TERRAFORM_NET_OVERRIDE.exists():
        return [
            OpsResult(
                False,
                f"Missing {TERRAFORM_NET_OVERRIDE}",
                "Cannot attach observability to the terraform network without the override.",
            )
        ]
    results = _start_observability_stack(
        extra_compose_files=[TERRAFORM_NET_OVERRIDE], force_recreate=True
    )
    # Bounded wait-for-healthy (#3538), mirroring the native
    # `_reconcile_grafana_provisioning` path: `docker compose up -d` returns as
    # soon as the containers are created, but Grafana (57 plugins + provisioning)
    # takes ~30s to actually serve, and `_terraform_stack_health` only gates on
    # the core containers. Without this wait `ops install --terraform` returns
    # before Grafana is reachable and callers (the smoke gate, a user opening the
    # dashboard) race its startup. A container stuck crash-looping never reports
    # healthy, so this surfaces as one clear failure instead of a silent race.
    if _compose_stack_snapshot().get("grafana") == "running" and not _wait_for_grafana_healthy():
        results.append(
            OpsResult(
                False,
                "Grafana never became healthy",
                "Check `nyxgpt ops status` (a compose service stuck `restarting` is the tell) "
                "and `nyxgpt ops logs grafana` for the boot error.",
            )
        )
    return results


def _stop_observability_stack_terraform() -> list[OpsResult]:
    """Tear down the observability Compose stack attached to the terraform network.

    The mirror of `_start_observability_stack_terraform`, run BEFORE `terraform
    destroy`. `install --terraform --local` brings observability up on the
    `nyxgpt-terraform` network; `terraform destroy` then can't remove that
    network while those containers are still attached (it times out on the
    network delete). This `docker compose down` (with the terraform-net
    override) removes the observability containers and detaches them from the
    network -- the external network itself is left for terraform to destroy.
    Best-effort: a Docker-less host or a missing override just skips it.
    """
    if not _compose_available():
        return [OpsResult(True, "Skipped observability teardown (Docker not found)")]
    if not TERRAFORM_NET_OVERRIDE.exists():
        return [
            OpsResult(True, f"Skipped observability teardown (no {TERRAFORM_NET_OVERRIDE.name})")
        ]
    cmd = [
        "docker",
        "compose",
        "-f",
        str(self_heal.COMPOSE_FILE),
        "-f",
        str(TERRAFORM_NET_OVERRIDE),
    ]
    for profile in OBSERVABILITY_PROFILES:
        cmd += ["--profile", profile]
    cmd += ["down"]
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [OpsResult(False, "Failed to tear down observability stack", _cp_details(cp))]
    return [OpsResult(True, "Observability stack torn down (detached from terraform network)")]


def observability(args) -> int:
    """CLI entrypoint for `nyxgpt ops observability`.

    Starts the monitoring/logging/tracing/errors Compose profiles (Grafana,
    Prometheus, Loki, promtail, the OTel collector, Jaeger, GlitchTip) so
    operators never need to run a raw `docker compose --profile X up`
    themselves. Idempotent: re-running just confirms everything is already up.

    Documented as runnable without `nyxgpt ops install` having gone first, so
    syncs the packaged ops resources itself (#3621): `_reconcile_grafana_provisioning`
    reads `self_heal.COMPOSE_FILE` and the Grafana provisioning directory,
    both of which only exist under `NYXGPT_HOME` once
    `_sync_packaged_resources` has copied them there.

    Returns 0 on success, else 2.
    """
    logger.info(
        "ops: observability starting", extra={"component": "ops", "action": "observability"}
    )
    sync_results: list[OpsResult] = []

    def _observability_sync_step() -> list[OpsResult]:
        nonlocal sync_results
        sync_results = _sync_packaged_resources()
        return sync_results

    def _observability_reconcile_step() -> list[OpsResult]:
        if not all(r.ok for r in sync_results):
            return [
                OpsResult(
                    True,
                    "Skipped Grafana provisioning reconcile (packaged resource sync failed)",
                )
            ]
        return _reconcile_grafana_provisioning()

    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        ("sync packaged resources", _observability_sync_step),
        ("reconcile observability stack", _observability_reconcile_step),
    ]
    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("observability", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: observability %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "observability", "ok": ok},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("observability", "observability", result, message)
    return 0 if ok else 2


def reconcile_observability(enable: bool) -> list[OpsResult]:
    """Bring the observability Compose stack in line with a desired enabled state.

    Used by the web config wizard (#3354) after config.ini's
    monitoring/tracing/error_tracking/log_aggregation `enabled` flags change
    via the API, so enabling one of those sections in the wizard results in
    the Compose profile actually starting -- not just a flag flip -- and
    disabling all of them tears the stack back down. Mirrors `nyxgpt ops
    observability` / `nyxgpt ops stop --target observability` exactly, so
    callers (the config API) never need to shell out to `docker compose`
    themselves. Records its own ops lifecycle action/event (#3390) since,
    unlike `restart()`/`stop()`, this is the entrypoint the dashboard calls
    directly rather than going through the CLI-facing `observability()`.
    """
    results = _reconcile_grafana_provisioning() if enable else _stop_observability_stack()
    result, message = _ops_action_outcome(results)
    _record_ops_action("observability" if enable else "stop", "observability", result, message)
    return results


# --- Env sync public API ---

# Maps a Docker Compose `.env` variable to the config.ini `[section] key` it's
# derived from. config.ini (generated by `nyxgpt wizard`) is the single
# source of truth for these secrets -- Compose's `.env` is a generated
# artifact, not something the user hand-edits.
COMPOSE_ENV_SECRET_MAP: dict[str, tuple[str, str]] = {
    "NYXGPT_AUTH_API_KEY": ("auth", "api_key"),
    "GRAFANA_ADMIN_PASSWORD": ("monitoring", "grafana_admin_password"),
}


def sync_env_from_config(
    cfg_path: Path | None = None, env_path: Path | None = None
) -> list[OpsResult]:
    """Derive Docker Compose's `.env` secrets from `~/.nyxGPT/config.ini`.

    Overwrites (or appends) only the secret lines listed in
    `COMPOSE_ENV_SECRET_MAP`; every other line in `.env` (ports, image tags,
    etc.) is left untouched. If `.env` doesn't exist yet, it's seeded from
    `.env.example`.
    """
    from nyxgpt.config import load_config

    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return [
            OpsResult(
                False,
                f"Missing config {cfg_path}",
                "Run `nyxgpt wizard` first to generate config.ini and its secrets.",
            )
        ]

    cfg = load_config(cfg_path)

    # `.env` lives alongside OPS_COMPOSE_FILE (NYXGPT_HOME by default) since
    # Docker Compose resolves it relative to the compose file's own
    # directory. `.env.example` -- the packaged template
    # `_sync_packaged_resources` copies there (#3621) -- always sits next to
    # whichever `.env` this call targets, so an explicit `env_path` override
    # (as `env_sync`'s `--env-file` and this function's own tests use) still
    # finds the matching example alongside it rather than NYXGPT_HOME's.
    env_path = env_path or (NYXGPT_HOME / ".env")
    example_path = env_path.parent / ".env.example"
    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8").splitlines()
    elif example_path.exists():
        lines = example_path.read_text(encoding="utf-8").splitlines()
    else:
        lines = []

    synced: list[str] = []
    for var_name, (section, key) in COMPOSE_ENV_SECRET_MAP.items():
        value = cfg.get(section, key, fallback="")
        if not value:
            continue
        new_line = f"{var_name}={value}"
        for i, line in enumerate(lines):
            if line.startswith(f"{var_name}="):
                lines[i] = new_line
                break
        else:
            lines.append(new_line)
        synced.append(var_name)

    if not synced:
        if not cfg.getboolean("auth", "enabled", fallback=False):
            return [
                OpsResult(
                    True,
                    "No secrets to sync (auth disabled)",
                    "[auth] enabled = false with no api_key set is a valid "
                    "localhost-only configuration -- .env left untouched. Run "
                    "`nyxgpt wizard` to generate secrets before any networked "
                    "deploy, then re-run `nyxgpt ops env-sync`.",
                )
            ]
        return [
            OpsResult(
                False,
                "No secrets found in config.ini to sync",
                f"Set [auth] api_key and/or [monitoring] grafana_admin_password in "
                f"{cfg_path} (re-run `nyxgpt wizard` to generate them), then retry.",
            )
        ]

    _ensure_dir(env_path.parent)
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.chmod(env_path, 0o600)

    return [
        OpsResult(
            True,
            f"Synced {', '.join(synced)} into {env_path} from {cfg_path}",
        )
    ]


def env_sync(args) -> int:
    """CLI entrypoint for `nyxgpt ops env-sync`.

    Reads `--config`/`--env-file` overrides (if given) from `args`, then
    seeds the live `docker/config.docker.ini` from its template (if missing)
    and derives Docker Compose's `.env` secrets from config.ini via
    `sync_env_from_config`, printing an OK/FAIL line per result.

    Seeding the Compose config here (not just in `nyxgpt ops install`) covers
    the Compose-only Quickstart, which runs `nyxgpt ops env-sync` before
    `docker compose up` without going through the native install flow -- so a
    fresh checkout gets the bind-mounted file created before Compose needs it.
    For that same install()-less Quickstart flow to seed `.env` from
    `.env.example` (see `sync_env_from_config`), the packaged ops resources
    have to be synced to `NYXGPT_HOME` first too (#3621) -- otherwise
    `.env.example` isn't there yet and `.env` silently ends up with only the
    secret lines.

    Returns 0 on success, else 2.
    """
    cfg_path = Path(args.config).expanduser() if getattr(args, "config", None) else None
    env_path = Path(args.env_file).expanduser() if getattr(args, "env_file", None) else None

    logger.info(
        "ops: env-sync starting (config=%s, env_file=%s)",
        cfg_path,
        env_path,
        extra={"component": "ops", "action": "env-sync"},
    )

    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        ("sync packaged resources", _sync_packaged_resources),
        ("compose config (derive from native)", _generate_compose_config),
        (
            "sync secrets from config.ini",
            lambda: sync_env_from_config(cfg_path=cfg_path, env_path=env_path),
        ),
        (
            "sync grafana slack webhook secret",
            lambda: _sync_grafana_slack_webhook_secret(cfg_path=cfg_path),
        ),
    ]
    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("env-sync", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: env-sync %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "env-sync", "ok": ok},
    )

    return 0 if ok else 2


# --- Secrets sync: config.ini -> GitHub Actions secrets (#3505) ---
#
# The canonical-store pattern this codifies: several external tokens
# (Slack bot tokens, agent PATs) are write-once -- the issuing service shows
# them only at creation, so hand-editing a second copy into GitHub's
# Settings -> Secrets UI lets the two silently drift. config.ini is the one
# place a human ever pastes these in (via `nyxgpt secrets setup`); this
# pushes them outward, one direction only, to the matching Actions secret.
# `config.SECRETS_SYNC_MANIFEST` is the sole source of truth for *which*
# config.ini keys are in scope -- anything not listed there is never pushed.

GITHUB_API_BASE_URL = "https://api.github.com"


def _github_actions_client(pat: str) -> httpx.Client:
    """Construct an `httpx.Client` authenticated against the GitHub REST API."""
    return httpx.Client(
        base_url=GITHUB_API_BASE_URL,
        timeout=15.0,
        headers={
            "Authorization": f"Bearer {pat}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )


def _secrets_sync_targets(cfg: ConfigParser) -> list[tuple[str, str, str]]:
    """Return `(full_key, value, actions_secret_name)` for every manifest entry with a value.

    A manifest key absent or blank in config.ini is silently skipped (nothing
    to sync yet, not an error) -- `nyxgpt secrets setup`/manual entry decides
    when a given secret exists.
    """
    from nyxgpt.config import SECRETS_SYNC_MANIFEST

    targets = []
    for full_key, actions_secret in SECRETS_SYNC_MANIFEST.items():
        section, key = full_key.split(".", 1)
        value = cfg.get(section, key, fallback="").strip()
        if value:
            targets.append((full_key, value, actions_secret))
    return targets


def _encrypt_for_actions_secret(public_key_b64: str, value: str) -> str:
    """Encrypt `value` for the GitHub Actions secrets API's libsodium sealed-box scheme.

    GitHub requires each secret value sealed with the repo's public key
    (base64-encoded in its API response) before it's PUT to the API -- see
    https://docs.github.com/en/rest/actions/secrets. Returns the
    base64-encoded ciphertext the API expects as `encrypted_value`.
    """
    public_key = nacl_public.PublicKey(base64.b64decode(public_key_b64))
    sealed_box = nacl_public.SealedBox(public_key)
    encrypted = sealed_box.encrypt(value.encode("utf-8"))
    return base64.b64encode(encrypted).decode("utf-8")


def sync_secrets_to_github_actions(
    cfg_path: Path | None = None, dry_run: bool = False
) -> list[OpsResult]:
    """Push `config.SECRETS_SYNC_MANIFEST`'s config.ini values to GitHub Actions secrets.

    One direction only: config.ini -> Actions. Never reads a secret back from
    GitHub (the API can't return one anyway -- write-once). `dry_run=True`
    reports which secrets *would* be pushed (names only, no network call, no
    values) without touching the GitHub API or requiring a valid PAT.
    Returns one `OpsResult` per synced secret (name only in the message --
    never the value) plus, on failure, enough detail to fix the problem
    (missing config field, HTTP status, etc.).
    """
    from nyxgpt.config import (
        get_github_pat,
        get_github_repo_name,
        get_github_repo_owner,
        load_config,
    )

    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return [
            OpsResult(
                False,
                f"Missing config {cfg_path}",
                "Run `nyxgpt wizard` first to generate config.ini.",
            )
        ]

    cfg = load_config(cfg_path)
    targets = _secrets_sync_targets(cfg)
    if not targets:
        return [
            OpsResult(
                True,
                "No mapped secrets have a value set in config.ini -- nothing to sync",
                "Run `nyxgpt secrets setup` (or set a mapped [monitoring]/[github] key) "
                "first, then retry.",
            )
        ]

    if dry_run:
        return [
            OpsResult(True, f"[dry-run] would sync {full_key} -> Actions secret {actions_secret}")
            for full_key, _value, actions_secret in targets
        ]

    pat = get_github_pat(cfg)
    if not pat:
        return [
            OpsResult(
                False,
                "Cannot sync: [github] pat is not set",
                "Run `nyxgpt secrets setup` to configure a GitHub PAT with repo scope.",
            )
        ]
    repo_owner = get_github_repo_owner(cfg)
    repo_name = get_github_repo_name(cfg)
    if not repo_owner or not repo_name:
        return [
            OpsResult(
                False,
                "Cannot sync: [github] repo_owner/repo_name is not set in config.ini",
                "Set both under [github] in config.ini, then retry.",
            )
        ]

    results: list[OpsResult] = []
    with _github_actions_client(pat) as client:
        try:
            response = client.get(f"/repos/{repo_owner}/{repo_name}/actions/secrets/public-key")
            response.raise_for_status()
        except httpx.HTTPError as e:
            return [
                OpsResult(
                    False,
                    "Failed to fetch the repo's Actions secrets public key",
                    f"{e} -- check [github] pat has 'repo' (or 'actions:write') scope and "
                    f"[github] repo_owner/repo_name are correct.",
                )
            ]
        public_key_data = response.json()
        key_id = public_key_data["key_id"]
        public_key_b64 = public_key_data["key"]

        for full_key, value, actions_secret in targets:
            try:
                encrypted_value = _encrypt_for_actions_secret(public_key_b64, value)
                put_response = client.put(
                    f"/repos/{repo_owner}/{repo_name}/actions/secrets/{actions_secret}",
                    json={"encrypted_value": encrypted_value, "key_id": key_id},
                )
                put_response.raise_for_status()
            except httpx.HTTPError as e:
                results.append(
                    OpsResult(
                        False,
                        f"Failed to sync {full_key} -> Actions secret {actions_secret}",
                        f"{e} -- verify [github] pat has permission to manage Actions secrets "
                        f"on {repo_owner}/{repo_name}.",
                    )
                )
                continue
            results.append(OpsResult(True, f"Synced {full_key} -> Actions secret {actions_secret}"))

    return results


def secrets_sync(args) -> int:
    """CLI entrypoint for `nyxgpt ops secrets-sync`.

    Returns 0 if every mapped secret with a value synced successfully
    (or there was nothing to sync), else 2.
    """
    cfg_path = Path(args.config).expanduser() if getattr(args, "config", None) else None
    dry_run = bool(getattr(args, "dry_run", False))

    logger.info(
        "ops: secrets-sync starting (config=%s, dry_run=%s)",
        cfg_path,
        dry_run,
        extra={"component": "ops", "action": "secrets-sync"},
    )

    results = sync_secrets_to_github_actions(cfg_path=cfg_path, dry_run=dry_run)
    ok = _emit_results("secrets-sync", results)

    result, message = _ops_action_outcome(results)
    _record_ops_action("secrets-sync", "github-actions", result, message)

    logger.info(
        "ops: secrets-sync %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "secrets-sync", "ok": ok},
    )

    return 0 if ok else 2


# --- GlitchTip auto-provisioning (`nyxgpt ops glitchtip-init`) ---

# Fixed org/project names -- reused (not recreated) on every re-run, which is
# what makes this idempotent.
GLITCHTIP_ORG_SLUG = "nyxgpt"
GLITCHTIP_ORG_NAME = "nyxgpt"
GLITCHTIP_TEAM_SLUG = "nyxgpt"
GLITCHTIP_PROJECT_SLUG = "nyxgpt-backend"
GLITCHTIP_PROJECT_NAME = "nyxgpt-backend"
GLITCHTIP_TOKEN_NAME = "nyxgpt-ops-glitchtip-init"
# event:read lets Grafana's Infinity datasource (#3411) query issues/events
# via GlitchTip's Sentry-compatible REST API; team:read/team:write let
# `_glitchtip_ensure_team_membership` (#3565 round 6) confirm/add the
# provisioning admin to the canonical team -- without it, GlitchTip's
# `/organizations/{org}/members/me/teams/{team}/` join endpoint 403s.
GLITCHTIP_TOKEN_SCOPES = [
    "org:read",
    "org:write",
    "project:read",
    "project:write",
    "event:read",
    "team:read",
    "team:write",
]
GLITCHTIP_DEFAULT_ADMIN_EMAIL = "admin@nyxgpt.local"

# The `glitchtip` Compose service's network alias and container-internal port
# (docker-compose.yml: `PORT: 8080`, exposed as `8080:8080`) -- always 8080
# regardless of `GLITCHTIP_UI_PORT`, which only remaps the *host*-side port.
# Used to rewrite a DSN for containerized-api consumption; see
# `_containerized_error_tracking_dsn`.
GLITCHTIP_CONTAINER_HOST = "glitchtip"
GLITCHTIP_CONTAINER_PORT = 8080


def _glitchtip_grafana_token_path() -> Path:
    """Where the GlitchTip API token is written for Grafana's Infinity
    datasource to read (#3411) -- see
    docker/grafana/provisioning/datasources/glitchtip.yml's `$__file{}`
    reference and docs/docker-compose.md#grafana-single-pane-of-glass. Lives
    outside `~/.nyxGPT/volumes/grafana` (Grafana's own data dir) so it isn't
    swept by `nyxgpt ops down --volumes`, which deletes volume_dir()
    contents -- this is a credential, not app data.

    Computed fresh on every call (like `_provision_glitchtip`'s
    `native_cfg_path`), not a module-level constant, so tests can
    monkeypatch `Path.home`.
    """
    return Path.home() / ".nyxGPT" / "secrets" / "glitchtip-grafana-token"


def _glitchtip_secrets_dir_unwritable_result(path: Path) -> OpsResult:
    """Actionable failure for a `~/.nyxGPT/secrets` that exists but this
    process can't write to -- shared by the install preflight and the token
    writer itself so both report the same guidance (#3432)."""
    return OpsResult(
        False,
        f"{path} exists but is not writable by {getpass.getuser()!r}",
        f"On Linux, dockerd runs as root and auto-creates a missing Docker bind-mount "
        f"source directory as root:root the first time a container starts -- if "
        f"Grafana started before this directory existed, that's almost certainly what "
        f"happened here. Fix with: sudo chown -R $(whoami) {path} && chmod 755 {path}, "
        "then re-run `nyxgpt ops install` (or `nyxgpt ops glitchtip-init`).",
    )


# A non-empty, syntactically-harmless stand-in for the GlitchTip Infinity
# datasource bearer token, mirroring GRAFANA_SLACK_WEBHOOK_PLACEHOLDER_URL. Its
# only job is to make the datasource's `$__file{}` reference resolve to a
# non-empty value so Grafana boots; `ops glitchtip-init` overwrites it with the
# real token when GlitchTip is provisioned.
GRAFANA_GLITCHTIP_TOKEN_PLACEHOLDER = "UNCONFIGURED-glitchtip-token"


def _ensure_grafana_secret_placeholders() -> None:
    """Seed crash-safe placeholders for the secrets Grafana reads via `$__file{}`.

    Grafana 13.x hard-fails its *entire* startup (crash-loops, never serves) when
    a `$__file{}` datasource/contact-point secret references a file that is
    missing -- or, per #3538, present but empty. On a fresh `ops install` neither
    value exists yet: the GlitchTip Grafana token is minted later by
    `ops glitchtip-init`/`_provision_glitchtip` (which runs *after* the
    observability stack starts), and the Slack webhook file is only written when
    one is configured. So provisioning would reference two unresolved files and
    take Grafana down with it (observed on both the native and terraform smoke
    gates). Seed valid, non-empty placeholders here -- ahead of the observability
    bring-up, from `_ensure_glitchtip_secrets_dir` which both install paths run
    first -- so `$__file{}` always resolves: a placeholder GlitchTip token is an
    Infinity datasource that returns 401 until configured, and the placeholder
    Slack URL is a contact point that won't deliver -- both degrade gracefully
    instead of crashing Grafana. Only seeds when the file is absent, so a real
    token/URL is never clobbered; the real writers overwrite the placeholder when
    a value exists. Best-effort -- exceptions are swallowed so this never breaks
    the preflight it runs inside.
    """
    if not _slack_webhook_secret_path().exists():
        with contextlib.suppress(Exception):
            # Passing "" makes the writer store GRAFANA_SLACK_WEBHOOK_PLACEHOLDER_URL.
            _write_grafana_slack_webhook_secret("")
    if not _glitchtip_grafana_token_path().exists():
        with contextlib.suppress(Exception):
            _write_grafana_glitchtip_token(GRAFANA_GLITCHTIP_TOKEN_PLACEHOLDER)


def _ensure_glitchtip_secrets_dir() -> list[OpsResult]:
    """Ensure `~/.nyxGPT/secrets` exists and is writable by the invoking user
    *before* anything bind-mounts it (#3432).

    On Linux, dockerd runs as root and auto-creates a missing bind-mount
    source directory as root:root the first time a container starts. Since
    `docker-compose.yml` mounts this directory read-only into Grafana
    (`${HOME}/.nyxGPT/secrets:/etc/nyxgpt-secrets:ro`), if Grafana starts
    (via `_reconcile_grafana_provisioning`/`_start_observability_stack_terraform`)
    before this directory exists, Docker creates it root-owned and every
    later attempt by this (non-root) process to write the GlitchTip token
    into it -- `_write_grafana_glitchtip_token` -- fails with a raw
    `PermissionError`. Running this as an early install step, ahead of
    those, means Docker always finds the directory already present and
    never touches its ownership. macOS (Docker Desktop) doesn't hit this:
    its VM handles bind-mount ownership differently.

    Mode is `0o755`, not `0o700` (#3588): the official Grafana image runs
    as a fixed non-root uid (472) inside the container, and a native Linux
    bind mount exposes host files under their literal host uid/gid -- no
    user-namespace remapping -- so a `0o700` dir owned by the host user
    blocks Grafana's uid from even traversing into it to stat the token
    file it needs to read. `0o755` lets any uid traverse and read; only the
    owning host user can write, which is what actually needs protecting
    here (these are locally-scoped tokens for this machine's own GlitchTip/
    Grafana instances, not high-value secrets).

    Run as a best-effort preflight step (`install()` / `_install_terraform_steps`
    catch and log any exception a step raises), so it never needs to raise
    itself -- it just reports whether the directory is now usable.
    """
    path = _glitchtip_grafana_token_path().parent
    if not path.exists():
        try:
            path.mkdir(mode=0o755, parents=True, exist_ok=True)
        except OSError as e:
            return [OpsResult(False, f"Failed to create {path}", f"{type(e).__name__}: {e}")]
        _ensure_grafana_secret_placeholders()
        return [OpsResult(True, f"Created {path}")]

    if not os.access(path, os.W_OK | os.X_OK):
        return [_glitchtip_secrets_dir_unwritable_result(path)]

    # Owned-and-writable is what matters; a chmod that fails here is harmless.
    with contextlib.suppress(OSError):
        os.chmod(path, 0o755)
    _ensure_grafana_secret_placeholders()
    return [OpsResult(True, f"{path} exists and is writable")]


# The uid:gid each observability image runs its main process as, for the host
# directories docker-compose.yml bind-mounts into them. These are fixed in the
# upstream images (they are not configurable per-deployment): Prometheus drops
# to `nobody`, Grafana to its own `grafana` user in the root group, Loki to
# `loki`. Services whose entrypoint still starts as root and fixes up its own
# data directory (postgres/glitchtip) are deliberately absent -- they need the
# directory to *exist* (so dockerd doesn't create it) but not to be chowned.
OBSERVABILITY_VOLUME_OWNERS: dict[str, tuple[int, int]] = {
    "prometheus": (65534, 65534),
    "grafana": (472, 0),
    "loki": (10001, 10001),
}

# Every ~/.nyxGPT/volumes/* directory an observability container bind-mounts,
# whether or not it needs a chown -- all of them must exist before the stack
# starts so dockerd never auto-creates one as root:root.
OBSERVABILITY_VOLUME_DIRS: tuple[str, ...] = (
    "prometheus",
    "grafana",
    "loki",
    "glitchtip-postgres",
    "glitchtip-uploads",
)


def _dir_acl_grants_uid(path: Path, uid: int) -> bool:
    """True if `path` already carries an effective POSIX ACL granting `uid` rwx.

    Used both to keep `_ensure_observability_volume_dir` idempotent (don't
    re-run the grant on every `ops install`) and to keep `ops doctor` quiet
    about a directory that is reachable by its container through an ACL
    rather than through ownership. `getfacl -cn` prints numeric entries with
    no header; an entry the ACL mask has stripped down is annotated
    `#effective:`, so a line carrying that marker is *not* a grant.
    """
    getfacl = _which("getfacl")
    if getfacl is None:
        return False
    cp = _run([getfacl, "-cn", str(path)], check=False, expected=True)
    if cp.returncode != 0:
        return False
    return any(
        line.strip().startswith(f"user:{uid}:rwx") and "#effective" not in line
        for line in (cp.stdout or "").splitlines()
    )


def _grant_dir_acl_to_uid(path: Path, uid: int) -> bool:
    """Grant `uid` rwx on `path` (recursively) via a POSIX ACL, without root.

    `setfacl` only requires being the file's owner, so this is the one lever a
    non-root host user has to make a bind-mount source writable by a
    container's uid -- bind mounts expose host uids verbatim (no user
    namespace remapping), and the container's uid is neither ours nor in our
    group. Unlike a world-writable chmod it grants exactly one uid and leaves
    every other local user out, which matters because these directories hold
    real state (`grafana.db` carries sessions and hashed credentials).

    Recursive on purpose: a directory whose top level we own may still contain
    root-owned files from an earlier broken run. `setfacl -R` fails on those,
    which correctly drops the caller through to the actionable `sudo chown -R`
    message instead of reporting success on a container that would still
    crash-loop. Returns False when the acl(5) tools are absent or the
    filesystem was not mounted with ACL support.
    """
    setfacl = _which("setfacl")
    if setfacl is None:
        return False
    cp = _run([setfacl, "-R", "-m", f"u:{uid}:rwx", str(path)], check=False, expected=True)
    return cp.returncode == 0


def _ensure_observability_volume_dir(component: str) -> OpsResult:
    """Make one `~/.nyxGPT/volumes/<component>` directory usable by its container's uid."""
    path = volume_dir(component)  # creates it, owned by *this* user, if missing
    want = OBSERVABILITY_VOLUME_OWNERS.get(component)
    if want is None:
        return OpsResult(True, f"{path} exists")

    uid, gid = want
    try:
        st = path.stat()
    except OSError as e:
        return OpsResult(False, f"Failed to stat {path}", f"{type(e).__name__}: {e}")
    if st.st_uid == uid:
        return OpsResult(True, f"{path} is owned by the container's uid ({uid})")
    if _dir_acl_grants_uid(path, uid):
        # Already reconciled by this function's no-root fallback below; don't
        # re-run a sudo chown on every `ops install`.
        return OpsResult(True, f"{path} grants write access to the container's uid ({uid})")

    cp = _privileged_run(["chown", "-R", f"{uid}:{gid}", str(path)], expected=True)
    if cp is not None and cp.returncode == 0:
        return OpsResult(True, f"Set owner of {path} to {uid}:{gid} for its container")

    # No passwordless root. If we own the directory we can still hand exactly
    # this one uid write access with a POSIX ACL, which needs no root at all.
    if st.st_uid == os.getuid() and _grant_dir_acl_to_uid(path, uid):
        return OpsResult(True, f"Granted the container's uid ({uid}) write access to {path}")

    return OpsResult(
        False,
        f"{path} is owned by uid {st.st_uid} and cannot be made writable by its container",
        "dockerd runs as root and creates a missing bind-mount source directory as "
        "root:root, which then leaves the container's non-root uid unable to write "
        "(the container crash-loops as unhealthy). Neither passwordless sudo nor a "
        "POSIX ACL was available to reconcile it. Fix with:\n"
        f"  sudo chown -R {uid}:{gid} {path}\n"
        "then re-run `nyxgpt ops install`.",
    )


def _ensure_observability_volume_dirs() -> list[OpsResult]:
    """Pre-create every observability bind-mount directory with an ownership its
    container can actually write to (#3632).

    On Linux, dockerd (running as root) auto-creates a missing bind-mount
    source directory as `root:root` the first time the container starts.
    Prometheus then runs as uid 65534 inside the container, cannot write to
    `/prometheus`, panics, and crash-loops -- which is what surfaced as
    "dependency failed to start: container nyxgpt-prometheus-1 is unhealthy"
    and took the whole observability bring-up (and GlitchTip provisioning
    behind it) down with it. Grafana (uid 472) and Loki (uid 10001) sit on
    the same landmine.

    macOS never hits this -- Docker Desktop's VirtioFS/gRPC-FUSE sharing
    presents bind mounts as owned by whatever uid the container asks for --
    which is exactly why it went unnoticed until a plain Linux engine was
    exercised. Runs as an early best-effort install step (same shape as
    `_ensure_glitchtip_secrets_dir`, which fixed the sibling #3432 case for
    `~/.nyxGPT/secrets`), so it never raises.
    """
    if not _is_linux():
        return [OpsResult(True, "Not Linux; Docker Desktop handles bind-mount ownership")]
    return [_ensure_observability_volume_dir(c) for c in OBSERVABILITY_VOLUME_DIRS]


def _observability_volume_doctor_issues() -> list[str]:
    """`nyxgpt ops doctor` checks for the #3632 root-owned bind-mount directories."""
    if not _is_linux():
        return []
    issues: list[str] = []
    for component, (uid, gid) in OBSERVABILITY_VOLUME_OWNERS.items():
        path = Path.home() / ".nyxGPT" / "volumes" / VOLUME_DIR_NAMES[component]
        if not path.exists():
            continue
        try:
            st = path.stat()
        except OSError:
            continue
        # World-writable is not something install() produces any more, but a
        # machine reconciled by the first cut of this fix still carries it and
        # its container is genuinely fine -- don't nag about it.
        if st.st_uid == uid or bool(st.st_mode & 0o002) or _dir_acl_grants_uid(path, uid):
            continue
        issues.append(
            f"{path} is owned by uid {st.st_uid}, so the {component} container "
            f"(uid {uid}) cannot write to it and will crash-loop as unhealthy "
            f"(run: sudo chown -R {uid}:{gid} {path} && nyxgpt ops install)"
        )
    return issues


def _glitchtip_secrets_doctor_issues() -> list[str]:
    """`nyxgpt ops doctor` checks for the #3432 Linux bind-mount ownership
    failure mode: a `~/.nyxGPT/secrets` that exists but isn't writable by
    the current user (see `_ensure_glitchtip_secrets_dir`), and -- once the
    observability stack is actually up -- a missing GlitchTip token file,
    which leaves Grafana's GlitchTip datasource (glitchtip.yml) unable to
    authenticate even though Prometheus/Loki/Jaeger are fine.

    The second check only queries `_compose_stack_snapshot()` when Docker is
    on PATH, same guard `doctor()` already uses for the Cassandra container
    check -- avoids an unnecessary `docker compose ps` on a host without
    Docker at all.
    """
    issues: list[str] = []

    secrets_dir = _glitchtip_grafana_token_path().parent
    if secrets_dir.exists() and not os.access(secrets_dir, os.W_OK | os.X_OK):
        issues.append(
            f"{secrets_dir} exists but is not writable by {getpass.getuser()!r} "
            f"(run: sudo chown -R $(whoami) {secrets_dir} && nyxgpt ops install)"
        )

    if _which("docker") is not None and _compose_stack_snapshot().get("grafana") == "running":
        token_path = _glitchtip_grafana_token_path()
        if not token_path.exists():
            issues.append(
                f"Observability stack is up but {token_path} is missing -- Grafana's "
                "GlitchTip datasource can't authenticate (run: nyxgpt ops glitchtip-init)"
            )

    return issues


def _error_tracking_dsn_drift_issue(cfg_path: Path | None = None) -> str | None:
    """Detect the #3565 acceptance-failure shape: a configured error-tracking
    DSN whose public key no longer matches any live GlitchTip project key.

    sentry_sdk's HTTP transport is fire-and-forget, exactly like the OTLP
    span exporter `_tracing_wiring_issue` already guards against: when
    GlitchTip rejects an event (401, unrecognized key) the SDK just drops it
    -- nothing raises, nothing logs anywhere an operator would see, and
    `/api/error-tracking` keeps reporting `active: true` because that only
    reflects whether `sentry_sdk.init()` ran, not whether GlitchTip still
    accepts the key it was given. This happens whenever GlitchTip's
    org/project/key gets re-minted independently of `config.ini` (e.g. its
    Postgres data was reset out-of-band) -- `_provision_glitchtip` only
    restarts a *native* `nyxgpt-api` when it personally changes the DSN, so
    a drift introduced any other way is never detected until this check.

    Authenticates with the same ops-provisioned API token already written
    for Grafana's Infinity datasource (`_glitchtip_grafana_token_path`) --
    no extra credential to manage, and no check at all if that token, a
    configured DSN, or a reachable GlitchTip aren't all present, so this
    never blocks `doctor` on a host where error tracking isn't in play.
    """
    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return None

    parser = ConfigParser()
    try:
        parser.read(cfg_path)
    except Exception as e:
        logger.warning(
            "Failed to parse %s, skipping error tracking DSN drift check: %s",
            cfg_path,
            e,
            extra={"component": "ops"},
        )
        return None

    if not get_error_tracking_enabled(parser):
        return None

    error_tracking_config = get_error_tracking_config(parser)
    dsn = (error_tracking_config["dsn"] or "").strip()
    if not dsn:
        return None

    try:
        configured_key = httpx.URL(dsn).username
    except Exception:
        return None
    if not configured_key:
        return None

    token_path = _glitchtip_grafana_token_path()
    if not token_path.exists():
        return None
    try:
        token = token_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not token:
        return None

    base_url = error_tracking_config["glitchtip_ui_url"]
    try:
        with _glitchtip_http_client(
            base_url, headers={"Authorization": f"Bearer {token}"}
        ) as client:
            resp = client.get(
                f"/api/0/projects/{GLITCHTIP_ORG_SLUG}/{GLITCHTIP_PROJECT_SLUG}/keys/"
            )
    except httpx.HTTPError:
        return None
    if resp.status_code != 200:
        return None

    keys: Any = resp.json()
    if not isinstance(keys, list):
        return None
    live_public_keys = set()
    for key in keys:
        key_dsn = _extract_dsn(key)
        if not key_dsn:
            continue
        try:
            live_public_keys.add(httpx.URL(key_dsn).username)
        except Exception:
            continue

    if not live_public_keys or configured_key in live_public_keys:
        return None

    return (
        f"error_tracking DSN in {cfg_path} doesn't match any current GlitchTip key for "
        f"{GLITCHTIP_ORG_SLUG}/{GLITCHTIP_PROJECT_SLUG} -- every event is being rejected "
        "(401) and silently dropped, the same way an unreachable OTLP collector silently "
        "drops spans. The project's key was likely re-minted since this DSN was written. "
        "Fix: nyxgpt ops glitchtip-init && nyxgpt ops restart api."
    )


def _requirement_distribution_name(requirement: str) -> str:
    """Extract the distribution name from a PEP 508 requirement string.

    e.g. "opentelemetry-instrumentation-urllib>=0.45b0" ->
    "opentelemetry-instrumentation-urllib". Strips any environment marker
    (`; python_version ...`) and version specifier/extras.
    """
    without_marker = requirement.split(";", 1)[0].strip()
    match = re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]*", without_marker)
    return match.group(0) if match else without_marker


def _stale_venv_doctor_issues() -> list[str]:
    """`nyxgpt ops doctor` check for a Python venv that wasn't refreshed
    after a `git pull` added or bumped a declared dependency (#3487) -- the
    root cause behind a bare top-level import of a newly-added package (e.g.
    an OTel instrumentation) crashing every `nyxgpt` command with a raw
    `ModuleNotFoundError` instead of a targeted, actionable finding here.
    """
    pyproject_path = REPO_ROOT / "pyproject.toml"
    if not pyproject_path.exists():
        return []

    try:
        declared = tomllib.loads(pyproject_path.read_text())["project"]["dependencies"]
    except Exception as e:
        logger.warning(
            "Failed to parse %s for the stale-venv doctor check: %s",
            pyproject_path,
            e,
            extra={"component": "ops"},
        )
        return []

    missing = []
    for requirement in declared:
        name = _requirement_distribution_name(requirement)
        try:
            importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            missing.append(name)

    if not missing:
        return []

    return [
        "Installed environment is missing declared "
        f"dependenc{'y' if len(missing) == 1 else 'ies'}: {', '.join(sorted(missing))} "
        "-- your venv is likely stale after a pull (run: pip install -e .)"
    ]


def _glitchtip_container_healthy() -> bool:
    """Whether the `glitchtip` Compose container has actually passed its health check.

    Checks `health` directly rather than reusing `ComponentStatus.healthy`,
    which deliberately treats a "starting" container as healthy (see
    self_heal.py's start_period-grace comment) so the self-heal watchdog
    doesn't restart something mid-boot -- the right call there, but the wrong
    one here: a container freshly (re)started reports `state=running,
    health=starting` for its whole healthcheck `start_period`, so a caller
    waiting to know the container is *actually* ready (not just "not yet
    proven broken") needs `health == "healthy"`, or this returns as soon as
    the container exists (#3588's grafana mirror of this same bug).
    """
    for status in self_heal.list_component_status():
        if status.service == "glitchtip":
            return status.state == "running" and status.health in ("", "healthy")
    return False


def _wait_for_glitchtip_healthy(timeout: float = 120.0, poll_interval: float = 3.0) -> bool:
    """Poll until the `glitchtip` container reports healthy, or `timeout` elapses.

    Returns False immediately (no polling) if the container isn't part of the
    currently running Compose stack at all -- e.g. `--skip-observability` was
    used, Docker isn't installed, or `error_tracking` is enabled in config but
    the container was torn down (`state == "absent"`, reported by self_heal's
    desired-state reconciliation) -- so a host with no GlitchTip never stalls
    `nyxgpt ops install`, and a standalone `nyxgpt ops glitchtip-init` run
    against a torn-down stack fails fast instead of polling out the full
    `timeout` for a container nothing in this call path starts. Otherwise
    waits out its health-check `start_period` (see docker-compose.yml), since
    a container freshly started by `_start_observability_stack` is not
    immediately reachable.
    """
    statuses = [s for s in self_heal.list_component_status() if s.service == "glitchtip"]
    if not statuses or statuses[0].state == "absent":
        return False
    if statuses[0].state == "running" and statuses[0].health in ("", "healthy"):
        return True

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        time.sleep(poll_interval)
        if _glitchtip_container_healthy():
            return True
    return False


def _resolve_admin_credentials(cfg_path: Path) -> tuple[str, str, bool]:
    """Return `(email, password, generated)` for the GlitchTip admin user.

    Reads `[error_tracking] admin_email`/`admin_password` from `cfg_path` if
    already set; generates a strong password when none is configured. Does
    not write anything -- see `_persist_admin_credentials`.
    """
    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(cfg_path)

    email = parser.get("error_tracking", "admin_email", fallback="").strip()
    email = email or GLITCHTIP_DEFAULT_ADMIN_EMAIL
    password = parser.get("error_tracking", "admin_password", fallback="").strip()
    generated = not password
    if generated:
        password = secrets.token_urlsafe(24)
    return email, password, generated


def _persist_admin_credentials(cfg_path: Path, email: str, password: str) -> None:
    """Write the (possibly generated) admin email/password back to `cfg_path`.

    Same trust model as `[auth] api_key`: GlitchTip is loopback-only, so this
    is acceptable to store in config.ini chmod 600 -- see docs/self-healing.md.
    Only ever called with the native `~/.nyxGPT/config.ini` path, never the
    derived `docker/config.docker.ini`.
    """
    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(cfg_path)
    if not parser.has_section("error_tracking"):
        parser.add_section("error_tracking")
    parser.set("error_tracking", "admin_email", email)
    parser.set("error_tracking", "admin_password", password)

    with cfg_path.open("w", encoding="utf-8") as f:
        parser.write(f)
    os.chmod(cfg_path, 0o600)


def _glitchtip_ensure_superuser(email: str, password: str) -> OpsResult:
    """Idempotently ensure a GlitchTip superuser exists via Django's `createsuperuser --noinput`.

    Non-interactive: credentials are passed as the `DJANGO_SUPERUSER_*`
    environment variables Django's own `createsuperuser` management command
    reads directly, so this never blocks on a TTY prompt. `--noinput` exits
    rc=1 by design if the account already exists -- declared to `_run` as an
    expected returncode so a healthy re-run of `glitchtip-init` logs at INFO
    instead of a scary WARNING (#3574), while still treating it as success
    so re-running after the first successful run is a no-op.

    The password never touches argv (CodeQL #105/#106,
    py/clear-text-logging-sensitive-data): bare `-e VAR` flags make
    `docker compose exec` forward each variable's value from this process's
    environment (passed via `_run(env=...)`) into the container, so
    `_run`'s non-zero-exit logging -- which fires at INFO on every
    idempotent rc=1 re-run -- only ever sees the variable NAMES. The old
    `-e NAME=value` argv form slipped past `_redact_cmd`'s dash-prefixed
    flag masking and put the real password in the log `extra` on every
    re-run.
    """
    cmd = [
        "docker",
        "compose",
        "-f",
        str(self_heal.COMPOSE_FILE),
        "exec",
        "-T",
        "-e",
        "DJANGO_SUPERUSER_EMAIL",
        "-e",
        "DJANGO_SUPERUSER_PASSWORD",
        "-e",
        "DJANGO_SUPERUSER_USERNAME",
        "glitchtip",
        "./manage.py",
        "createsuperuser",
        "--noinput",
    ]
    try:
        cp = _run(
            cmd,
            check=False,
            expected_returncodes={1},
            expected_message=(
                f"GlitchTip superuser {email} already exists -- expected rc=1, "
                "treated as success"
            ),
            env={
                **os.environ,
                "DJANGO_SUPERUSER_EMAIL": email,
                "DJANGO_SUPERUSER_PASSWORD": password,
                "DJANGO_SUPERUSER_USERNAME": email,
            },
        )
    except Exception as e:
        return OpsResult(
            False, "Failed to run GlitchTip createsuperuser", f"{type(e).__name__}: {e}"
        )

    if cp.returncode == 0:
        return OpsResult(True, f"Created GlitchTip admin user {email}")

    combined = ((cp.stdout or "") + (cp.stderr or "")).lower()
    if "already" in combined or "unique" in combined:
        return OpsResult(True, f"GlitchTip admin user {email} already exists")

    details = _output_excerpt(cp)
    return OpsResult(False, "Failed to ensure GlitchTip admin user", details.strip())


def _glitchtip_http_client(base_url: str, **kwargs: Any) -> httpx.Client:
    """Construct an `httpx.Client` against GlitchTip's base URL.

    A thin wrapper purely so tests can monkeypatch it to inject an
    `httpx.MockTransport` instead of hitting a real network socket.
    """
    return httpx.Client(base_url=base_url, timeout=10.0, **kwargs)


def _glitchtip_login(
    base_url: str, email: str, password: str
) -> tuple[httpx.Client | None, OpsResult]:
    """Log into GlitchTip as `email`/`password`, returning an authenticated client.

    Modern GlitchTip (>= 5.x, verified on 6.2.0) serves django-allauth's
    headless browser API: `GET /_allauth/browser/v1/config` primes the
    `csrftoken` cookie, which is echoed back as `X-CSRFToken` on the login
    POST; the resulting session cookie carries auth forward for
    `_glitchtip_ensure_api_token` to mint a bearer token from. Older
    releases used a plain Django/DRF session view at `/api/auth/login/` --
    if the headless route 404s, this falls back to that legacy flow so the
    provisioning works across image pins.
    """

    def _csrf_headers(client: httpx.Client) -> dict[str, str]:
        headers = {"Referer": base_url}
        csrf_token = client.cookies.get("csrftoken", "")
        if csrf_token:
            headers["X-CSRFToken"] = csrf_token
        return headers

    client = _glitchtip_http_client(base_url, follow_redirects=True)
    try:
        client.get("/_allauth/browser/v1/config")
        resp = client.post(
            "/_allauth/browser/v1/auth/login",
            json={"email": email, "password": password},
            headers=_csrf_headers(client),
        )
        if resp.status_code == 404:
            client.get("/api/auth/login/")
            resp = client.post(
                "/api/auth/login/",
                json={"email": email, "password": password},
                headers=_csrf_headers(client),
            )
        if resp.status_code >= 400:
            client.close()
            return None, OpsResult(
                False,
                "Failed to authenticate to GlitchTip",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        return client, OpsResult(True, "Authenticated to GlitchTip")
    except httpx.HTTPError as e:
        client.close()
        return None, OpsResult(False, "Failed to reach GlitchTip API", f"{type(e).__name__}: {e}")


def _glitchtip_ensure_api_token(
    client: httpx.Client, base_url: str
) -> tuple[str | None, OpsResult]:
    """Mint (or reuse) a scoped GlitchTip API token for `nyxgpt ops` automation.

    Uses the authenticated session from `_glitchtip_login` for this one call
    (token creation is CSRF-guarded like any other POST); every call after
    this switches to `Authorization: Bearer <token>`.

    GlitchTip's `APIToken` model field (and the `api-tokens/` response) is
    `label`, not `name` -- posting `name` (as this function did through
    #3565 round 5) silently drops on the floor (`APITokenIn`'s schema only
    accepts `label`/`scopes`), so every token is created with `label: ""`.
    The very next run's reuse lookup then matches on `tok.get("name")`,
    which is *never* present in the response, so it can never find a match
    either -- every `glitchtip-init`/`install`/`env-sync` run minted a brand
    new orphaned token, silently defeating the "idempotent" contract
    (verified live: booted a real GlitchTip 6.2.0 instance, ran the
    pre-fix code twice, got two distinct tokens both labeled ""). Posting
    `label` and reusing by `label` fixes both sides of that bug.

    A reused token whose stored `scopes` don't cover every scope in
    `GLITCHTIP_TOKEN_SCOPES` (e.g. an older token from before a scope was
    added here) is deleted and re-minted -- GlitchTip's API has no token
    PUT/PATCH, only create/delete, so upgrading scopes means replacing it.
    """
    try:
        csrf_token = client.cookies.get("csrftoken", "")
        headers = {"Referer": base_url}
        if csrf_token:
            headers["X-CSRFToken"] = csrf_token

        listing = client.get("/api/0/api-tokens/")
        if listing.status_code == 200:
            existing: Any = listing.json()
            if isinstance(existing, list):
                for tok in existing:
                    if not isinstance(tok, dict):
                        continue
                    if tok.get("label") != GLITCHTIP_TOKEN_NAME or not tok.get("token"):
                        continue
                    if set(GLITCHTIP_TOKEN_SCOPES) <= set(tok.get("scopes") or []):
                        return str(tok["token"]), OpsResult(
                            True, "Reusing existing GlitchTip API token"
                        )
                    token_id = tok.get("id")
                    if token_id is not None:
                        client.delete(f"/api/0/api-tokens/{token_id}/", headers=headers)
                    break

        resp = client.post(
            "/api/0/api-tokens/",
            json={"label": GLITCHTIP_TOKEN_NAME, "scopes": GLITCHTIP_TOKEN_SCOPES},
            headers=headers,
        )
        if resp.status_code not in (200, 201):
            return None, OpsResult(
                False,
                "Failed to create GlitchTip API token",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        data: Any = resp.json()
        token = None
        if isinstance(data, dict):
            token = data.get("token") or data.get("key")
        if not token:
            return None, OpsResult(
                False, "GlitchTip API token response missing a token", str(data)[:500]
            )
        return str(token), OpsResult(True, "Created GlitchTip API token")
    except httpx.HTTPError as e:
        return None, OpsResult(
            False, "Failed to create GlitchTip API token", f"{type(e).__name__}: {e}"
        )


def _glitchtip_ensure_organization(client: httpx.Client) -> tuple[str | None, OpsResult]:
    """Ensure the `nyxgpt` GlitchTip organization exists, returning its slug."""
    try:
        listing = client.get("/api/0/organizations/")
        if listing.status_code == 200:
            existing: Any = listing.json()
            if isinstance(existing, list):
                for org in existing:
                    if isinstance(org, dict) and org.get("slug") == GLITCHTIP_ORG_SLUG:
                        return GLITCHTIP_ORG_SLUG, OpsResult(
                            True, f"Using existing GlitchTip organization {GLITCHTIP_ORG_SLUG}"
                        )

        resp = client.post("/api/0/organizations/", json={"name": GLITCHTIP_ORG_NAME})
        if resp.status_code not in (200, 201):
            return None, OpsResult(
                False,
                "Failed to create GlitchTip organization",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        data: Any = resp.json()
        slug = (
            str(data.get("slug", GLITCHTIP_ORG_SLUG))
            if isinstance(data, dict)
            else GLITCHTIP_ORG_SLUG
        )
        return slug, OpsResult(True, f"Created GlitchTip organization {slug}")
    except httpx.HTTPError as e:
        return None, OpsResult(
            False, "Failed to ensure GlitchTip organization", f"{type(e).__name__}: {e}"
        )


def _glitchtip_ensure_team(client: httpx.Client, org_slug: str) -> tuple[str | None, OpsResult]:
    """Ensure the `nyxgpt` GlitchTip team exists under `org_slug`, returning its slug.

    Modern GlitchTip (verified on 6.2.0) only creates projects under a team
    (the org-level projects route is list-only), so provisioning needs a team
    before `_glitchtip_ensure_project` can create anything.
    """
    try:
        listing = client.get(f"/api/0/organizations/{org_slug}/teams/")
        if listing.status_code == 200:
            existing: Any = listing.json()
            if isinstance(existing, list):
                for team in existing:
                    if isinstance(team, dict) and team.get("slug") == GLITCHTIP_TEAM_SLUG:
                        return GLITCHTIP_TEAM_SLUG, OpsResult(
                            True, f"Using existing GlitchTip team {GLITCHTIP_TEAM_SLUG}"
                        )

        resp = client.post(
            f"/api/0/organizations/{org_slug}/teams/",
            json={"slug": GLITCHTIP_TEAM_SLUG},
        )
        if resp.status_code not in (200, 201):
            return None, OpsResult(
                False,
                "Failed to create GlitchTip team",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        data: Any = resp.json()
        slug = (
            str(data.get("slug", GLITCHTIP_TEAM_SLUG))
            if isinstance(data, dict)
            else GLITCHTIP_TEAM_SLUG
        )
        return slug, OpsResult(True, f"Created GlitchTip team {slug}")
    except httpx.HTTPError as e:
        return None, OpsResult(False, "Failed to ensure GlitchTip team", f"{type(e).__name__}: {e}")


def _glitchtip_ensure_team_membership(
    client: httpx.Client, org_slug: str, team_slug: str
) -> OpsResult:
    """Ensure the provisioning admin is a member of `team_slug`, idempotently.

    GlitchTip's UI only lists projects on teams the logged-in user belongs
    to -- a superuser who is an org member but not on any team still sees
    "This organization has no projects" (#3565 round 5 acceptance failure,
    live-diagnosed by the owner via Django admin). `_glitchtip_ensure_team`
    creating a brand-new team already adds the requesting user (verified by
    reading GlitchTip's `create_team` view: it `team.members.aadd()`s the
    creator's `OrganizationUser`), so this only actually does work the first
    time a *pre-existing* team is reused by a different/new admin. It's
    cheap and idempotent (`team.members.aadd()` is a no-op if already a
    member) so it's called unconditionally rather than trying to detect
    which case applies.

    Uses the join endpoint's `me` alias
    (`POST /organizations/{org}/members/me/teams/{team}/`) rather than
    looking up a member id, and requires the `team:write` scope on the
    client's token (see `GLITCHTIP_TOKEN_SCOPES`) -- without it this 403s.
    """
    try:
        resp = client.post(f"/api/0/organizations/{org_slug}/members/me/teams/{team_slug}/")
        if resp.status_code in (200, 201):
            return OpsResult(True, f"Confirmed GlitchTip team membership on {team_slug}")
        return OpsResult(
            False,
            "Failed to confirm GlitchTip team membership",
            f"HTTP {resp.status_code}: {resp.text[:500]}",
        )
    except httpx.HTTPError as e:
        return OpsResult(
            False, "Failed to confirm GlitchTip team membership", f"{type(e).__name__}: {e}"
        )


def _glitchtip_ensure_project(
    client: httpx.Client, org_slug: str, team_slug: str
) -> tuple[str | None, OpsResult]:
    """Ensure the `nyxgpt-backend` GlitchTip project exists under `org_slug`, returning its slug.

    Creates via the team-scoped route (`/api/0/teams/{org}/{team}/projects/`),
    the only creation path modern GlitchTip serves; falls back to the legacy
    org-level POST if the team route is absent on an older image.
    """
    try:
        listing = client.get(f"/api/0/organizations/{org_slug}/projects/")
        if listing.status_code == 200:
            existing: Any = listing.json()
            if isinstance(existing, list):
                for proj in existing:
                    if isinstance(proj, dict) and proj.get("slug") == GLITCHTIP_PROJECT_SLUG:
                        return GLITCHTIP_PROJECT_SLUG, OpsResult(
                            True, f"Using existing GlitchTip project {GLITCHTIP_PROJECT_SLUG}"
                        )

        resp = client.post(
            f"/api/0/teams/{org_slug}/{team_slug}/projects/",
            json={"name": GLITCHTIP_PROJECT_NAME, "platform": "python"},
        )
        if resp.status_code in (404, 405):
            resp = client.post(
                f"/api/0/organizations/{org_slug}/projects/",
                json={"name": GLITCHTIP_PROJECT_NAME, "platform": "python"},
            )
        if resp.status_code not in (200, 201):
            return None, OpsResult(
                False,
                "Failed to create GlitchTip project",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        data: Any = resp.json()
        slug = (
            str(data.get("slug", GLITCHTIP_PROJECT_SLUG))
            if isinstance(data, dict)
            else GLITCHTIP_PROJECT_SLUG
        )
        return slug, OpsResult(True, f"Created GlitchTip project {slug}")
    except httpx.HTTPError as e:
        return None, OpsResult(
            False, "Failed to ensure GlitchTip project", f"{type(e).__name__}: {e}"
        )


def _extract_dsn(key: Any) -> str:
    """Pull the public DSN out of a GlitchTip ProjectKey response, tolerating shape variants."""
    if not isinstance(key, dict):
        return ""
    dsn_field = key.get("dsn")
    if isinstance(dsn_field, dict):
        return str(dsn_field.get("public") or "")
    if isinstance(dsn_field, str):
        return dsn_field
    return ""


def _glitchtip_ensure_project_key(
    client: httpx.Client, org_slug: str, project_slug: str
) -> tuple[str | None, OpsResult]:
    """Ensure a GlitchTip project key exists for `org_slug`/`project_slug`, returning its DSN."""
    try:
        listing = client.get(f"/api/0/projects/{org_slug}/{project_slug}/keys/")
        if listing.status_code == 200:
            existing: Any = listing.json()
            if isinstance(existing, list):
                for key in existing:
                    dsn = _extract_dsn(key)
                    if dsn:
                        return dsn, OpsResult(True, "Using existing GlitchTip project key")

        resp = client.post(
            f"/api/0/projects/{org_slug}/{project_slug}/keys/", json={"name": "nyxgpt"}
        )
        if resp.status_code not in (200, 201):
            return None, OpsResult(
                False,
                "Failed to create GlitchTip project key",
                f"HTTP {resp.status_code}: {resp.text[:500]}",
            )
        data: Any = resp.json()
        dsn = _extract_dsn(data)
        if not dsn:
            return None, OpsResult(
                False, "GlitchTip project key response missing a DSN", str(data)[:500]
            )
        return dsn, OpsResult(True, "Created GlitchTip project key")
    except httpx.HTTPError as e:
        return None, OpsResult(
            False, "Failed to ensure GlitchTip project key", f"{type(e).__name__}: {e}"
        )


def _patch_ini_value(text: str, section: str, key: str, value: str) -> str:
    """Return `text` with `key = value` set inside `[section]`, preserving
    every other line -- including comments -- verbatim.

    Unlike a `ConfigParser` read/write round-trip (which drops comments),
    this only ever rewrites the single matching `key = ...` line, or
    appends one if the key/section isn't present yet. Used for
    `docker/config.docker.ini`, whose `[error_tracking]` section carries
    hand-written documentation comments (seeded from its tracked `.example`
    template) that must survive `nyxgpt ops glitchtip-init` re-runs.
    """
    lines = text.splitlines(keepends=True)
    section_header_re = re.compile(r"^\s*\[([^\]]+)\]\s*$")
    key_re = re.compile(rf"^(\s*){re.escape(key)}(\s*=\s*).*$")

    section_start: int | None = None
    section_end = len(lines)
    for i, line in enumerate(lines):
        m = section_header_re.match(line)
        if m:
            if section_start is not None:
                section_end = i
                break
            if m.group(1) == section:
                section_start = i

    if section_start is None:
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        if lines and lines[-1].strip():
            lines.append("\n")
        lines.append(f"[{section}]\n")
        lines.append(f"{key} = {value}\n")
        return "".join(lines)

    for i in range(section_start + 1, section_end):
        if key_re.match(lines[i]):
            lines[i] = f"{key} = {value}\n"
            return "".join(lines)

    lines.insert(section_end, f"{key} = {value}\n")
    return "".join(lines)


def _containerized_error_tracking_dsn(dsn: str) -> str:
    """Rewrite a GlitchTip DSN's host:port for a containerized api to use.

    GlitchTip mints DSNs from its own `GLITCHTIP_DOMAIN` env var
    (`http://localhost:${GLITCHTIP_UI_PORT}` -- see docker-compose.yml's
    `glitchtip` service), because that's what a browser opening an issue link
    needs. But a *containerized* api (Compose `--profile errors` or
    `terraform ... --local`, both consuming `docker/config.docker.ini`) reads
    that same DSN to send events server-side -- inside the container network,
    `localhost` resolves to the api container itself, not the docker host.
    `sentry_sdk`'s HTTP transport is fire-and-forget, so the connection
    failure is silently swallowed: `capture_exception` returns normally and
    nothing ever reaches GlitchTip (#3565 round 5 -- confirmed live: the
    error-tracking endpoint reported 202 while GlitchTip received nothing).

    Points the DSN at the `glitchtip` service's network alias and
    container-internal port instead, which every containerized deploy mode
    shares a docker network with (`_COMPOSE_CONFIG_OVERRIDES` makes the same
    assumption for `ollama`/`cassandra`). Falls back to returning `dsn`
    unchanged if it doesn't parse as a URL with a host.
    """
    try:
        url = httpx.URL(dsn)
    except Exception:
        return dsn
    if not url.host:
        return dsn
    return str(url.copy_with(host=GLITCHTIP_CONTAINER_HOST, port=GLITCHTIP_CONTAINER_PORT))


def _current_error_tracking_dsn(cfg_path: Path) -> str:
    """Return the `[error_tracking] dsn` currently in `cfg_path`, or `""` if
    the file/section/key is absent -- used by `_provision_glitchtip` to
    detect a DSN change (re-minted project/key) before `nyxgpt-api` has
    reloaded it, see `_restart_native_api_if_running`."""
    if not cfg_path.exists():
        return ""
    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(cfg_path)
    return parser.get("error_tracking", "dsn", fallback="").strip()


def _write_error_tracking_dsn(cfg_path: Path, dsn: str, *, chmod_600: bool) -> OpsResult:
    """Write the provisioned DSN and `enabled = true` into `[error_tracking]` in `cfg_path`.

    No-ops (reports ok) if `cfg_path` doesn't exist -- not every host has
    both `~/.nyxGPT/config.ini` (native) and `docker/config.docker.ini`
    (Compose) in play. `chmod_600` should only be set for the native path:
    the live `docker/config.docker.ini` is a derived, git-ignored artifact
    seeded from a tracked template, not a secrets file -- the DSN is a public
    key, safe to store there (see docs/self-healing.md) -- so its permissions
    are left untouched.

    Patches only the `dsn`/`enabled` lines in place (via `_patch_ini_value`)
    rather than round-tripping through `ConfigParser`, so any comments in
    `cfg_path` -- notably the documentation comments in
    `docker/config.docker.ini` -- survive untouched.
    """
    if not cfg_path.exists():
        return OpsResult(True, f"Skipped {cfg_path} (not present)")

    text = cfg_path.read_text(encoding="utf-8")
    text = _patch_ini_value(text, "error_tracking", "dsn", dsn)
    text = _patch_ini_value(text, "error_tracking", "enabled", "true")
    cfg_path.write_text(text, encoding="utf-8")

    if chmod_600:
        os.chmod(cfg_path, 0o600)

    return OpsResult(True, f"Wrote GlitchTip DSN into {cfg_path}")


def _write_grafana_glitchtip_token(token: str) -> tuple[bool, OpsResult]:
    """Write `token` to `_glitchtip_grafana_token_path()` for Grafana's Infinity datasource.

    Returns `(changed, result)` -- `changed` is False when the file already
    holds this exact token, which callers use to skip an unnecessary Grafana
    restart (Grafana only re-reads provisioning files, including `$__file{}`
    targets, at startup).

    `_ensure_glitchtip_secrets_dir` runs earlier in `install()`/
    `_install_terraform_steps` specifically so this doesn't hit a
    root-owned bind-mount directory (#3432), but this still guards the
    write with its own try/except -- e.g. a standalone `nyxgpt ops
    glitchtip-init` run skips that preflight -- so a permission problem
    surfaces as this actionable `OpsResult` instead of an uncaught
    `PermissionError` traceback bubbling up through `_provision_glitchtip`.

    File mode is `0o644`, not `0o600` (#3588): Grafana's official image
    runs as non-root uid 472, and a native Linux bind mount preserves host
    uid/gid checks (no user-namespace remap), so a `0o600` file owned by
    the host user is unreadable by Grafana's container process -- Grafana
    fails to boot with a `stat ...: permission denied` on its GlitchTip
    datasource provisioning. `0o644` keeps write access restricted to the
    owning host user while letting any uid read it, matching the parent
    directory's `0o755` in `_ensure_glitchtip_secrets_dir`.
    """
    path = _glitchtip_grafana_token_path()
    try:
        if path.exists() and path.read_text(encoding="utf-8").strip() == token:
            return False, OpsResult(True, f"{path} already holds the current GlitchTip token")

        path.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        path.write_text(token, encoding="utf-8")
        os.chmod(path, 0o644)
    except OSError as e:
        result = _glitchtip_secrets_dir_unwritable_result(path.parent)
        return False, OpsResult(
            False,
            f"Cannot write GlitchTip token to {path}",
            f"{result.details}\n{type(e).__name__}: {e}",
        )
    return True, OpsResult(True, f"Wrote GlitchTip API token for Grafana to {path}")


def _grafana_container_healthy() -> bool:
    """Whether the `grafana` Compose container has actually passed its health check.

    Checks `health` directly rather than reusing `ComponentStatus.healthy`
    -- see `_glitchtip_container_healthy`'s docstring for why that flag's
    "starting counts as healthy" semantics (correct for the self-heal
    watchdog) are wrong for this caller. This was the actual cause of the
    `terraform-local-smoke` CI race (#3588 review round 2): right after
    `docker compose restart grafana`, `_wait_for_grafana_healthy` polled
    `ComponentStatus.healthy`, which was already `True` while the container
    was still in its healthcheck `start_period` (`state=running,
    health=starting`) -- so the restart was reported done and the install
    command returned before Grafana was actually reachable, and the smoke
    test's immediate curl hit connection-refused.
    """
    for status in self_heal.list_component_status():
        if status.service == "grafana":
            return status.state == "running" and status.health in ("", "healthy")
    return False


def _wait_for_grafana_healthy(timeout: float = 120.0, poll_interval: float = 3.0) -> bool:
    """Poll until the `grafana` container reports healthy, or `timeout` elapses.

    Mirrors `_wait_for_glitchtip_healthy` (#3432): returns False immediately
    (no polling) if `grafana` isn't part of the currently running Compose
    stack at all, so a host without the observability stack never stalls.
    Otherwise waits out Grafana's healthcheck `start_period` (see
    docker-compose.yml's `grafana` service) since a container just
    (re)started is not immediately reachable -- and, critically, a container
    stuck crash-looping (#3538, e.g. an alerting-provisioning file Grafana
    can't validate) never reports healthy, so this returns False instead of
    hanging forever, letting callers surface that as an actionable failure
    instead of reporting a restart as OK when Grafana never actually comes
    back up.
    """
    statuses = [s for s in self_heal.list_component_status() if s.service == "grafana"]
    if not statuses or statuses[0].state == "absent":
        return False
    if statuses[0].state == "running" and statuses[0].health in ("", "healthy"):
        return True

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        time.sleep(poll_interval)
        if _grafana_container_healthy():
            return True
    return False


def _restart_grafana_if_running(reason: str = "the new GlitchTip token") -> OpsResult:
    """Restart the `grafana` Compose container if its container exists.

    Grafana only reads `$__file{}` provisioning targets (the GlitchTip
    Infinity token, see `_write_grafana_glitchtip_token`, and the Slack
    alerting webhook, see `_write_grafana_slack_webhook_secret`) at startup,
    so a freshly (re)written secret needs this to actually take effect.

    Only skips when the container is entirely `"absent"` (no container to
    restart at all, e.g. the observability profile was never started) --
    NOT merely non-`"running"`. On a from-scratch install, Grafana's
    GlitchTip-Infinity datasource provisioning fails and crash-loops
    (`state="exited"`) before `_provision_glitchtip` has written the token
    this restart exists to deliver; skipping on anything but "running" left
    it dead for good instead of bringing it back (#3588's `terraform-local-
    smoke` regression). `docker compose restart` covers both a running and
    an already-stopped container -- there's no need to branch to `up -d`.

    Waits for Grafana to report healthy again before returning (#3538) --
    without this, a restart that leaves Grafana crash-looping (e.g. a broken
    alerting-provisioning file) was previously reported as a plain "OK,
    restarted", with the crash loop only surfacing later, misleadingly, as
    an unrelated-looking credential-verify failure.
    """
    if not _compose_available():
        return OpsResult(True, "Skipped Grafana restart (Docker not found)")

    running = _compose_stack_snapshot()
    if running.get("grafana", "absent") == "absent":
        return OpsResult(True, "Skipped Grafana restart (not running)")

    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE), "restart", "grafana"]
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return OpsResult(False, "Failed to restart Grafana", _output_excerpt(cp))

    if not _wait_for_grafana_healthy():
        return OpsResult(
            False,
            f"Restarted Grafana to pick up {reason}, but it never became healthy again",
            "Check `nyxgpt ops status` (a compose service stuck `restarting` is the tell) "
            "and `nyxgpt ops logs grafana` for the boot error.",
        )
    return OpsResult(True, f"Restarted Grafana to pick up {reason}")


def _restart_native_api_if_running(reason: str = "the new GlitchTip DSN") -> OpsResult:
    """Restart the native `nyxgpt-api` Homebrew service if it's currently running.

    The API's error-tracking SDK reads `[error_tracking] dsn` from
    `~/.nyxGPT/config.ini` once, at process startup -- it does not hot-reload
    config.ini. If `_provision_glitchtip` re-mints the GlitchTip project/key
    (e.g. after a `down`+`install` cycle against a fresh GlitchTip database)
    the DSN written to config.ini changes, but a running `nyxgpt-api` keeps
    reporting to the *old* DSN until restarted -- silently dropping every
    event from then on. Mirrors `_restart_grafana_if_running` for the
    Grafana Infinity token. No-ops (not a failure) when `nyxgpt-api` isn't
    running as a native brew service -- a Compose-deployed `nyxgpt-api`
    reads its DSN from `docker/config.docker.ini` fresh on each container
    start and restarts through `nyxgpt ops restart api` like any other
    Compose service.
    """
    if _brew_services_snapshot().get("nyxgpt-api") not in ("started", "running"):
        return OpsResult(True, "Skipped nyxgpt-api restart (not running natively)")

    result = _restart_brew_service("nyxgpt-api")[0]
    if not result.ok:
        return result
    return OpsResult(True, f"Restarted nyxgpt-api to pick up {reason}")


def _slack_webhook_secret_path() -> Path:
    """Where the Slack incoming-webhook URL is written for Grafana's alerting
    contact point to read (#3466) -- see
    docker/grafana/provisioning/alerting/contact-points.yml's `$__file{}`
    reference. Lives in the same `~/.nyxGPT/secrets` directory as the
    GlitchTip Grafana token (`_glitchtip_grafana_token_path`), so the
    existing `_ensure_glitchtip_secrets_dir` preflight (#3432) already
    guards this write against the root-owned bind-mount directory failure
    mode too.

    Computed fresh on every call, not a module-level constant, so tests can
    monkeypatch `Path.home`.
    """
    return Path.home() / ".nyxGPT" / "secrets" / "slack-webhook-url"


# Written to the secret file in place of an empty string when [monitoring]
# slack_webhook_url is unset (#3538). Grafana's alerting-provisioning
# validator requires a Slack integration to have a non-empty url/token/
# recipient -- an empty url doesn't mean "configured but broken", it fails
# validation identically to a missing one and crash-loops the whole Grafana
# container. This placeholder is syntactically a well-formed Slack webhook
# URL (satisfies validation, so Grafana boots) but not a real one -- delivery
# to it fails at send time, visible under Alerting -> Contact points -> Test,
# which is the "alerts still fire, Slack delivery silently fails" behavior
# #3466 actually intended.
GRAFANA_SLACK_WEBHOOK_PLACEHOLDER_URL = (
    "https://hooks.slack.com/services/UNCONFIGURED/UNCONFIGURED/UNCONFIGURED"
)


def _write_grafana_slack_webhook_secret(url: str) -> tuple[bool, OpsResult]:
    """Write `url` to `_slack_webhook_secret_path()` for Grafana's
    `nyxgpt-slack` contact point -- `GRAFANA_SLACK_WEBHOOK_PLACEHOLDER_URL`
    when `url` is empty/unset.

    Never writes an empty string, even though `url` may be `""` -- the
    contact point's `$__file{}` reference must resolve to a non-empty,
    syntactically-valid webhook URL at Grafana startup, or Grafana's
    alerting-provisioning validator refuses to boot the container entirely
    (#3538: confirmed by booting grafana/grafana:13.1.1 against this exact
    provisioning with an empty secret file -- it crash-loops, it does not
    degrade to "Slack delivery fails silently" as originally intended by
    #3466). The placeholder preserves that original intent instead: Grafana
    boots, and only the (already-broken, unconfigured) Slack delivery fails,
    visibly, under Grafana's Alerting -> Contact points -> Test.

    Returns `(changed, result)` -- `changed` is False when the file already
    holds this exact value, which callers use to skip an unnecessary
    Grafana restart (mirrors `_write_grafana_glitchtip_token`).

    File/dir modes are `0o644`/`0o755`, not `0o600`/`0o700`, for the same
    reason as `_write_grafana_glitchtip_token` (#3588): Grafana's
    non-root container uid needs to read this file across a native Linux
    bind mount.
    """
    path = _slack_webhook_secret_path()
    resolved = url.strip() or GRAFANA_SLACK_WEBHOOK_PLACEHOLDER_URL
    try:
        if path.exists() and path.read_text(encoding="utf-8").strip() == resolved:
            return False, OpsResult(True, f"{path} already holds the current Slack webhook URL")

        path.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        path.write_text(resolved, encoding="utf-8")
        os.chmod(path, 0o644)
    except OSError as e:
        result = _glitchtip_secrets_dir_unwritable_result(path.parent)
        return False, OpsResult(
            False,
            f"Cannot write Slack webhook URL to {path}",
            f"{result.details}\n{type(e).__name__}: {e}",
        )
    if url.strip():
        return True, OpsResult(True, f"Wrote Slack webhook URL for Grafana at {path}")
    return True, OpsResult(
        True,
        f"Wrote placeholder Slack webhook URL for Grafana at {path} "
        "(no [monitoring] slack_webhook_url configured)",
    )


def _sync_grafana_slack_webhook_secret(cfg_path: Path | None = None) -> list[OpsResult]:
    """Provision Grafana's Slack contact point secret from config.ini's
    `[monitoring] slack_webhook_url` (#3466).

    Run from both `install()` and `env_sync()` so the webhook is picked up
    whether the user runs the full native install or just the Compose-only
    Quickstart's `nyxgpt ops env-sync` before `docker compose up`.
    """
    from nyxgpt.config import load_config

    cfg_path = cfg_path or (Path.home() / ".nyxGPT" / "config.ini")
    if not cfg_path.exists():
        return [OpsResult(True, "Skipped Slack webhook sync (no config.ini yet)")]
    cfg = load_config(cfg_path)

    url = get_monitoring_slack_webhook_url(cfg)
    changed, write_result = _write_grafana_slack_webhook_secret(url)
    results = [write_result]
    if changed:
        results.append(_restart_grafana_if_running("the new Slack webhook URL"))
    return results


# The `nyxgpt-slack` contact point / integration provisioned by
# docker/grafana/provisioning/alerting/contact-points.yml -- `alert_test`
# needs both to address Grafana's receiver-test API directly (#3545).
GRAFANA_SLACK_CONTACT_POINT_NAME = "nyxgpt-slack"
GRAFANA_SLACK_INTEGRATION_UID = "nyxgpt-slack-receiver"


def _grafana_receiver_k8s_name(contact_point_name: str) -> str:
    """Grafana's alerting-notifications app addresses a legacy-provisioned
    contact point by `base64.RawURLEncoding(name)` -- see `NameToUid` /
    `convertToK8sResource` in grafana/grafana's
    pkg/services/ngalert/models/receivers.go and
    pkg/registry/apps/alerting/notifications/receiver/conversions.go.
    Confirmed live by booting grafana/grafana:13.1.1 (the pinned image)
    against this repo's exact provisioning and listing
    `/apis/notifications.alerting.grafana.app/v0alpha1/namespaces/default/receivers`
    (#3545): `nyxgpt-slack` -> `bnl4Z3B0LXNsYWNr`.
    """
    return base64.urlsafe_b64encode(contact_point_name.encode()).rstrip(b"=").decode()


def _send_grafana_test_alert(
    grafana_ui_url: str, grafana_admin_password: str, webhook_configured: bool
) -> OpsResult:
    """POST a test notification through the `nyxgpt-slack` receiver via
    Grafana's receiver-test API -- the same
    `/apis/notifications.alerting.grafana.app/.../receivers/{name}/test`
    endpoint Grafana's own Alerting -> Contact points -> Test button calls
    (#3545).

    #3466 originally posted straight into Grafana's embedded Alertmanager
    ingestion API (`/api/alertmanager/grafana/api/v2/alerts`), which only
    accepts alerts from Grafana's own rule engine and 400s on anything
    posted externally. The legacy contact-point test route that would have
    worked instead (`/api/alertmanager/grafana/config/api/v1/receivers/test`)
    also doesn't help -- it returns 410 Gone on the pinned grafana/grafana
    image, having been replaced by this one. This proves delivery through
    the contact point, not rule evaluation or notification-policy routing --
    see docs/alerting.md#testing-the-pipeline for the full-path (deliberate
    threshold breach) alternative that covers those.

    `webhook_configured` is the caller's own read of config.ini's
    `[monitoring] slack_webhook_url`. Grafana redacts/encrypts the `url`
    setting in every API response (it's schema-flagged secure regardless of
    which YAML section provisions it -- see contact-points.yml), so there is
    no way to distinguish "no webhook configured" from "webhook configured
    but wrong" by inspecting the test response alone; the caller's own
    config read is the only source of truth for that distinction.
    """
    receiver_name = _grafana_receiver_k8s_name(GRAFANA_SLACK_CONTACT_POINT_NAME)
    payload = {
        "integration": {
            "uid": GRAFANA_SLACK_INTEGRATION_UID,
            "type": "slack",
            "settings": {},
            # Reuse the currently-provisioned (possibly placeholder) `url`
            # secret rather than resupplying it -- this CLI has no access to
            # the secret file's contents, nor should it need any.
            "secureFields": {"url": True},
        },
        "alert": {
            "labels": {"alertname": "NyxGPTAlertTest", "severity": "warning"},
            "annotations": {"summary": "Test alert triggered by `nyxgpt ops alert-test`"},
        },
    }
    try:
        with _grafana_admin_client(grafana_ui_url, grafana_admin_password) as client:
            resp = client.post(
                "/apis/notifications.alerting.grafana.app/v0alpha1/namespaces/default/"
                f"receivers/{receiver_name}/test",
                json=payload,
            )
    except httpx.HTTPError as e:
        return OpsResult(
            False,
            "Failed to reach Grafana's receiver-test API",
            f"{type(e).__name__}: {e}",
        )
    if resp.status_code != 200:
        return OpsResult(
            False,
            "Grafana rejected the nyxgpt-slack contact-point test request",
            f"HTTP {resp.status_code}: {resp.text[:500]}",
        )
    data = resp.json()
    if data.get("status") == "success":
        return OpsResult(
            True,
            "Sent a test notification through the nyxgpt-slack contact point -- "
            "check Slack for delivery.",
        )
    error = str(data.get("error") or "Grafana reported failure with no error message")
    if not webhook_configured:
        return OpsResult(
            True,
            "Alerting pipeline is intact -- Grafana reached the nyxgpt-slack contact "
            "point and attempted delivery, but no [monitoring] slack_webhook_url is "
            "configured in config.ini, so delivery to the placeholder webhook failed "
            "as expected.",
            error[:500],
        )
    return OpsResult(False, "Slack delivery test failed", error[:500])


def alert_test(_args: Any) -> int:
    """CLI entrypoint for `nyxgpt ops alert-test`.

    Pushes a test notification through the `nyxgpt-slack` contact point via
    Grafana's receiver-test API -- the acceptance test for Slack delivery:
    confirms the receiver and webhook are wired correctly without waiting
    for a real CPU/memory/disk/self-heal/canary threshold breach. This
    covers contact-point delivery only, not rule evaluation or
    notification-policy routing -- see docs/alerting.md#testing-the-pipeline
    for the full-path alternative. No-ops with a clear, actionable message
    if monitoring is disabled, unset up, or Grafana isn't reachable.

    Returns 0 on success, else 2.
    """
    from nyxgpt.config import load_config

    logger.info("ops: alert-test starting", extra={"component": "ops", "action": "alert-test"})

    cfg_path = Path.home() / ".nyxGPT" / "config.ini"
    if not cfg_path.exists():
        results = [
            OpsResult(
                False,
                f"Missing config {cfg_path}",
                "Run `nyxgpt wizard` first to generate config.ini.",
            )
        ]
    else:
        cfg = load_config(cfg_path)
        monitoring = get_monitoring_config(cfg)
        if not monitoring["enabled"]:
            results = [
                OpsResult(
                    False,
                    "Monitoring is disabled",
                    "Set [monitoring] enabled = true in config.ini, then run `nyxgpt ops "
                    "install` (or start the `monitoring` Compose profile) before testing "
                    "alerts.",
                )
            ]
        else:
            grafana_admin_password = _grafana_admin_password(cfg)
            webhook_configured = bool(get_monitoring_slack_webhook_url(cfg).strip())
            results = [
                _send_grafana_test_alert(
                    monitoring["grafana_ui_url"], grafana_admin_password, webhook_configured
                )
            ]

    ok = _emit_results("alert-test", results)
    logger.info(
        "ops: alert-test %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "alert-test", "ok": ok},
    )
    return 0 if ok else 2


def _provision_glitchtip() -> list[OpsResult]:
    """Auto-provision a GlitchTip admin user, org, project, and DSN -- idempotent, zero-touch.

    Only runs when the `glitchtip` Compose container is up and passes its
    health check; no-ops with a clear message otherwise (e.g.
    `--skip-observability`, no Docker, or a freshly started container still
    inside its health-check `start_period`). Safe to call repeatedly: every
    step first checks for an existing admin user / org / project / key
    before creating one, so re-running never duplicates anything.
    """
    if not _compose_available():
        return [OpsResult(True, "Skipped GlitchTip auto-provisioning (Docker not found)")]

    if not _wait_for_glitchtip_healthy():
        return [
            OpsResult(
                True,
                "Skipped GlitchTip auto-provisioning (glitchtip container not up/healthy)",
                "Run `nyxgpt ops observability` (or `nyxgpt ops install`) to start it, then "
                "retry `nyxgpt ops glitchtip-init`.",
            )
        ]

    native_cfg_path = Path.home() / ".nyxGPT" / "config.ini"
    if not native_cfg_path.exists():
        return [
            OpsResult(
                False,
                f"Missing config {native_cfg_path}",
                "Run `nyxgpt wizard` first to generate config.ini.",
            )
        ]

    results: list[OpsResult] = []

    email, password, generated = _resolve_admin_credentials(native_cfg_path)
    if generated:
        _persist_admin_credentials(native_cfg_path, email, password)
        results.append(
            OpsResult(True, f"Generated and saved a GlitchTip admin password to {native_cfg_path}")
        )

    su_result = _glitchtip_ensure_superuser(email, password)
    results.append(su_result)
    if not su_result.ok:
        return results

    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(native_cfg_path)
    base_url = parser.get("error_tracking", "glitchtip_ui_url", fallback="http://localhost:8080")

    login_client, login_result = _glitchtip_login(base_url, email, password)
    results.append(login_result)
    if login_client is None:
        return results

    token: str | None = None
    try:
        token, token_result = _glitchtip_ensure_api_token(login_client, base_url)
        results.append(token_result)
    finally:
        login_client.close()
    if token is None:
        return results

    api_client = _glitchtip_http_client(base_url, headers={"Authorization": f"Bearer {token}"})
    dsn: str | None = None
    try:
        org_slug, org_result = _glitchtip_ensure_organization(api_client)
        results.append(org_result)
        if org_slug is None:
            return results

        team_slug, team_result = _glitchtip_ensure_team(api_client, org_slug)
        results.append(team_result)
        if team_slug is None:
            return results

        results.append(_glitchtip_ensure_team_membership(api_client, org_slug, team_slug))

        project_slug, project_result = _glitchtip_ensure_project(api_client, org_slug, team_slug)
        results.append(project_result)
        if project_slug is None:
            return results

        dsn, key_result = _glitchtip_ensure_project_key(api_client, org_slug, project_slug)
        results.append(key_result)
        if dsn is None:
            return results
    finally:
        api_client.close()

    previous_native_dsn = _current_error_tracking_dsn(native_cfg_path)
    results.append(_write_error_tracking_dsn(native_cfg_path, dsn, chmod_600=True))
    results.append(
        _write_error_tracking_dsn(
            COMPOSE_CONFIG_FILE, _containerized_error_tracking_dsn(dsn), chmod_600=False
        )
    )
    if dsn != previous_native_dsn:
        results.append(_restart_native_api_if_running())

    token_changed, token_write_result = _write_grafana_glitchtip_token(token)
    results.append(token_write_result)
    if token_changed:
        results.append(_restart_grafana_if_running())

    return results


def glitchtip_init(args: Any) -> int:
    """CLI entrypoint for `nyxgpt ops glitchtip-init`.

    Auto-provisions a GlitchTip admin user, organization, project, and DSN
    with no manual sign-in step, writing the DSN into config.ini. Idempotent
    -- safe to re-run any time. No-ops with a clear message if the
    `glitchtip` Compose container isn't up/healthy.

    Returns 0 on success (including a clean no-op), else 2.
    """
    logger.info(
        "ops: glitchtip-init starting", extra={"component": "ops", "action": "glitchtip-init"}
    )
    steps: list[tuple[str, Callable[[], list[OpsResult]]]] = [
        ("provision glitchtip", _provision_glitchtip),
    ]
    quiet = bool(getattr(args, "quiet", False))
    results, slow_steps = _run_steps("glitchtip-init", steps, quiet=quiet)
    ok = all(r.ok for r in results)
    if not quiet:
        _print_slow_steps_summary(slow_steps)
    logger.info(
        "ops: glitchtip-init %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "glitchtip-init", "ok": ok},
    )
    return 0 if ok else 2


# --- Wrapped credential retrieval (`nyxgpt ops credentials`, #3718) ---
#
# Both observability UIs behind the SRE dashboard have admin credentials
# that are deliberately never exposed over the HTTP API (#3458/#3466), and
# until now had no wrapped way to read them either -- so logging into
# Grafana or GlitchTip meant `ssh` + `cat` on the box, the rawest possible
# violation of the Operational Command Wrapping requirement. These commands
# close that gap CLI-side only: `nyxgpt ops credentials` on the machine
# running the stack, `nyxgpt cloud credentials` (see cloud_deploy.py) for a
# deployment, over the same wrapped SSH access path everything else uses.

GRAFANA_ADMIN_USERNAME = "admin"

CREDENTIAL_SERVICES = ("grafana", "glitchtip")


@dataclass(frozen=True)
class ServiceCredential:
    """One service's admin login, plus where the password actually came from.

    `password` is empty when nothing is resolvable yet; `remediation` then
    says which wrapped command provisions it. `source` exists because the
    same service can be credentialed three different ways (config.ini
    override, ops-managed secret file, `glitchtip-init` provisioning) and an
    operator debugging a failed login needs to know which one answered.
    """

    service: str
    url: str
    username: str
    password: str
    source: str
    remediation: str = ""

    @property
    def available(self) -> bool:
        """Whether a password could be resolved at all."""
        return bool(self.password)

    def as_dict(self) -> dict[str, Any]:
        """JSON-serializable form, for `--json` and the cloud path's transport."""
        return {
            "service": self.service,
            "url": self.url,
            "username": self.username,
            "password": self.password,
            "source": self.source,
            "remediation": self.remediation,
            "available": self.available,
        }


def _grafana_credential(cfg: ConfigParser) -> ServiceCredential:
    """Resolve Grafana's admin login the way `nyxgpt ops install` reconciles it.

    Read-only: uses `read_grafana_admin_password` rather than
    `resolve_grafana_admin_password`, so merely *asking* for the password on
    a host that was never installed doesn't mint one -- see that function's
    docstring.
    """
    password, source = read_grafana_admin_password(cfg)
    return ServiceCredential(
        service="grafana",
        url=str(get_monitoring_config(cfg).get("grafana_ui_url", "")),
        username=GRAFANA_ADMIN_USERNAME,
        password=password,
        source=source,
        remediation=(
            ""
            if password
            else (
                "No Grafana admin password has been provisioned yet -- run "
                "`nyxgpt ops install` (it generates and reconciles one), or set "
                "[monitoring] grafana_admin_password in config.ini."
            )
        ),
    )


def _glitchtip_credential(cfg: ConfigParser, cfg_path: Path) -> ServiceCredential:
    """Resolve GlitchTip's admin login from the config.ini `glitchtip-init` wrote.

    Reads `cfg_path` directly rather than the cached `cfg`: `nyxgpt ops
    glitchtip-init` persists the generated credentials by rewriting
    config.ini (`_persist_admin_credentials`), and a long-lived process's
    cached parser can be a provisioning run behind what is on disk.
    """
    parser = ConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(cfg_path)

    password = parser.get("error_tracking", "admin_password", fallback="").strip()
    email = parser.get("error_tracking", "admin_email", fallback="").strip()
    return ServiceCredential(
        service="glitchtip",
        url=str(get_error_tracking_config(cfg).get("glitchtip_ui_url", "")),
        username=email or GLITCHTIP_DEFAULT_ADMIN_EMAIL,
        password=password,
        source=f"{cfg_path} [error_tracking] admin_password" if password else "",
        remediation=(
            ""
            if password
            else (
                "No GlitchTip admin password has been provisioned yet -- run "
                "`nyxgpt ops glitchtip-init` (it provisions the admin user and "
                "saves the credentials)."
            )
        ),
    )


def resolve_service_credentials(
    cfg_path: Path | None = None, services: Container[str] | None = None
) -> list[ServiceCredential]:
    """Resolve the admin logins for the observability UIs on this machine.

    Each credential comes from its real source -- a config.ini override, the
    ops-managed secret file, or the values `glitchtip-init` provisioned --
    so what this prints is what the running service actually accepts.
    `services` filters to a subset (default: all of `CREDENTIAL_SERVICES`).
    """
    from nyxgpt.config import load_config

    path = cfg_path or (NYXGPT_HOME / "config.ini")
    cfg = load_config(path)
    wanted = CREDENTIAL_SERVICES if services is None else services

    resolvers: dict[str, Callable[[], ServiceCredential]] = {
        "grafana": lambda: _grafana_credential(cfg),
        "glitchtip": lambda: _glitchtip_credential(cfg, path),
    }
    return [resolvers[name]() for name in CREDENTIAL_SERVICES if name in wanted]


def format_credentials(creds: list[ServiceCredential]) -> str:
    """Render `creds` for a terminal, one labeled block per service."""
    blocks: list[str] = []
    for cred in creds:
        lines = [cred.service]
        if cred.url:
            lines.append(f"  URL:      {cred.url}")
        if cred.available:
            lines.append(f"  Username: {cred.username}")
            lines.append(f"  Password: {cred.password}")
            lines.append(f"  Source:   {cred.source}")
        else:
            lines.append(f"  Username: {cred.username}")
            lines.append("  Password: (not provisioned)")
            lines.append(f"  Fix:      {cred.remediation}")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


def credentials(args: Any) -> int:
    """CLI entrypoint for `nyxgpt ops credentials`.

    Prints the Grafana and GlitchTip admin logins for the stack on this
    machine, replacing the `ssh` + `cat ~/.nyxGPT/secrets/...` an operator
    otherwise needs to sign in (#3718). Output goes to stdout only: the
    passwords are never logged (the log line below records service names and
    whether each resolved, never a value) and remain absent from every HTTP
    API response, preserving #3458/#3466.

    Returns 0 when every requested service resolved, else 2 -- so a missing
    credential is a scriptable failure rather than a silently empty field.
    """
    cfg_path = Path(args.config).expanduser() if getattr(args, "config", None) else None
    service = getattr(args, "service", "all") or "all"
    wanted = CREDENTIAL_SERVICES if service == "all" else (service,)

    creds = resolve_service_credentials(cfg_path=cfg_path, services=wanted)

    if getattr(args, "json", False):
        print(json.dumps([c.as_dict() for c in creds], indent=2))
    else:
        print(format_credentials(creds))

    ok = all(c.available for c in creds)
    logger.info(
        "ops: credentials %s",
        "resolved" if ok else "incomplete",
        extra={
            "component": "ops",
            "action": "credentials",
            "services": [c.service for c in creds],
            "resolved": [c.service for c in creds if c.available],
            "ok": ok,
        },
    )
    return 0 if ok else 2


# --- Live verification harness (`nyxgpt ops verify`, #3555 / P6-18) ---


def _verify_repo_index_path(mode: DeploymentMode) -> str:
    """Resolve the repo-ingest fixture's path as the running `api` process will see it.

    Writes a tiny fixture repo under the shared `nyxgpt-data` volume
    (`volume_dir("nyxgpt-data")`) and translates it to the API process's own
    view of that path: the containerized `api` service bind-mounts that host
    directory at `/root/.nyxGPT` (see docker-compose.yml), while a native
    `api` process sees the same host path directly (both pass
    `ingest_repository`'s "must be under Path.home()" check either way).
    """
    host_dir = volume_dir("nyxgpt-data") / "rag-verify-repo"
    verify_mod.write_verify_repo_fixture(host_dir)
    if mode.compose.get("api", "absent") not in ("absent", "none", ""):
        rel = host_dir.relative_to(Path.home())
        return f"/root/{rel.as_posix()}"
    return str(host_dir)


def _boot_verify_stack() -> list[OpsResult]:
    """Bring up the full Compose stack (core app + observability profiles) for `nyxgpt ops verify`.

    Unlike `_start_observability_stack` (which deliberately excludes
    `CORE_APP_SERVICES` so a native-first install's own processes aren't
    duplicated in Compose), `verify`'s target environment -- CI, or an
    ephemeral local run -- has no native brew/launchd path at all, so this
    issues a plain `docker compose --profile X... up -d` with no
    service-list filtering: Compose brings up every default (core app)
    service plus the requested observability profiles together, the same
    shape `scripts/smoke-test.sh` deploys for its own live smoke test.
    """
    if not _compose_available():
        return [
            OpsResult(
                False,
                "docker not found -- `nyxgpt ops verify` needs the Compose stack",
                "Install Docker, or pass --skip-boot if a stack (native or Compose) is "
                "already up.",
            )
        ]
    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE)]
    for profile in OBSERVABILITY_PROFILES:
        cmd += ["--profile", profile]
    cmd += ["up", "-d"]
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [OpsResult(False, "Failed to boot the Compose stack for verify", _cp_details(cp))]
    return [OpsResult(True, "Compose stack up (core app + observability profiles)")]


def _wait_for_verify_stack_healthy(
    services: tuple[str, ...] = ("api", "web", "ollama", "cassandra"),
    timeout: float = 300.0,
    poll_interval: float = 5.0,
) -> list[OpsResult]:
    """Poll `self_heal.list_component_status()` until every service in `services` is healthy."""
    deadline = time.monotonic() + timeout
    pending = set(services)
    while pending and time.monotonic() < deadline:
        statuses = {s.service: s for s in self_heal.list_component_status()}
        for service in list(pending):
            status = statuses.get(service)
            if status is not None and status.healthy:
                pending.discard(service)
        if pending:
            time.sleep(poll_interval)
    if pending:
        return [
            OpsResult(
                False,
                f"Timed out waiting for {', '.join(sorted(pending))} to become healthy",
                f"Waited {timeout:g}s -- check `nyxgpt ops status` / `docker compose logs`.",
            )
        ]
    return [OpsResult(True, f"{', '.join(services)} all healthy")]


def _teardown_verify_stack() -> list[OpsResult]:
    """Tear down the Compose stack `_boot_verify_stack` brought up (app + observability)."""
    if not _compose_available():
        return [OpsResult(True, "Skipped verify stack teardown (Docker not found)")]
    cmd = ["docker", "compose", "-f", str(self_heal.COMPOSE_FILE)]
    for profile in OBSERVABILITY_PROFILES:
        cmd += ["--profile", profile]
    cmd += ["down"]
    cp = _run(cmd, check=False)
    if cp.returncode != 0:
        return [OpsResult(False, "Failed to tear down verify stack", _cp_details(cp))]
    return [OpsResult(True, "Verify stack torn down")]


def verify(args: Any) -> int:
    """CLI entrypoint for `nyxgpt ops verify`.

    The live smoke harness behind #3555/P6-18: boots the Compose stack
    (core app + observability profiles) in an ephemeral environment unless
    `--skip-boot` is passed, generates one known unit of traffic per
    acceptance-criteria path (a chat round-trip, one RAG ingest per source
    -- document/upload/repo -- and a RAG query -- see `nyxgpt.verify`),
    then asserts it landed via two independent live checks: Prometheus
    instant-query counter deltas, and Grafana's HTTP API re-executing each
    touched dashboard panel's own query. Captures Playwright screenshots of
    the touched dashboards as visual evidence for the review agent
    (multimodal) to inspect. Tears the stack back down afterward unless
    `--keep-up` is passed (or `--skip-boot` was used, in which case nothing
    was booted to tear down).

    This is what the review agent runs in CI on every PR touching
    observability, metrics, or UI surfaces (see
    agents/runbooks/review-runbook.md), and what the owner can run locally
    as a one-command pre-check before acceptance testing.

    Returns 0 if every check passed, else 2.
    """
    from nyxgpt.config import get_api_port, get_auth_api_key, load_config

    logger.info("ops: verify starting", extra={"component": "ops", "action": "verify"})

    cfg_path = Path.home() / ".nyxGPT" / "config.ini"
    if not cfg_path.exists():
        precondition_results = [
            OpsResult(
                False, f"Missing config {cfg_path}", "Run `nyxgpt wizard` first to generate it."
            )
        ]
        ok = _emit_results("verify", precondition_results)
        return 0 if ok else 2

    cfg = load_config(cfg_path)
    monitoring = get_monitoring_config(cfg)
    if not monitoring["enabled"]:
        precondition_results = [
            OpsResult(
                False,
                "Monitoring is disabled",
                "Set [monitoring] enabled = true in config.ini, then run `nyxgpt ops install` "
                "(or start the `monitoring` Compose profile) before running `nyxgpt ops "
                "verify` -- it asserts against Prometheus/Grafana, which need to be up.",
            )
        ]
        ok = _emit_results("verify", precondition_results)
        return 0 if ok else 2

    results: list[OpsResult] = []
    booted = False
    try:
        if not getattr(args, "skip_boot", False):
            boot_results = _boot_verify_stack()
            results.extend(boot_results)
            if not all(r.ok for r in boot_results):
                ok = _emit_results("verify", results)
                return 0 if ok else 2
            booted = True

            health_results = _wait_for_verify_stack_healthy(timeout=getattr(args, "timeout", 300.0))
            results.extend(health_results)
            results.extend(_reconcile_grafana_provisioning())
            if not all(r.ok for r in health_results):
                ok = _emit_results("verify", results)
                return 0 if ok else 2

        api_url = getattr(args, "api_url", None) or f"http://127.0.0.1:{get_api_port(cfg)}"
        api_key = get_auth_api_key(cfg) or None
        grafana_admin_password = _grafana_admin_password(cfg)
        prometheus_url = monitoring["prometheus_ui_url"]
        grafana_url = monitoring["grafana_ui_url"]

        repo_index_path = _verify_repo_index_path(detect_deployment_mode())

        before = verify_mod.snapshot_counters(prometheus_url, verify_mod.EXPECTED_COUNTER_QUERIES)

        _markers, traffic_checks = verify_mod.generate_traffic(
            api_url, api_key, repo_index_path=repo_index_path
        )
        results.extend(OpsResult(c.ok, c.message, c.details) for c in traffic_checks)

        prometheus_checks = verify_mod.assert_counter_deltas(
            prometheus_url, before, verify_mod.EXPECTED_COUNTER_QUERIES
        )
        results.extend(OpsResult(c.ok, c.message, c.details) for c in prometheus_checks)

        try:
            dashboard_paths = verify_mod.resolve_touched_dashboards(
                getattr(args, "dashboards", None)
            )
        except ValueError as e:
            results.append(OpsResult(False, "Could not resolve touched dashboards", str(e)))
            dashboard_paths = []

        if dashboard_paths:
            with _grafana_admin_client(grafana_url, grafana_admin_password) as grafana_client:
                panel_checks = verify_mod.assert_panel_queries(grafana_client, dashboard_paths)
            results.extend(OpsResult(c.ok, c.message, c.details) for c in panel_checks)

            if not getattr(args, "skip_screenshots", False):
                out_dir = Path(
                    getattr(args, "screenshot_dir", None)
                    or (Path.home() / ".nyxGPT" / "verify-artifacts")
                )
                screenshot_checks = verify_mod.capture_dashboard_screenshots(
                    grafana_url,
                    grafana_admin_password,
                    [verify_mod.dashboard_uid(p) for p in dashboard_paths],
                    out_dir,
                )
                results.extend(OpsResult(c.ok, c.message, c.details) for c in screenshot_checks)
    finally:
        if booted and not getattr(args, "keep_up", False):
            results.extend(_teardown_verify_stack())

    ok = _emit_results("verify", results)
    logger.info(
        "ops: verify %s",
        "succeeded" if ok else "failed",
        extra={"component": "ops", "action": "verify", "ok": ok},
    )
    result, message = _ops_action_outcome(results)
    _record_ops_action("verify", "verify", result, message)
    return 0 if ok else 2
