"""
nyxGPT package
"""
