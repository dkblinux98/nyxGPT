#!/usr/bin/env bash
set -euo pipefail

# nyxGPT web runner
# Starts the Next.js dev server using ~/.nyxGPT/config.ini

CONFIG="$HOME/.nyxGPT/config.ini"
if [[ ! -f "$CONFIG" ]]; then
  echo "Missing config: $CONFIG" >&2
  exit 1
fi

# Minimal INI reader: get_ini section key
get_ini() {
  local section="$1"
  local key="$2"
  awk -F '=' -v s="[$section]" -v k="$key" '
    $0==s { found=1; next }
    /^\[/ { found=0 }
    found && $1 ~ k {
      gsub(/^[ \t]+|[ \t]+$/, "", $2)
      print $2
      exit
    }
  ' "$CONFIG"
}

WEB_HOST="$(get_ini web host)"
WEB_PORT="$(get_ini web port)"
API_OVERRIDE="$(get_ini web api_base_url)"
NODE_BIN="$(get_ini paths node_bin)"
NPM_BIN="$(get_ini paths npm_bin)"
REPO_DIR="$(get_ini paths repo_dir)"


if [[ -z "$NODE_BIN" || -z "$NPM_BIN" || -z "$REPO_DIR" ]]; then
  echo "Missing required [paths] configuration (node_bin, npm_bin, repo_dir)" >&2
  exit 1
fi

# Ensure node is discoverable for tools that use `#!/usr/bin/env node` (e.g., npm)
NODE_DIR="$(dirname "$NODE_BIN")"
NPM_DIR="$(dirname "$NPM_BIN")"
export PATH="$NODE_DIR:$NPM_DIR:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"

if ! command -v node >/dev/null 2>&1; then
  echo "node not found on PATH (PATH=$PATH). Check [paths] node_bin and npm_bin in $CONFIG" >&2
  exit 1
fi

export HOST="${WEB_HOST:-127.0.0.1}"
export PORT="${WEB_PORT:-3000}"

if [[ -n "${API_OVERRIDE:-}" ]]; then
  export NEXT_PUBLIC_API_BASE="$API_OVERRIDE"
fi

# web/src/lib/apiProxy.ts attaches X-API-Key from NYXGPT_AUTH_API_KEY on every
# proxied call. Without it, turning on [auth] enabled leaves the web UI 401ing
# against its own API (#3632) -- the key was only ever wired up in Compose mode.
# `tr`, not ${VAR,,}: macOS ships bash 3.2, where the latter is a fatal
# "bad substitution" under `set -euo pipefail`.
AUTH_ENABLED="$(get_ini auth enabled | tr '[:upper:]' '[:lower:]')"
if [[ "$AUTH_ENABLED" == "true" ]]; then
  AUTH_KEY="$(get_ini auth api_key)"
  if [[ -n "${AUTH_KEY:-}" ]]; then
    export NYXGPT_AUTH_API_KEY="$AUTH_KEY"
  fi
fi

cd "$REPO_DIR/web"

# Clear Next.js cache to ensure fresh routes are recognized
# This prevents 404 errors when new routes are added
# Note: In launchd context, Dropbox-synced directories may be protected
if [[ -d ".next" ]]; then
  # Test if we can write to the directory before attempting deletion
  if touch ".next/.nyxgpt-test" 2>/dev/null; then
    rm -f ".next/.nyxgpt-test"
    echo "Clearing Next.js cache (.next directory)..."
    xattr -rc .next 2>/dev/null || true
    rm -rf .next 2>/dev/null || true
  fi
  # If we can't write, silently skip cache clearing - Next.js will work fine
fi

exec "$NPM_BIN" run dev
