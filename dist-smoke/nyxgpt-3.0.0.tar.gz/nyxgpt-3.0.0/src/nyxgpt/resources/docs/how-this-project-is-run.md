# How this project is run

nyxGPT is built by an agent-staffed engineering organization managed by a
human owner with an SRE/Release Management background. See
[What nyxGPT actually is](../README.md#what-nyxgpt-actually-is) in the
README for why that's the point of this project, not incidental to it.
This page is the mechanics.

## Agent roles and workflow

Four roles carry the work, each restricted to a fixed set of allowed
actions — see [AGENTS.md](../AGENTS.md) for the authoritative permission
matrix; nothing not explicitly allowed there may be done by an agent.

- **scrummaster-agent** — selects the next backlog issue (lowest Phase,
  then lowest issue number) and hands it to the developer agent. Charter:
  [agents/charters/scrummaster-agent.md](../agents/charters/scrummaster-agent.md) ·
  runbook: [agents/runbooks/scrummaster-runbook.md](../agents/runbooks/scrummaster-runbook.md).
- **developer-agent** — implements the issue, writes/updates tests, and
  opens a PR. Charter:
  [agents/charters/developer-agent.md](../agents/charters/developer-agent.md) ·
  runbook: [agents/runbooks/developer-runbook.md](../agents/runbooks/developer-runbook.md).
- **review-agent** — reviews the PR against the issue's acceptance
  criteria and code quality, decides APPROVE or REQUEST_CHANGES, and owns
  the merge on approval. Charter:
  [agents/charters/review-agent.md](../agents/charters/review-agent.md) ·
  runbook: [agents/runbooks/review-runbook.md](../agents/runbooks/review-runbook.md).
- **stakeholder-agent** — an optional notifier role that surfaces when
  human stakeholder approval is required; it does not modify repo state
  directly. Charter:
  [agents/charters/stakeholder-agent.md](../agents/charters/stakeholder-agent.md).

A fifth role, the **human owner**, closes releases, advances phases, and
is the only actor who can move an issue to "For Release." After three
rejected review cycles on a PR, the issue escalates to the human owner
directly (see the review runbook, §6).

Each role's prompt (what the agent is told when it runs) lives under
[agents/prompts/](../agents/prompts/), alongside its charter and runbook.

## The project board status flow

Every issue moves through a fixed set of statuses on the GitHub project
board:

```
Backlog -> In Progress -> In Review -> Acceptance Testing -> For Release -> Closed
```

- **Backlog** — approved, unscheduled.
- **In Progress** — the developer agent is actively implementing it.
- **In Review** — a PR is open; the review agent (or, after 3 rejected
  cycles, the human owner) is deciding. After merge, the issue *stays* "In
  Review" until acceptance testing formally begins — this prevents
  unmerged work from being tested by mistake.
- **Acceptance Testing** — merged, and assigned to the human owner to
  verify the acceptance criteria against the real, running system.
- **For Release** — accepted; only the human owner sets this.
- **Closed** — released.

An issue can also be "parked" mid-flow — merged but held at "In Review"
instead of advancing to Acceptance Testing — if its acceptance criteria
depend on other, still-open issues; it promotes automatically once every
blocker clears. Full semantics are in
[AGENTS.md](../AGENTS.md#project-status-semantics) and
[agents/runbooks/review-runbook.md](../agents/runbooks/review-runbook.md) §9.

## Decision records

Architecture and product choices with lasting consequences are captured as
standalone decision records under
[`product_management/`](../product_management/) (`DECISION_*.md`) — for
example
[DECISION_AWS_COMPUTE_SUBSTRATE.md](../product_management/DECISION_AWS_COMPUTE_SUBSTRATE.md)
and
[DECISION_PRIVATE_ACCESS_MECHANISM.md](../product_management/DECISION_PRIVATE_ACCESS_MECHANISM.md).
Each records the problem, the constraints inherited from prior decisions,
the options considered, and the owner's approval, so a later reader can
see why a choice was made without reconstructing it from commit history.

## The operating ledger

Decision records explain *why* a lasting choice was made. The **operating
ledger**, [agents/LEDGER.md](../agents/LEDGER.md), does something narrower and
more operational: it is the agent system's memory between sessions.

An agent session starts with no recollection of the last one. Left to itself it
reconstructs project state — what was decided, what is published, what is
deliberately not being worked — by re-deriving it from artifacts, and when the
artifacts are incomplete it fills the gaps and states the result with the same
confidence as something it actually checked. Nothing distinguishes a
reconstruction from a verified fact, which makes the failure invisible from
both sides.

The ledger moves that memory into the repository. It records four things:

- **Decisions** — what was settled, when, and by whom.
- **Verifications** — a fact, the method that established it, and the condition
  that makes it stale. The method is mandatory and must be repeatable.
- **Parked items** — work deliberately not being done, with the reason and the
  condition that would revive it, so nobody re-proposes it every few weeks.
- **Open questions** — what is unresolved and who can answer it.

Plus a **Superseded** section: beliefs this project genuinely held and has since
retired. Entries are never deleted, only moved there — a deleted entry becomes
re-derivable, and gets re-derived wrong.

Every agent reads it at session start, and the binding rule is that **a claim
not in the ledger and not freshly verified is not asserted as fact**. Agents
append entries through the normal branch/PR path, riding in whatever PR
produced the fact.

It stays short on purpose: load-bearing facts and decisions, never narration of
what a session did (commits, PRs and issue threads already record that). The
entry schema, granularity rules and pruning rule live in the ledger itself; the
doctrine behind it is `product_management/AGENTIC_SDLC_DESIGN.md` §9b.

## Definition of Done, and the acceptance-failure / improvement taxonomy

The
[Definition of Done](../CLAUDE.md#definition-of-done-owner-requirement-2026-07-08)
requires every user-facing feature to be reachable end-to-end: a backend
change with no web UI surface, or an ops feature with no admin-dashboard
surface, is an incomplete implementation, and the review agent is required
to block on it as a Medium finding.

It also requires **executed verification**: a change whose claim is about
runtime, install or platform behavior reaches acceptance testing only once
that claim has been demonstrated by running it on the target platform — a
smoke job on a real macOS/Linux runner, a dispatched workflow run, or the
command itself with its output — cited in the pull request. Review here is
inspection, and inspection cannot see a broken venv bootstrap or a missing
`npm` on a cloud image. The mechanics, including which smoke job covers which
platform, are in [Testing](testing.md#executed-verification-smoke-jobs-on-real-targets-3775).

When human acceptance testing (after merge) turns something up, it is
classified into one of two buckets, because they mean different things
about where the process broke:

- **Acceptance Failure** — the implementation does not do what the
  accepted issue specified. Filed as a new, related issue that blocks the
  original feature from reaching "For Release" until the failure is fixed
  and itself accepted.
- **Improvement** — the implementation does exactly what was specified,
  but the specification itself was incomplete or wrong. This is charged to
  requirements, not implementation — a product management failure, not an
  acceptance failure. It gates the original feature exactly as a failure
  does; the label difference is a statistic, not a gate.

Neither bucket is worked the moment it is filed. Both land in an
**Acceptance Failed** holding lane and wait for the acceptance round to
finish: the fix process starts once **Acceptance Testing** has drained
(empty except the release tracking issue), at which point the held items
move to Backlog and the queue is kicked once. That keeps the owner's
testing rhythm intact — test everything, drain, test the next candidate —
instead of flooding the lane under test with freshly-merged fixes.
Agent-process issues bypass the gate.

The same lane is also where the owner parks **features they have tested and
failed**, so that what has failed stays visible in one place. Those are
closed issues, and the machinery reads the difference: closed items in the
lane are parked and are moved only by the promotion sweep, once everything
blocking them is accepted; open items are the round's held rework.

The other end of the cycle is automated from the same signal: the owner
moving the **release tracking issue** to "For Release" is the release
sign-off, and the ceremony (master fast-forward, tag, GitHub Release,
`stable` publish, Homebrew tap stamp, retirement of that line's release
candidates) runs from it unattended.

Full mechanics — the related-issue model, the blocking dependency, and the
sweep that automatically promotes a feature to "For Release" once every
related failure clears — are in
[agents/runbooks/review-runbook.md](../agents/runbooks/review-runbook.md) §9;
the drain gate and the automated ceremony are in
[docs/acceptance-drain-gate.md](acceptance-drain-gate.md).

## The documentation contract (both directions)

Two questions are asked about documentation on every change, and they are
deliberately separate:

1. **Forward** — are the docs *for this change* updated? Enforced
   diff-scoped by the review workflow: user-facing code changed with no doc
   update blocks approval.
2. **Inverse** — does this change make something already written
   *elsewhere* untrue? This is not detectable from the diff, so the review
   agent runs it by hand: name the capability the change adds, removes or
   inverts, grep the whole tree for existing assertions about it, and fix
   every sentence the merged state falsifies. An unfixed falsified claim is
   a Medium (blocking) finding.

The inverse question exists because of a concrete miss (#3743, 2026-08-13):
repo-less PyPI publishing shipped while `README.md` still asserted it had
not shipped and a repo checkout was still required. Both agents passed the
forward check honestly — the false section was simply nowhere near the
diff. Its corollary is an authoring rule: docs must not contain world-state
claims with built-in expiry ("not yet shipped", "the currently published
version is…", "planned for Phase N"); they point at living sources — the
PyPI project page, [the portability matrix](portability-matrix.md),
generated command/API docs, the release tracking issue — instead. Full
contract text: [review runbook](../agents/runbooks/review-runbook.md) §1a
and [developer runbook](../agents/runbooks/developer-runbook.md) §5.

## The retrospective

A regularly-refreshed retrospective dashboard tracks review-cycle
outcomes, acceptance-failure/improvement rates, and time-to-merge across
the project's history — the evidence behind the claim that gate activity
in this project is real and routine, not theoretical. It's built from the
same issue/PR history visible in this repository and refreshed via
[scripts/retrospective/REFRESH_RUNBOOK.md](../scripts/retrospective/REFRESH_RUNBOOK.md).

It also tracks the cost side of running the project with agents: *spend
telemetry* (billable runner minutes, Claude-invoking steps and self-heal
retries per issue) and *churn cost* — the token price of re-onboarding an
agent that carries no memory between rounds, split into context
re-establishment vs change production per round, rolled up per issue across
rounds, and paired with a hand-recorded tally of stale-context incidents
(acting on a fact a later session had already changed). Both are
owner-refreshed dumps; the churn view reports dollars only when the owner
has configured a price sheet for the dump to use, and tokens otherwise. The
rates themselves are never committed to this repository.

**As part of the v3.0.0 release, the retrospective is made publicly
reachable** (the share action itself is owner-side, performed at release
time):
[nyxGPT Project Retrospective](https://claude.ai/code/artifact/2b850289-fbb2-4e55-abf7-ea55d4501701).
Until that release step happens, this link is only reachable from the
owner's own Claude session.
